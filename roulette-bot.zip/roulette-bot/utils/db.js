const fs = require('fs');
const path = require('path');
const file = path.join(__dirname, '..', 'data', 'settings.json');

function all() {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return {}; }
}

// max = 0 يعني لا نهائي
function get(guildId) {
  return { channelId: null, wait: 60, enabled: true, max: 0, ...(all()[guildId] || {}) };
}

function set(guildId, patch) {
  const data = all();
  data[guildId] = { ...get(guildId), ...patch };
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
  return data[guildId];
}

module.exports = { get, set };

const fs = require('fs');
const path = require('path');
const { createCanvas, loadImage } = require('@napi-rs/canvas');

async function safeLoad(url) {
  if (!url) return null;
  try {
    const r = await fetch(url);
    return await loadImage(Buffer.from(await r.arrayBuffer()));
  } catch { return null; }
}

// صورة العجلة: الشريحة بتاعة المختار بتقف عند المؤشر (اليمين)
async function wheel(names, chooserIndex, guildIconUrl) {
  const S = 700, c = S / 2, R = 330;
  const cv = createCanvas(S, S);
  const g = cv.getContext('2d');
  const n = names.length;
  const a = (Math.PI * 2) / n;
  const rot = -((chooserIndex + 0.5) * a) + (Math.random() - 0.5) * a * 0.6;

  g.translate(c, c);
  g.save();
  g.rotate(rot);
  names.forEach((name, i) => {
    g.beginPath();
    g.moveTo(0, 0);
    g.arc(0, 0, R, i * a, (i + 1) * a);
    g.closePath();
    g.fillStyle = `hsl(${(i * 360 / n + (i % 2) * 25) % 360},45%,52%)`;
    g.fill();
    g.strokeStyle = '#ffffff';
    g.lineWidth = 2;
    g.stroke();

    g.save();
    g.rotate(i * a + a / 2);
    g.fillStyle = '#ffffff';
    g.font = `bold ${n > 24 ? 12 : n > 14 ? 16 : 22}px sans-serif`;
    g.textAlign = 'right';
    g.textBaseline = 'middle';
    g.fillText(String(name).slice(0, 14), R - 18, 0);
    g.restore();
  });
  g.restore();

  // دايرة المنتصف + صورة السيرفر
  const r = 58;
  g.save();
  g.beginPath();
  g.arc(0, 0, r, 0, Math.PI * 2);
  g.closePath();
  g.fillStyle = '#111';
  g.fill();
  g.clip();
  const icon = await safeLoad(guildIconUrl);
  if (icon) g.drawImage(icon, -r, -r, r * 2, r * 2);
  g.restore();
  g.beginPath();
  g.arc(0, 0, r, 0, Math.PI * 2);
  g.strokeStyle = '#ffffff';
  g.lineWidth = 4;
  g.stroke();

  // المؤشر
  g.beginPath();
  g.moveTo(R - 30, 0);
  g.lineTo(R + 14, -18);
  g.lineTo(R + 14, 18);
  g.closePath();
  g.fillStyle = '#ffffff';
  g.fill();

  return cv.toBuffer('image/png');
}

// صورة اللوبي: لو حطيت assets/banner.png هيستخدمها، غير كده بيرسم واحدة
function banner() {
  const custom = path.join(__dirname, '..', 'assets', 'banner.png');
  if (fs.existsSync(custom)) return fs.readFileSync(custom);

  const W = 1200, H = 520;
  const cv = createCanvas(W, H);
  const g = cv.getContext('2d');
  g.fillStyle = '#1a1b1f';
  g.fillRect(0, 0, W, H);

  // توهج خلف النص
  const glow = g.createRadialGradient(850, 260, 10, 850, 260, 330);
  glow.addColorStop(0, 'rgba(120,130,170,0.20)');
  glow.addColorStop(1, 'rgba(26,27,31,0)');
  g.fillStyle = glow;
  g.fillRect(0, 0, W, H);

  // العجلة (يسار)
  const cx = 300, cy = 260, R = 220;
  const cols = ['#1d2234', '#252b42', '#161a28', '#2b3250', '#1a1f30', '#222842'];
  for (let i = 0; i < 6; i++) {
    g.beginPath();
    g.moveTo(cx, cy);
    g.arc(cx, cy, R, i * Math.PI / 3 + 0.35, (i + 1) * Math.PI / 3 + 0.35);
    g.closePath();
    g.fillStyle = cols[i];
    g.fill();
    g.strokeStyle = '#3b4468';
    g.lineWidth = 3;
    g.stroke();
  }
  g.beginPath(); g.arc(cx, cy, R, 0, Math.PI * 2);
  g.strokeStyle = '#4a547c'; g.lineWidth = 8; g.stroke();

  // دوائر صغيرة على الحافة
  for (const ang of [-2.3, -0.5, 0.9, 2.4]) {
    const x = cx + Math.cos(ang) * (R - 25), y = cy + Math.sin(ang) * (R - 25);
    g.beginPath(); g.arc(x, y, 34, 0, Math.PI * 2);
    g.fillStyle = '#2a2f45'; g.fill();
    g.strokeStyle = '#4a547c'; g.lineWidth = 3; g.stroke();
    g.fillStyle = '#e8e8f0';
    g.beginPath(); g.arc(x, y, 9, 0, Math.PI * 2); g.fill();
  }

  // المنتصف
  g.beginPath(); g.arc(cx, cy, 62, 0, Math.PI * 2);
  g.fillStyle = '#0e0f13'; g.fill();
  g.strokeStyle = '#6b76a3'; g.lineWidth = 5; g.stroke();
  g.beginPath(); g.arc(cx, cy, 24, 0, Math.PI * 2);
  g.fillStyle = '#ffffff'; g.fill();

  // النص (يمين)
  g.fillStyle = '#ffffff';
  g.textAlign = 'center';
  g.textBaseline = 'middle';
  g.font = 'bold 96px sans-serif';
  g.fillText('روليت', 880, 150);
  g.font = '34px sans-serif';
  g.fillText('للدخول على اللعبة قم بالضغط', 880, 250);
  g.font = 'bold 40px sans-serif';
  g.fillText('على زر', 960, 320);

  // شكل زر "دخول"
  g.fillStyle = '#3a3c44';
  g.beginPath(); g.roundRect(770, 292, 130, 56, 12); g.fill();
  g.fillStyle = '#ffffff';
  g.font = 'bold 28px sans-serif';
  g.fillText('دخول', 835, 321);

  return cv.toBuffer('image/png');
}

module.exports = { wheel, banner };

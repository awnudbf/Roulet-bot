// Roulette Bot - By ahmdfc
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { Client, GatewayIntentBits, Collection } = require('discord.js');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

// تحميل أوامر السلاش (كل أمر في ملف)
client.commands = new Collection();
for (const file of fs.readdirSync(path.join(__dirname, 'commands')).filter(f => f.endsWith('.js'))) {
  const cmd = require(`./commands/${file}`);
  client.commands.set(cmd.data.name, cmd);
}

// تحميل الأحداث (كل حدث في ملف)
for (const file of fs.readdirSync(path.join(__dirname, 'events')).filter(f => f.endsWith('.js'))) {
  const ev = require(`./events/${file}`);
  client[ev.once ? 'once' : 'on'](ev.name, (...args) => ev.execute(client, ...args));
}

client.login(process.env.TOKEN);

module.exports = {
  name: 'guildCreate',
  async execute(client, guild) {
    const body = [...client.commands.values()].map(c => c.data.toJSON());
    await guild.commands.set(body).catch(() => {});
  },
};

const db = require('../utils/db');
const roulette = require('../games/roulette');

const PREFIX = '÷روليت';

module.exports = {
  name: 'messageCreate',
  async execute(client, message) {
    if (message.author.bot || !message.guild) return;
    if (!message.content.startsWith(PREFIX)) return;

    const s = db.get(message.guild.id);
    if (!s.channelId) return message.reply('❌ | الروليت لسه مش متظبط، استخدم `/setup-roulete` الأول.');
    if (!s.enabled) return message.reply('❌ | الروليت معطل حالياً.');
    if (message.channelId !== s.channelId) return message.reply(`❌ | الروليت بيشتغل بس في <#${s.channelId}>`);

    const text = message.content.slice(PREFIX.length).trim();
    await roulette.start(message, s, text);
  },
};

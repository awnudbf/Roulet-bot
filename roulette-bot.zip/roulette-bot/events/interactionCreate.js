const roulette = require('../games/roulette');

module.exports = {
  name: 'interactionCreate',
  async execute(client, interaction) {
    try {
      if (interaction.isChatInputCommand()) {
        const cmd = client.commands.get(interaction.commandName);
        if (cmd) await cmd.execute(interaction);
      } else if (interaction.isButton() && interaction.customId.startsWith('rl:')) {
        await roulette.handleButton(interaction);
      }
    } catch (e) {
      console.error(e);
      const msg = { content: '❌ حصل خطأ.', ephemeral: true };
      if (interaction.replied || interaction.deferred) interaction.followUp(msg).catch(() => {});
      else interaction.reply(msg).catch(() => {});
    }
  },
};

module.exports = {
  name: 'clientReady',
  once: true,
  async execute(client) {
    console.log(`✅ Logged in as ${client.user.tag}`);
    const body = [...client.commands.values()].map(c => c.data.toJSON());
    for (const guild of client.guilds.cache.values()) {
      await guild.commands.set(body).catch(e => console.log('slash error', guild.id, e.message));
    }
  },
};

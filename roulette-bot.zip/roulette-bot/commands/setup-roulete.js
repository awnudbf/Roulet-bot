const {
  SlashCommandBuilder, PermissionFlagsBits, ChannelType, EmbedBuilder,
} = require('discord.js');
const db = require('../utils/db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setup-roulete')
    .setDescription('إعداد الروليت')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addChannelOption(o => o.setName('channel').setDescription('الروم اللي هيشتغل فيه الروليت')
      .addChannelTypes(ChannelType.GuildText).setRequired(true))
    .addIntegerOption(o => o.setName('time').setDescription('الوقت قبل ما الروليت يبدأ').setRequired(true)
      .addChoices(
        { name: 'دقيقة', value: 60 }, { name: 'دقيقتين', value: 120 },
        { name: '3 دقايق', value: 180 }, { name: '4 دقايق', value: 240 },
        { name: '5 دقايق', value: 300 }))
    .addStringOption(o => o.setName('status').setDescription('تفعيل أو تعطيل').setRequired(true)
      .addChoices({ name: 'تفعيل', value: 'on' }, { name: 'تعطيل', value: 'off' }))
    .addIntegerOption(o => o.setName('max').setDescription('أقصى عدد للمشاركين').setRequired(true)
      .addChoices(
        { name: 'لا نهائي', value: 0 }, { name: '300', value: 300 },
        { name: '50', value: 50 }, { name: '30', value: 30 })),

  async execute(interaction) {
    const channel = interaction.options.getChannel('channel');
    const time = interaction.options.getInteger('time');
    const status = interaction.options.getString('status') === 'on';
    const max = interaction.options.getInteger('max');

    db.set(interaction.guildId, { channelId: channel.id, wait: time, enabled: status, max });

    const embed = new EmbedBuilder()
      .setColor(0x6a00f4)
      .setTitle('✅ تم حفظ إعدادات الروليت')
      .addFields(
        { name: 'الروم', value: `<#${channel.id}>`, inline: true },
        { name: 'الوقت', value: `${time} ثانية`, inline: true },
        { name: 'الحالة', value: status ? 'مفعل ✅' : 'معطل ❌', inline: true },
        { name: 'أقصى عدد', value: max ? String(max) : 'لا نهائي ♾️', inline: true },
      )
      .setFooter({ text: 'By ahmdfc' });

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};

// لعبة الروليت - By ahmdfc
const {
  EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, AttachmentBuilder,
} = require('discord.js');
const img = require('../utils/images');

const COLOR = 0x6a00f4;
const FOOTER = { text: 'By ahmdfc' };
const PICK_TIME = 15; // ثواني لاختيار اللاعب
const PAGE_SIZE = 10;
const games = new Map(); // channelId -> game

const sleep = ms => new Promise(r => setTimeout(r, ms));
const rand = arr => arr[Math.floor(Math.random() * arr.length)];
const maxText = g => (g.max ? String(g.max) : '∞');

/* ---------------- اللوبي (التسجيل) ---------------- */

function lobbyContent(game, ended) {
  const head = ended
    ? '🔒 | انتهى وقت التسجيل، ستبدأ اللعبة الآن.'
    : `⏰ | سيتم بدء الروليت بعد **${game.wait}** ثانية`;
  return `${game.text ? game.text + '\n' : ''}${head}\n**(${game.players.length}/${maxText(game)})**`;
}

function lobbyButtons(game, disabled) {
  return [new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('rl:join').setEmoji('➕').setLabel('دخول').setStyle(ButtonStyle.Secondary).setDisabled(disabled),
    new ButtonBuilder().setCustomId('rl:leave').setEmoji('➖').setLabel('خروج').setStyle(ButtonStyle.Secondary).setDisabled(disabled),
  )];
}

async function start(message, settings, text) {
  const ch = message.channel;
  if (games.has(ch.id)) return message.reply('❌ | في روليت شغال بالفعل في الروم دي.');

  const guild = message.guild;
  const game = {
    channel: ch,
    guildName: guild.name,
    guildIcon: guild.iconURL({ extension: 'png', size: 256 }),
    max: settings.max,
    wait: settings.wait,
    startAt: Math.floor(Date.now() / 1000) + settings.wait,
    text,
    players: [],
    alive: [],
    started: false,
    lobbyMsg: null,
  };
  games.set(ch.id, game);

  const bannerFile = new AttachmentBuilder(img.banner(), { name: 'roulette.png' });
  game.lobbyMsg = await ch.send({
    content: lobbyContent(game, false),
    components: lobbyButtons(game, false),
    files: [bannerFile],
    allowedMentions: { parse: ['users', 'roles', 'everyone'] },
  });

  game.timer = setTimeout(() => run(game).catch(e => { console.error(e); games.delete(ch.id); }), settings.wait * 1000);
}

/* ---------------- تشغيل اللعبة ---------------- */

async function run(game) {
  const ch = game.channel;
  game.started = true;

  if (game.players.length < 2) {
    await game.lobbyMsg.edit({ content: lobbyContent(game, true), components: lobbyButtons(game, true) }).catch(() => {});
    await ch.send('❌ | تم إلغاء الروليت لأن العدد أقل من لاعبين.');
    games.delete(ch.id);
    return;
  }

  game.players.forEach((p, i) => { p.num = i + 1; p.hasShield = true; p.shieldOn = false; });
  game.alive = [...game.players];

  await game.lobbyMsg.edit({ content: lobbyContent(game, true), components: lobbyButtons(game, true) }).catch(() => {});
  await ch.send('✅ | تم الانتهاء من تسجيل الادوار ، ستبدأ الجولة الاولى بعد قليل...');
  await sleep(4000);

  while (game.alive.length > 1) {
    const chooser = rand(game.alive);
    game.chooser = chooser;
    game.page = 0;

    const buf = await img.wheel(game.alive.map(p => p.name), game.alive.indexOf(chooser), game.guildIcon);
    await ch.send({
      embeds: [new EmbedBuilder()
        .setColor(COLOR)
        .setAuthor({ name: game.guildName, iconURL: game.guildIcon || undefined })
        .setDescription(`**${chooser.num} - <@${chooser.id}>**`)
        .setThumbnail(chooser.avatar)
        .setImage('attachment://wheel.png')
        .setFooter(FOOTER)],
      files: [new AttachmentBuilder(buf, { name: 'wheel.png' })],
    });

    const msg = await ch.send({
      content: `🕘 | <@${chooser.id}> ، لديك **${PICK_TIME}** ثانية لاختيار لاعب لطرده.`,
      components: pickComponents(game),
    });
    game.pickMsg = msg;

    const result = await new Promise(resolve => {
      game.resolve = resolve;
      game.pickTimer = setTimeout(() => resolve({ type: 'random' }), PICK_TIME * 1000);
    });
    clearTimeout(game.pickTimer);
    game.resolve = null;

    let line;
    if (result.type === 'out') {
      game.alive = game.alive.filter(p => p.id !== chooser.id);
      line = `🚪 | انسحب <@${chooser.id}> من اللعبة، ستبدأ الجولة التالية بعد قليل...`;
    } else {
      const others = game.alive.filter(p => p.id !== chooser.id);
      const target = result.type === 'pick' ? game.alive.find(p => p.id === result.id) : rand(others);
      if (target.shieldOn) {
        target.shieldOn = false;
        target.hasShield = false;
        line = `🛡️ | درع <@${target.id}> حماه من الطرد! ستبدأ الجولة التالية بعد قليل...`;
      } else {
        game.alive = game.alive.filter(p => p.id !== target.id);
        line = result.type === 'pick'
          ? `🔪 | قام <@${chooser.id}> بطرد <@${target.id}> من اللعبة، ستبدأ الجولة التالية بعد قليل...`
          : `🎲 | تم طرد <@${target.id}> بشكل عشوائي من اللعبة، ستبدأ الجولة التالية بعد قليل...`;
      }
    }

    await msg.edit({ content: line, components: [] }).catch(() => {});
    await sleep(4000);
  }

  const winner = game.alive[0];
  if (winner) {
    await ch.send({
      content: `<@${winner.id}>`,
      embeds: [new EmbedBuilder()
        .setColor(0xffc107)
        .setAuthor({ name: game.guildName, iconURL: game.guildIcon || undefined })
        .setTitle('🏆 الفائز في الروليت')
        .setDescription(`مبروك <@${winner.id}> ، انت آخر لاعب متبقي! 🎉`)
        .setThumbnail(winner.avatar)
        .setFooter(FOOTER)],
    });
  }
  games.delete(ch.id);
}

/* ---------------- أزرار اختيار اللاعب ---------------- */

function pickComponents(game) {
  const { alive, chooser } = game;
  const pages = Math.max(1, Math.ceil(alive.length / PAGE_SIZE));
  const slice = alive.slice(game.page * PAGE_SIZE, (game.page + 1) * PAGE_SIZE);

  const rows = [];
  for (let i = 0; i < slice.length; i += 5) {
    rows.push(new ActionRowBuilder().addComponents(
      slice.slice(i, i + 5).map(p => new ButtonBuilder()
        .setCustomId(`rl:pick:${p.id}`)
        .setLabel(`${p.num} ${p.name}`.slice(0, 80))
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(p.id === chooser.id)),
    ));
  }

  if (pages > 1) {
    rows.push(new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`rl:page:${game.page - 1}`).setEmoji('⬅️').setLabel('الصفحة السابقة')
        .setStyle(ButtonStyle.Secondary).setDisabled(game.page === 0),
      new ButtonBuilder().setCustomId(`rl:page:${game.page + 1}`).setEmoji('➡️').setLabel('الصفحة التالية')
        .setStyle(ButtonStyle.Secondary).setDisabled(game.page >= pages - 1),
    ));
  }

  rows.push(new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('rl:rand').setEmoji('🎲').setLabel('طرد عشوائي').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('rl:out').setEmoji('🚪').setLabel('انسحاب').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('rl:bag').setEmoji('🎒').setLabel('حقيبتي').setStyle(ButtonStyle.Secondary),
  ));
  return rows;
}

/* ---------------- التعامل مع كل الأزرار ---------------- */

async function handleButton(i) {
  const game = games.get(i.channelId);
  const [, action, arg] = i.customId.split(':');
  const eph = content => i.reply({ content, ephemeral: true });

  if (!game) return eph('❌ | مفيش روليت شغال دلوقتي.');

  // ---- مرحلة التسجيل ----
  if (action === 'join') {
    if (game.started) return eph('❌ | التسجيل انتهى.');
    if (game.players.some(p => p.id === i.user.id)) return eph('⚠️ | انت مسجل بالفعل.');
    if (game.max && game.players.length >= game.max) return eph('❌ | العدد اكتمل.');
    game.players.push({
      id: i.user.id,
      name: i.user.username,
      avatar: i.user.displayAvatarURL({ extension: 'png', size: 256 }),
    });
    return i.update({ content: lobbyContent(game, false), components: lobbyButtons(game, false) });
  }

  if (action === 'leave') {
    if (game.started) return eph('❌ | التسجيل انتهى.');
    if (!game.players.some(p => p.id === i.user.id)) return eph('⚠️ | انت مش مسجل.');
    game.players = game.players.filter(p => p.id !== i.user.id);
    return i.update({ content: lobbyContent(game, false), components: lobbyButtons(game, false) });
  }

  if (action === 'bag') {
    const me = game.players.find(p => p.id === i.user.id);
    if (!me) return eph('⚠️ | انت مش مشارك في اللعبة.');
    if (!game.started) return eph('🎒 | الحقيبة بتتفتح بعد ما اللعبة تبدأ.');
    if (!me.hasShield) return eph('🎒 | حقيبتك فاضية.');
    if (!game.alive.some(p => p.id === me.id)) return eph('❌ | انت خرجت من اللعبة.');
    return i.reply({
      content: me.shieldOn ? '🛡️ | الدرع شغال بالفعل عليك.' : '🎒 | حقيبتك فيها: 🛡️ **درع** (بيحميك من طردة واحدة).',
      components: me.shieldOn ? [] : [new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('rl:shield').setEmoji('🛡️').setLabel('استخدام الدرع').setStyle(ButtonStyle.Primary))],
      ephemeral: true,
    });
  }

  if (action === 'shield') {
    const me = game.alive.find(p => p.id === i.user.id);
    if (!me || !me.hasShield) return i.update({ content: '❌ | مفيش درع.', components: [] });
    me.shieldOn = true;
    return i.update({ content: '🛡️ | تم تفعيل الدرع، هيحميك من أول طردة.', components: [] });
  }

  if (action === 'count') return i.deferUpdate();

  // ---- مرحلة اللعب: للاعب المختار فقط ----
  if (!game.started || !game.chooser || !game.resolve) return eph('❌ | مش وقت الاختيار.');
  if (i.user.id !== game.chooser.id) return eph('❌ | الاختيار مش ليك، استنى دورك.');

  if (action === 'page') {
    game.page = Number(arg);
    return i.update({ components: pickComponents(game) });
  }
  if (action === 'pick') {
    if (arg === i.user.id) return eph('❌ | مينفعش تطرد نفسك.');
    await i.deferUpdate();
    return game.resolve({ type: 'pick', id: arg });
  }
  if (action === 'rand') { await i.deferUpdate(); return game.resolve({ type: 'random' }); }
  if (action === 'out') { await i.deferUpdate(); return game.resolve({ type: 'out' }); }
}

module.exports = { start, handleButton };

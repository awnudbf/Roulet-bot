# Roulette Bot — By ahmdfc

1. `npm install`
2. انسخ `.env.example` إلى `.env` وحط التوكن
3. فعّل **Message Content Intent** من Developer Portal
4. `npm start`
5. في السيرفر: `/setup-roulete` ثم اكتب `÷روليت رسالتك @منشن`

لو عاوز بانر مخصص حط صورة اسمها `banner.png` في فولدر `assets`.

// ============================================================
//  الشكل الجديد للإيمبد والأزرار  |  By Venlook x Ahmdfc
//  يتطبق تلقائياً على كل الإيمبدات والأزرار في البوت
//  - الإيمبدات تتحول تلقائياً إلى Components V2 (Container)
//  - الأزرار الرمادية تبقى رمادية
// ============================================================
const { EmbedBuilder, ButtonBuilder, ButtonStyle, MessagePayload } = require('discord.js');
let config = {};
try { config = require('./config.json'); } catch {}

const CREDIT = 'By Venlook x Ahmdfc';
const MARK = '✦';
const V2_FLAG = 1 << 15; // IS_COMPONENTS_V2 = 32768

const THEME = {
  main:    0x7C5CFF, // بنفسجي أساسي
  success: 0x2ECC9A, // أخضر
  danger:  0xFF4D6D, // أحمر
  warning: 0xFFB84D, // ذهبي
};

// معلومات البوت (تنحط عند تشغيل البوت)
let bot = { name: null, avatar: null };
function setBot(user) {
  if (!user || bot.name) return;
  bot = { name: user.username, avatar: user.displayAvatarURL({ extension: 'png', size: 128 }) };
}

const isUrl = u => typeof u === 'string' && /^https?:\/\//.test(u);

// تحويل أي لون قديم إلى لون من الثيم الجديد
function mapColor(c) {
  try {
    let n = c;
    if (typeof c === 'string') {
      const k = c.toLowerCase().replace('#', '');
      const names = { red: 'ff0000', green: '00ff00', yellow: 'ffff00', grey: '888888', gray: '888888' };
      n = parseInt(names[k] || k, 16);
    }
    if (typeof n !== 'number' || Number.isNaN(n)) return THEME.main;
    const r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
    if (r > 180 && g < 100 && b < 100) return THEME.danger;
    if (g > 180 && r < 120)           return THEME.success;
    if (r > 200 && g > 200 && b < 120) return THEME.warning;
    return THEME.main;
  } catch { return THEME.main; }
}

const origSetColor = EmbedBuilder.prototype.setColor;
EmbedBuilder.prototype.setColor = function (color) {
  return origSetColor.call(this, color == null ? color : mapColor(color));
};

// ---------- تصميم الإيمبد (البيانات) ----------
const origToJSON = EmbedBuilder.prototype.toJSON;
EmbedBuilder.prototype.toJSON = function () {
  const d = { ...origToJSON.call(this) };

  if (d.color === undefined) d.color = THEME.main;
  if (!d.timestamp) d.timestamp = new Date().toISOString();

  // 1) سطر علوي باسم البوت وصورته
  if (!d.author && bot.name) d.author = { name: bot.name, icon_url: bot.avatar };

  // 2) العنوان
  if (d.title && !d.title.startsWith(MARK) && d.title.length < 250) d.title = `${MARK} ${d.title}`;

  // 3) الوصف كاقتباس (خط جانبي ملون)
  if (d.description && !d.description.includes('```') && !d.description.trimStart().startsWith('>')) {
    const lines = d.description.split('\n');
    const quoted = lines.map(l => (l.trim() === '' ? l : `> ${l}`)).join('\n');
    if (quoted.length <= 4000) d.description = quoted;
  }

  // 4) صورة البوت مصغرة إذا ما فيه صورة مصغرة
  if (!d.thumbnail && !d.image && bot.avatar) d.thumbnail = { url: bot.avatar };

  // 6) الفوتر
  const text = d.footer && d.footer.text;
  if (!text) d.footer = { ...(d.footer || {}), text: CREDIT };
  else if (!text.includes(CREDIT)) d.footer = { ...d.footer, text: `${text}  •  ${CREDIT}` };
  if (d.footer && !d.footer.icon_url && bot.avatar) d.footer.icon_url = bot.avatar;

  return d;
};

// ---------- تحويل الإيمبد إلى Components V2 ----------
const text = content => ({ type: 10, content: content && String(content).length ? String(content) : '\u200b' });

function embedToContainer(e) {
  const data = typeof e.toJSON === 'function' ? e.toJSON() : e;

  // النصوص الأساسية (الكاتب، العنوان، الوصف، الحقول)
  const texts = [];
  if (data.author && data.author.name) texts.push(`-# ${data.author.name}`);
  if (data.title) texts.push(`### ${data.title}`);
  if (data.url && !data.title) texts.push(data.url);
  if (data.description) texts.push(data.description);
  if (data.fields && data.fields.length) {
    texts.push(data.fields.map(f => `**${f.name}**\n${f.value}`).join('\n\n'));
  }

  const children = [];
  const thumbUrl = data.thumbnail && data.thumbnail.url;

  if (thumbUrl && texts.length) {
    // الصورة المصغرة تطلع يمين النص (صغيرة مثل الإيمبد)
    children.push({
      type: 9,
      components: [text(texts.join('\n\n'))],
      accessory: { type: 11, media: { url: thumbUrl } },
    });
  } else {
    texts.forEach(t => children.push(text(t)));
  }

  if (data.image && data.image.url) {
    children.push({ type: 12, items: [{ media: { url: data.image.url } }] });
  }

  if (data.footer && data.footer.text) {
    children.push({ type: 14, spacing: 1, divider: true });
    children.push(text(`-# ${data.footer.text}`));
  }

  if (!children.length) children.push(text('\u200b'));

  return {
    type: 17,
    accent_color: typeof data.color === 'number' ? data.color : THEME.main,
    components: children,
  };
}

// يحول body الرسالة من إيمبدات إلى V2 (يبقى الإيمبد كما هو إذا فيه ملفات أو poll)
function toV2Body(body) {
  if (!body || !Array.isArray(body.embeds) || body.embeds.length === 0) return body;
  if ((body.files && body.files.length) || body.poll) return body;
  if (body.flags & V2_FLAG) return body;

  const top = [];
  if (body.content) top.push(text(body.content));
  for (const e of body.embeds) top.push(embedToContainer(e));

  const rest = (body.components || []).map(c => (c && typeof c.toJSON === 'function' ? c.toJSON() : c));

  body.components = [...top, ...rest];
  delete body.content;
  delete body.embeds;
  body.flags = (body.flags || 0) | V2_FLAG;
  return body;
}

// نربط التحويل بكل عمليات الإرسال والتعديل (send / reply / edit / followUp ...)
if (MessagePayload && MessagePayload.prototype && MessagePayload.prototype.resolveBody) {
  const origResolveBody = MessagePayload.prototype.resolveBody;
  MessagePayload.prototype.resolveBody = function () {
    const result = origResolveBody.call(this);
    try { if (result && result.body) result.body = toV2Body(result.body); } catch {}
    return result;
  };
}

// ---------- الأزرار ----------
// الأزرار الرمادية تبقى رمادية (Secondary)، ما نغيّرها لأي لون ثاني

module.exports = { THEME, CREDIT, setBot };

const express = require('express')
const app = express()
 const port = 6239

app.get('/', (req, res) => {
  res.send('Hello World!')
})
const fs = require('fs');
const path = require('path');

const { Events } = require('discord.js');

const { Client, GatewayIntentBits, Collection, REST, Routes, ApplicationCommandOptionType, EmbedBuilder, ChannelType, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits, AttachmentBuilder, StringSelectMenuBuilder, PermissionsBitField, ActivityType, Partials, WebhookClient, ContainerBuilder, MessageFlags, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize   } = require('discord.js')
require('./style.js'); // الشكل الجديد | By Venlook x Ahmdfc
const {ModalBuilder} = require("discord.js");
const {TextInputBuilder} = require("discord.js");
const {MessageEmbed} = require("discord.js");
const {ComponentType} = require("discord.js") 
const {TextInputStyle} = require("discord.js");
const {MessageButton} = require("discord.js");
const {MessageActionRow} = require("discord.js");
const { getAudioUrl } = require('google-tts-api');
const googleTTS = require('google-tts-api');
const sharp = require('sharp');
const {MessageSelectMenu} = require("discord.js");
const akinator = require('akinator');
const {SelectMenuBuilder} = require("discord.js");
const chalk = require('chalk')
const ms = require('ms')
let CronJob = require('cron').CronJob;
//
const { QuickDB, JSONDriver } = require("quick.db");
const jsonDriver = new JSONDriver();
const db = QuickDB.createSingleton({ driver: jsonDriver });

const config = require('./config.json');
const botTokens = config.tokens;  

// ============================================================
//  تخزين الصور (الخط / صور التكتات) جوه الاستضافة عشان ما تروح
//  لينكات ديسكورد بتنتهي بعد فترة، فالبوت بيحفظ نسخة محلية
//  وبيرفعها في روم اللوجات وبيجدد اللينك تلقائي.
//  لو غيرت صورة، القديمة بتتمسح (الملف + الرسالة) وتتحط الجديدة.
// ============================================================
const IMG_DIR = path.join(__dirname, 'saved_images');
const IMG_META_FILE = path.join(IMG_DIR, 'meta.json');
try { fs.mkdirSync(IMG_DIR, { recursive: true }); } catch (_) {}
let imgMeta = {};
try { imgMeta = JSON.parse(fs.readFileSync(IMG_META_FILE, 'utf8')); } catch (_) { imgMeta = {}; }
const saveImgMeta = () => { try { fs.writeFileSync(IMG_META_FILE, JSON.stringify(imgMeta, null, 2)); } catch (_) {} };
const IMAGE_KEY_RE = /^(image|buyshopimage|buyorderimage|buyauctionimage|priceImage)_\d+$/;
const IMG_REFRESH_MS = 6 * 60 * 60 * 1000;
const imgCache = new Map();
let storageClient = null;

function imgExt(type, url) {
  const t = (type || '').toLowerCase();
  if (t.includes('png')) return 'png';
  if (t.includes('jpeg') || t.includes('jpg')) return 'jpg';
  if (t.includes('gif')) return 'gif';
  if (t.includes('webp')) return 'webp';
  const m = /\.(png|jpe?g|gif|webp)(\?|$)/i.exec(url || '');
  return m ? m[1].toLowerCase().replace('jpeg', 'jpg') : 'png';
}

async function getStorageChannel() {
  if (!storageClient) return null;
  const id = Array.isArray(config.logs) ? config.logs[0] : config.logs;
  if (!id) return null;
  return await storageClient.channels.fetch(String(id)).catch(() => null);
}

async function deleteStoredMessage(meta) {
  if (!meta || !meta.channelId || !meta.messageId || !storageClient) return;
  try {
    const ch = await storageClient.channels.fetch(meta.channelId);
    const msg = await ch.messages.fetch(meta.messageId);
    await msg.delete();
  } catch (_) {}
}

async function uploadStoredImage(key) {
  const meta = imgMeta[key];
  if (!meta || !meta.file) return null;
  const ch = await getStorageChannel();
  if (!ch) return null;
  const filePath = path.join(IMG_DIR, meta.file);
  if (!fs.existsSync(filePath)) return null;
  const msg = await ch.send({ files: [new AttachmentBuilder(filePath, { name: meta.file })] });
  meta.channelId = ch.id;
  meta.messageId = msg.id;
  saveImgMeta();
  const url = msg.attachments.first()?.url || null;
  if (url) imgCache.set(key, { url, at: Date.now() });
  return url;
}

// تنزيل الصورة وحفظها محلياً (وحذف القديمة لو اتغيرت)
async function storeImage(key, url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`download failed ${res.status}`);
  const buf = Buffer.from(await res.arrayBuffer());
  const ext = imgExt(res.headers.get('content-type'), url);
  const file = `${key}.${ext}`;
  const old = imgMeta[key];
  if (old) {
    if (old.file && old.file !== file) { try { fs.unlinkSync(path.join(IMG_DIR, old.file)); } catch (_) {} }
    await deleteStoredMessage(old);
  }
  fs.writeFileSync(path.join(IMG_DIR, file), buf);
  imgMeta[key] = { file };
  imgCache.delete(key);
  saveImgMeta();
  await uploadStoredImage(key).catch((e) => console.error('image upload failed:', e.message));
}

// لينك طازج للصورة المحفوظة (بيتجدد كل 6 ساعات)
async function freshImageUrl(key, fallback) {
  const meta = imgMeta[key];
  if (!meta || !meta.file) return fallback;
  const cached = imgCache.get(key);
  if (cached && Date.now() - cached.at < IMG_REFRESH_MS) return cached.url;
  try {
    if (meta.channelId && meta.messageId && storageClient) {
      const ch = await storageClient.channels.fetch(meta.channelId);
      const msg = await ch.messages.fetch(meta.messageId);
      const url = msg.attachments.first()?.url;
      if (url) { imgCache.set(key, { url, at: Date.now() }); return url; }
    }
  } catch (_) {}
  try {
    const url = await uploadStoredImage(key);
    if (url) return url;
  } catch (_) {}
  return fallback;
}

const _dbGet = db.get.bind(db);
const _dbSet = db.set.bind(db);
db.get = async (key, ...rest) => {
  const v = await _dbGet(key, ...rest);
  if (typeof key === 'string' && v && typeof v === 'string' && IMAGE_KEY_RE.test(key)) {
    return await freshImageUrl(key, v);
  }
  return v;
};
db.set = async (key, value, ...rest) => {
  if (typeof key === 'string' && typeof value === 'string' && /^https?:\/\//i.test(value) && IMAGE_KEY_RE.test(key)) {
    try { await storeImage(key, value); } catch (e) { console.error('storeImage error:', e.message); }
  }
  return _dbSet(key, value, ...rest);
};


const bots = botTokens.map((token, index) => {
 const client = new Client({
//intents: 3276799,
    intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildEmojisAndStickers,
    GatewayIntentBits.GuildIntegrations,
    GatewayIntentBits.GuildWebhooks,
    GatewayIntentBits.GuildInvites,
    GatewayIntentBits.GuildVoiceStates,
GatewayIntentBits.GuildPresences,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildMessageTyping,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.DirectMessageReactions,
    GatewayIntentBits.DirectMessageTyping,
    GatewayIntentBits.MessageContent
  ],
  partials: [
    Partials.Message,
    Partials.Channel,
    Partials.GuildMember,
    Partials.Reaction,
    Partials.GuildScheduledEvent,
    Partials.User,
    Partials.ThreadMember
  ],

})
const types = require('./types.js')
const typesPath = path.join(__dirname, 'types.js');

client.types = types;

function choices() {
  const ch = [];
  for (const t of types) {
    ch.push({
      name: t.nametype,
      value: t.categoryId
    });
  }
  return ch;  
}

const chsd = choices();
client.commands1 = new Collection();
    
const botOwner = config.ownerId;
const allowedUserId = `${botOwner}`; 
const owner = `${botOwner}`;
const TARGET_ROLE_ID = "1384831324015296614";
const TARGET_CHANNEL_ID = "1327597784215584869";
const logJoinChannel = '1403091074083197089';
const allowedBotId = config.mainBotId;
const prefix = '+';
const TARGET_GUILD_ID = "1384831324015296614";
        const reportsChannelId = '1403092773137158175'; // ضع هنا معرف قناة البلاغات
        const reportsGuildId = '1384831324015296614'; // ضع هنا معرف السيرفر المحدد



client.on('messageCreate', async (message) => {
  if (message.author.bot) return;

  const guildId = message.guild.id;
  const keywords = await db.all();
  const guildKeywords = keywords.filter(entry => entry.id.startsWith(`autoreply_${guildId}_`));

  guildKeywords.forEach(entry => {
    const keyword = entry.id.split(`autoreply_${guildId}_`)[1];
    const data = entry.value;

    if (message.content === keyword) {
      const { reply, role, channel, embed, title, image, color } = data;

      // تحقق من الرتبة (إذا كانت موجودة)
      if (role && !message.member.roles.cache.has(role)) return;

      // تحقق من الروم (إذا كانت موجودة)
      if (channel && message.channel.id !== channel) return;

      // إرسال الرد
      if (embed) {
        const embedMessage = {
          title: title || null,
          description: reply,
          color: color ? parseInt(color.replace('#', ''), 16) : null,
          image: image ? { url: image } : null,
        };
        message.channel.send({ embeds: [embedMessage] });
      } else if (image) {
        // إذا لم يتم تحديد إيمبد ولكن تم تحديد صورة
        message.channel.send({ content: reply, files: [image] });
      } else {
        message.channel.send(reply);
      }
    }
  });
});

// استجابة زر عرض تفاصيل الرد

// ===== أمر ticket-panel: بانل ثابت (طلب / مزاد / متجر / دعم فني) =====
const TP_PERMS = [
  PermissionFlagsBits.ViewChannel,
  PermissionFlagsBits.SendMessages,
  PermissionFlagsBits.ReadMessageHistory,
  PermissionFlagsBits.AttachFiles,
];

client.on('interactionCreate', async (i) => {
  try {
    // 1) إرسال البانل
    if (i.isChatInputCommand() && i.commandName === 'ticket-panel') {
      if (!i.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
        return i.reply({ content: '**🚫 هذا الأمر للإدارة فقط.**', ephemeral: true });
      }
      const embed = new EmbedBuilder()
        .setTitle(i.options.getString('title') || 'قسم التذاكر')
        .setFooter({ text: 'By Venlook x Ahmdfc' });
      const desc = i.options.getString('description');
      if (desc) embed.setDescription(desc);

      const menu = new StringSelectMenuBuilder()
        .setCustomId('tp_panel_select')
        .setPlaceholder('اختر نوع التذكرة')
        .addOptions(
          { label: 'شراء طلب', emoji: '🛒', value: 'order' },
          { label: 'شراء مزاد', emoji: '🔨', value: 'auction' },
          { label: 'شراء متجر', emoji: '🏪', value: 'shop' },
          { label: 'تكت الدعم الفني', emoji: '🛠️', value: 'support' },
        );

      await i.channel.send({ embeds: [embed], components: [new ActionRowBuilder().addComponents(menu)] });
      return i.reply({ content: 'تم إرسال البانل ✅', ephemeral: true });
    }

    // 2) تذكرة الدعم الفني
    if (i.isStringSelectMenu() && i.customId === 'tp_panel_select' && i.values[0] === 'support') {
      const open = i.guild.channels.cache.find(c => c.topic === `tp:${i.user.id}`);
      if (open) {
        return i.reply({ content: `عندك تذكرة مفتوحة بالفعل: <#${open.id}>`, ephemeral: true });
      }

      const supportRoleId = config.Spportadmins;
      const hasRole = !!supportRoleId && i.guild.roles.cache.has(supportRoleId);
      const catId = config.Supportcat && i.guild.channels.cache.has(config.Supportcat) ? config.Supportcat : null;

      const overwrites = [
        { id: i.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
        { id: i.user.id, allow: TP_PERMS },
        { id: client.user.id, allow: [...TP_PERMS, PermissionFlagsBits.ManageChannels] },
      ];
      if (hasRole) overwrites.push({ id: supportRoleId, allow: TP_PERMS });

      const channel = await i.guild.channels.create({
        name: `support-${i.user.username}`.slice(0, 90),
        type: ChannelType.GuildText,
        parent: catId,
        topic: `tp:${i.user.id}`,
        permissionOverwrites: overwrites,
      });

      await channel.send({
        content: `${hasRole ? `<@&${supportRoleId}> ` : ''}<@${i.user.id}>`,
        embeds: [
          new EmbedBuilder()
            .setTitle('تكت الدعم الفني')
            .setDescription(`مرحبا <@${i.user.id}>، اكتب مشكلتك هنا وبيرد عليك فريق الدعم.`),
        ],
        components: [
          new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('tp_close').setLabel('إغلاق التذكرة').setStyle(ButtonStyle.Danger)
          ),
        ],
        allowedMentions: { roles: hasRole ? [supportRoleId] : [], users: [i.user.id] },
      });
      return i.reply({ content: `تم إنشاء تذكرتك: <#${channel.id}>`, ephemeral: true });
    }

    // 3) زر إغلاق تذكرة الدعم
    if (i.isButton() && i.customId === 'tp_close') {
      const isOpener = i.channel?.topic === `tp:${i.user.id}`;
      const isStaff = i.memberPermissions?.has(PermissionFlagsBits.ManageChannels);
      if (!isOpener && !isStaff) {
        return i.reply({ content: 'ما تقدر تقفل هذي التذكرة.', ephemeral: true });
      }
      await i.reply({ content: 'سيتم قفل التذكرة بعد 5 ثواني...' });
      setTimeout(() => i.channel.delete().catch(() => {}), 5000);
    }
  } catch (err) {
    console.error('ticket-panel error:', err);
  }
});

// ===== توجيه القوائم للتذاكر الأصلية =====
// كل اختيار يتحول لنفس customId الزر القديم، فالهاندلر الأصلي يشتغل بدون تعديل
client.on('interactionCreate', (i) => {
  if (!i.isStringSelectMenu()) return;
  let target = null;
  if (['buy_panel_select', 'shop_type_select', 'shop_create_select', 'shop_typedata_select'].includes(i.customId)) {
    target = i.values[0];
  } else if (i.customId === 'tp_panel_select') {
    target = { order: 'order', auction: 'ticket-auction', shop: 'buy_shop' }[i.values[0]] || null;
  }
  if (!target) return;
  i.customId = target;
  i.isButton = () => true;
});

client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;

  const [action, index] = interaction.customId.split('_');
  if (action !== 'view-autoreply') return;

  const guildId = interaction.guild.id;
  const keywords = await db.all();
  const guildKeywords = keywords.filter(entry => entry.id.startsWith(`autoreply_${guildId}_`));
  const selectedEntry = guildKeywords[parseInt(index)];
  if (!selectedEntry) return interaction.reply('الرد غير موجود.', { ephemeral: true });

  const keyword = selectedEntry.id.split(`autoreply_${guildId}_`)[1];
  const { reply, role, channel, embed, title, image, color } = selectedEntry.value;

  const detailsEmbed = new EmbedBuilder()
    .setTitle(`تفاصيل الرد التلقائي - ${keyword}`)
    .addFields(
      { name: 'الرد', value: reply },
      { name: 'رتبة محددة', value: role ? `<@&${role}>` : 'لا يوجد', inline: true },
      { name: 'روم محدد', value: channel ? `<#${channel}>` : 'لا يوجد', inline: true },
      { name: 'نوع الرد', value: embed ? 'إيمبد' : 'نص عادي', inline: true }
    );

  if (embed && title) detailsEmbed.setTitle(title);
  if (embed && image) detailsEmbed.setImage(image);
  if (embed && color) detailsEmbed.setColor(color);

  interaction.reply({ embeds: [detailsEmbed], ephemeral: true });
});

/*
client.on("ready", async () => {
    if (!storageClient) storageClient = client;
    console.log(`Logged in as ${client.user.tag}`);

    function formatNumber(number) {
        return number >= 1000 ? `${(number / 1000).toFixed(1)}k` : number.toString();
    }

    async function updatePresence() {
        // جلب عدد السيرفرات والأعضاء
        const totalServers = client.guilds.cache.size;
        const totalMembers = client.guilds.cache.reduce((acc, guild) => acc + guild.memberCount, 0);

        // جلب عدد المتاجر من قاعدة البيانات
        const allEntries = await db.all(); // جلب جميع البيانات
        const totalShops = allEntries.filter(entry => entry.id.startsWith('shop_')).length;

        // إنشاء رسائل الحالة
        const presenceMessages = [
            { name: `+help`, type: 0 },
            { name: `${formatNumber(totalServers)} servers | ${formatNumber(totalMembers)} members`, type: 0 },
            { name: `${formatNumber(totalShops)} shops`, type: 0 }
        ];

        // اختيار رسالة عشوائية
        const randomPresence = presenceMessages[Math.floor(Math.random() * presenceMessages.length)];

        // تحديث حالة البوت
        client.user.setPresence({
            activities: [randomPresence],
            status: 'idle'
        });
    }

    // تحديث الحالة في البداية
    updatePresence();

    // تحديث الحالة كل 15 ثانية
    setInterval(updatePresence, 15000);
});
    */
client.on('ready', async () => {
    require('./style.js').setBot(client.user); // معلومات البوت للشكل الجديد
    console.log(chalk.bold.underline.blue(`✅ Bot ${index + 1} logged in as ${client.user.tag}`));



    const restrictedCommands = [

        {
            name: 'add-token',
            description: 'لإضافة توكن',
            dm_permission: false,
            default_member_permissions: 8,
            options: [
                {
                    name: 'token',
                    description: 'التوكن الذي تريد إضافته',
                    type: ApplicationCommandOptionType.String,
                    required: true
                }
            ]
        },
        {
            name: 'remove-token',
            description: 'لحذف توكن',
            dm_permission: false,
            default_member_permissions: 8,
            options: [
                {
                    name: 'token',
                    description: 'التوكن الذي تريد حذفه',
                    type: ApplicationCommandOptionType.String,
                    required: true
                }
            ]
        },
        {
            name: 'panel',
            description: 'لـ ارسال البانل',
            dm_permission: false,
            default_member_permissions: 8,
        },
        {
            name: 'status',
            description: 'لـ ارسال البانل الحــالة',
            dm_permission: false,
            default_member_permissions: 8,
        },
 {
    name: 'set-activity',
    dm_permission: false,
    default_member_permissions: 8,
    description: 'تغيير حالة البوت',
    options: [
      {
        name: 'activity',
        description: 'النص الذي تريد عرضه',
        type: ApplicationCommandOptionType.String,
        required: true,
      },
      {
        name: 'type',
        description: 'نوع الحالة (0 = Playing, 1 = Streaming, 2 = Listening, 3 = Watching)',
        type: ApplicationCommandOptionType.Number,
        required: false,
      },
      {
        name: 'presence',
        description: 'حالة الاتصال (online, idle, dnd, invisible)',
        type: ApplicationCommandOptionType.String,
        required: false,
        choices: [
          { name: '🟢 Online', value: 'online' },
          { name: '🟡 Idle', value: 'idle' },
          { name: '🔴 Do Not Disturb', value: 'dnd' },
         
        ],
      },
    ],
  },

  {
    name: 'set-username',
    dm_permission: false,
    default_member_permissions: 8,
    description: 'تغيير اسم البوت',
    options: [
      {
        name: 'username',
        description: 'الاسم الجديد للبوت',
        type: ApplicationCommandOptionType.String,
        required: true,
      },
    ],
  },

{
    name: 'bot-avatar',
    description: 'تغيير صورة البوت والبنر',
    dm_permission: false,
    default_member_permissions: 8,
    options: [
        {
            name: 'imge',
            description: 'صورة البوت الجديدة',
            type: ApplicationCommandOptionType.Attachment,
            required: true,
        },
        {
            name: 'banner',
            description: 'بنر البوت الجديد (اختياري)',
            type: ApplicationCommandOptionType.Attachment,
            required: false, // ليس إلزاميًا
        },
    ],
}
    ];

//    const rest = new REST({ version: 10 }).setToken(token);
async function updateTypesAndCommands(typesData) {
    client.types = typesData;
    const updatedChoices = client.types.map(t => ({ name: t.name, value: t.id }));
    
    // يجب تحديث chsd إذا كانت تستخدم في الأوامر
     chsd = updatedChoices;
}

    const globalCommands = [
{
  name: "report",
  description: "لـــ ارســال بلاغ لـ صاحب البــوت",
  dm_permission: false,
  default_member_permissions: 1, 
  options: [
{
          name: 'details',
          description: `تفــاصيل البلاغ`,
          type: ApplicationCommandOptionType.String,
          required: true,      
},
      ],
},
{ 
    name: 'fake-tweet', 
    description: 'لـ انشاء تغريــدة مزيــفة',
    dm_permission: true,
    default_member_permissions: 1,
    options: [        
      {
      name: 'tweet',
      description:  'التغريدة',
      type: ApplicationCommandOptionType.String, 
      required: true
    },
    {
      name: 'user',
      description: 'الشخص',
      type: ApplicationCommandOptionType.User,
      required: false,
    }     
    ] 
   },
  { 
    name: 'fake-comment', 
    description: 'لـ انشاء تعــليق يوتيوب مزيــف',
    dm_permission: true,
    default_member_permissions: 1,
    options: [        
      {
      name: 'comment',
      description:  'التعليق',
      type: ApplicationCommandOptionType.String, 
      required: true
    },
    {
      name: 'user',
      description: 'الشخص',
      type: ApplicationCommandOptionType.User,
      required: false,
    }     
    ] 
   },

  { 
    name: 'tax', 
    description: 'لـمـعـرفـه الـضـريـبـه لـعـدد مـا',
    dm_permission: false,
    default_member_permissions: 1,
    options: [        
      {
      name: 'number',
      description:  'الـعـدد',
      type: ApplicationCommandOptionType.String, 
      required: true
    }     
    ] 
   },        
{
      name: 'add-tax-channel',
      description: ' اضـافـة روم لـ رومـات الضـرائـب ',
      dm_permission: false,
      default_member_permissions: 1,
      options: [
        {
          name: `channel`,
          description: ` الـروم `,
          type: ApplicationCommandOptionType.Channel,
          required: true,
          channel_types: [ChannelType.GuildText]
        },
      ]
    },
{
  name: 'server-info',
  description: 'عرض معلومات السيرفر',
  dm_permission: false,
  default_member_permissions: 1,
},

{
  name: 'reset-mentions',
  description: 'ترسيت جميع المنشنات',
  dm_permission: false,
  default_member_permissions: 1,
},    
{
    name: 'setup-images',
    description: 'تعديل انفوهات السيرفر',
    dm_permission: false,
    default_member_permissions: 1,
    options: [
        {
            name: 'buy-shop-image',
            description: 'صورة شراء متجر (رابط )',
            type: ApplicationCommandOptionType.String,
            required: false
        },
        {
            name: 'buy-shop-image-attachment',
            description: 'صورة شراء متجر (مرفق)',
            type: ApplicationCommandOptionType.Attachment,
            required: false
        },
        {
            name: 'buy-order-image',
            description: 'صورة شراء طلب (رابط )',
            type: ApplicationCommandOptionType.String,
            required: false
        },
        {
            name: 'buy-order-image-attachment',
            description: 'صورة شراء طلب (مرفق)',
            type: ApplicationCommandOptionType.Attachment,
            required: false
        },
        {
            name: 'buy-auction-image',
            description: 'صورة شراء مزاد (رابط )',
            type: ApplicationCommandOptionType.String,
            required: false
        },
        {
            name: 'buy-auction-image-attachment',
            description: 'صورة شراء مزاد (مرفق)',
            type: ApplicationCommandOptionType.Attachment,
            required: false
        },
   {
            name: 'price-image',
            description: 'انفو الاسعار (رابط)',
            type: ApplicationCommandOptionType.String,
            required: false
        },
        {
            name: 'price-image-attachment',
            description: 'انفو الاسعار (مرفق)',
            type: ApplicationCommandOptionType.Attachment,
            required: false
        },
   {
            name: 'line',
            description: 'صورة خط السيرفر (رابط )',
            type: ApplicationCommandOptionType.String,
            required: false
        },
        {
            name: 'line-attachment',
            description: 'صورة خط السيرفر (مرفق)',
            type: ApplicationCommandOptionType.Attachment,
            required: false
        }
    ]
},  
      {
  name: 'setup',
  description: 'اعداد البوت بسيرفرك',
  dm_permission: false,
  default_member_permissions: 1,
  options: [
    {
      name: 'line',
      description: 'خط السيرفر',
      type: ApplicationCommandOptionType.Attachment,
      required: false,
    },
    {
      name: 'logs',
      description: 'روم لوق المتاجر',
      type: ApplicationCommandOptionType.Channel,
      required: false,
      channel_types: [ChannelType.GuildText]
    },
    {
      name: 'order-room',
      description: 'روم الطلبات',
      type: ApplicationCommandOptionType.Channel,
      required: false,
      channel_types: [ChannelType.GuildText]
    },
    {
      name: 'action-room',
      description: 'روم المزادات',
      type: ApplicationCommandOptionType.Channel,
      required: false,
      channel_types: [ChannelType.GuildText]
    },
    {
      name: 'buy-shop-tickets',
      description: 'كتاغوري شراء متجر',
      type: ApplicationCommandOptionType.Channel,
      required: false,
      channel_types: [ChannelType.GuildCategory]
    },
    {
      name: 'buy-auction-tickets',
      description: 'كتاغوري شراء مزاد',
      type: ApplicationCommandOptionType.Channel,
      required: false,
      channel_types: [ChannelType.GuildCategory]
    },
    {
      name: 'buy-order-tickets',
      description: 'كتاغوري شراء طلبات',
      type: ApplicationCommandOptionType.Channel,
      required: false,
      channel_types: [ChannelType.GuildCategory]
    },
   {
      name: 'high-staff',
      description: 'رتبة العليا',
      type: ApplicationCommandOptionType.Role,
      required: false,
    },
    {
      name: 'shop-admin',
      description: 'مسؤول المتاجر',
      type: ApplicationCommandOptionType.Role,
      required: false,
    },
    {
      name: 'order-admin',
      description: 'مسؤول طلبات',
      type: ApplicationCommandOptionType.Role,
      required: false,
    },
    {
      name: 'auction-admin',
      description: 'مسؤول المزاد',
      type: ApplicationCommandOptionType.Role,
      required: false,
    },
    {
      name: 'bank',
      description: 'المستخدم الذي ستحدده كبنك السيرفر',
      type: ApplicationCommandOptionType.User,
      required: false,
    },
]
      },
{
 name: 'setup-prices',
  description: 'تعديل الأسعار في السيرفر',
  dm_permission: false,
  default_member_permissions: 1,
  options: [
    {
      name: 'everyone-price',
      description: 'سعر منشن ايفري للمتاجر',
      type: ApplicationCommandOptionType.Integer,
      required: false
    },
    {
      name: 'here-price',
      description: 'سعر منشن هير للمتاجر',
      type: ApplicationCommandOptionType.Integer,
      required: false
    },
    {
      name: 'shop-mention-price',
      description: 'سعر منشن متجر',
      type: ApplicationCommandOptionType.Integer,
      required: false
    },
    {
      name: 'order-every-price-credit',
      description: 'سعر منشن ايفري با الكردت للطلبات',
      type: ApplicationCommandOptionType.Integer,
      required: false
    },
    {
      name: 'order-here-price-credit',
      description: 'سعر منشن هير با الكردت',
      type: ApplicationCommandOptionType.Integer,
      required: false
    },
    {
      name: 'auction-every-price-credit',
      description: 'سعر منشن ايفري للمزاد باالكردت',
      type: ApplicationCommandOptionType.Integer,
      required: false
    },
    {
      name: 'auction-here-price-credit',
      description: 'سعر منشن هير با الكردت للمزادات',
      type: ApplicationCommandOptionType.Integer,
      required: false
    },
    {
      name: 'change-partners-credit',
      description: 'سعر اضافة شريك او حذف',
      type: ApplicationCommandOptionType.Integer,
      required: false
    },
    {
      name: 'change-name',
      description: 'سعر تغيير اسم المتجر',
      type: ApplicationCommandOptionType.Integer,
      required: false
    },
    {
      name: 'change-owner',
      description: 'سعر تغيير صاحب المتجر',
      type: ApplicationCommandOptionType.Integer,
      required: false
    },
    {
      name: 'remove-warn-credit',
      description: 'سعر ازالة تحذير',
      type: ApplicationCommandOptionType.Integer,
      required: false
    },
    {
      name: 'auto-message',
      description: 'سعر نشر تلقائي للمتاجر',
      type: ApplicationCommandOptionType.Integer,
      required: false
    },
  ],
},
  {
  name: 'اختصارت',
  description: 'اعداد الاختصارات',
  dm_permission: false,
  default_member_permissions: 1,
  options: [
    {
      name: 'اختصار-المنشنات',
      description: 'اختصار المنشنات وش تبي العضو يكتب عشان يظهر له المنشنات',
      type: ApplicationCommandOptionType.String,
      required: false,
    },
    {
      name: 'اختصار-تحذير',
      description: 'اختصار التحذيرات وش تبي المسؤول يكتب عشان يحذر المتجر',
      type: ApplicationCommandOptionType.String,
      required: false,
    },
    {
      name: 'اختصار-حذف',
      description: 'وش تبي المسؤول يكتب عشان يحذف المتجر',
      type: ApplicationCommandOptionType.String,
      required: false,
    },
    {
      name: 'اختصار-ضريبه',
      description: 'وش تبي العضو يكتب عشان يظهر الضريبه',
      type: ApplicationCommandOptionType.String,
      required: false,
    },
    {
      name: 'اختصار-نداء',
      description: 'وش تبي المسؤول يكتب عشان ينادي العضو',
      type: ApplicationCommandOptionType.String,
      required: false,
    },
    {
      name: 'اختصار-امر-بنق',
      description: 'وش تبي العضو يكتب عشان يظهر بنق البوت',
      type: ApplicationCommandOptionType.String,
      required: false,
    },
    {
      name: 'اختصار-تحديد-صاحب-المتجر',
      description: 'اختصار الأمر لتحديد صاحب المتجر',
      type: ApplicationCommandOptionType.String,
      required: false,
    },
    {
      name: 'اختصار-تحديد-المنشنات',
      description: 'اختصار الأمر لتحديد المنشنات الخاصة بالمتجر',
      type: ApplicationCommandOptionType.String,
      required: false,
    },
    {
      name: 'اختصار-اضافة-منشنات',
      description: 'اختصار الأمر لإضافة منشنات جديدة',
      type: ApplicationCommandOptionType.String,
      required: false,
    },
    {
      name: 'اختصار-اضافة-متجر',
      description: 'اختصار امر يضيف المتجر لبينات البوت',
      type: ApplicationCommandOptionType.String,
      required: false,
    },
    {
      name: 'اختصار-انشاء-متجر',
      description: 'اختصار امر يسوي المتجر',
      type: ApplicationCommandOptionType.String,
      required: false,
    },
]
      },
 {
      name: `price-panel`,
      description: `ارسال بانل الاسعار`,
      dm_permissions: false,
      default_member_permissions: 1,
      options: [
        {
      name: 'embed-text',
      description: 'الكلام الي بيكون محطوط با ايمبد الاسعار',
      type: ApplicationCommandOptionType.String,
      required: false,
    },
],
    }, 
    {
      name: `buy-panel`,
      description: `ارسال قسم الشراء`,
      dm_permissions: false,
      default_member_permissions: 1,
      options: [
        {
      name: 'embed-text',
      description: 'الكلام الي بيكون محطوط با ايمبد التكتات',
      type: ApplicationCommandOptionType.String,
      required: false,
    },
],
    },
    {
      name: `order-panel`,
      description: `ارسال قسم شراء طلبات`,
      dm_permissions: false,
      default_member_permissions: 1,
 options: [
        {
      name: 'embed-text',
      description: 'الكلام الي بيكون محطوط با ايمبد التكتات',
      type: ApplicationCommandOptionType.String,
      required: false,
    },
],
    }, 
    {
      name: `shop-panel`,
      description: `ارسال قسم شراء متاجر`,
      dm_permissions: false,
      default_member_permissions: 1,
      options: [
        {
      name: 'embed-text',
      description: 'الكلام الي بيكون محطوط با ايمبد التكتات',
      type: ApplicationCommandOptionType.String,
      required: false,
    },
],
    }, 
    {
      name: `auction-panel`,
      description: `ارسال قسم شراء مزاد`,
      dm_permissions: false,
      default_member_permissions: 1,
 options: [
        {
      name: 'embed-text',
      description: 'الكلام الي بيكون محطوط با ايمبد التكتات',
      type: ApplicationCommandOptionType.String,
      required: false,
    },
],
    }, 
    {
      name: 'remove-tax-channel',
      description: ' ازـالـة روم لـ رومـات الضـرائـب ',
      dm_permission: false,
      default_member_permissions: 1,
      options: [
        {
          name: `channel`,
          description: ` الـروم `,
          type: ApplicationCommandOptionType.Channel,
          required: true,
          channel_types: [ChannelType.GuildText]
        },
      ]
    },
    {
      name: 'show-tax-channels',
      description: ' لـ اظهار رومات الضرائب المسجلة ',
      dm_permission: false,
      default_member_permissions: 1,
    },
      {
      name: 'add-emoji-channel',
      description: ' اضـافـة روم لـ رومـات ايموجي ',
      dm_permission: false,
      default_member_permissions: 1,
      options: [
        {
          name: `channel`,
          description: ` الـروم `,
          type: ApplicationCommandOptionType.Channel,
          required: true,
          channel_types: [ChannelType.GuildText]
        },
      ]
    },
    {
      name: 'remove-emoji-channel',
      description: ' ازـالـة روم لـ رومـات ايموجي ',
      dm_permission: false,
      default_member_permissions: 1,
      options: [
        {
          name: `channel`,
          description: ` الـروم `,
          type: ApplicationCommandOptionType.Channel,
          required: true,
          channel_types: [ChannelType.GuildText]
        },
      ]
    },
    {
      name: 'show-emoji-channels',
      description: 'اظهار رومات الايموجي',
      dm_permission: false,
      default_member_permissions: 1,
    },
{
      name: 'add-sticker-channel',
      description: ' اضـافـة روم لـ رومـات ستيكر ',
      dm_permission: false,
      default_member_permissions: 1,
      options: [
        {
          name: `channel`,
          description: ` الـروم `,
          type: ApplicationCommandOptionType.Channel,
          required: true,
          channel_types: [ChannelType.GuildText]
        },
      ]
    },
{
      name: 'remove-sticker-channel',
      description: ' حذف روم ستيكر ',
      dm_permission: false,
      default_member_permissions: 1,
      options: [
        {
          name: `channel`,
          description: ` الـروم `,
          type: ApplicationCommandOptionType.Channel,
          required: true,
          channel_types: [ChannelType.GuildText]
        },
      ]
    },
{
      name: 'show-sticker-channels',
      description: ' اظهار رومات الاستيكر ',
      dm_permission: false,
      default_member_permissions: 1,
    },
{
  name: 'add-autoreply',
  description: 'اضافة رد تلقائي',
  dm_permission: false,
  default_member_permissions: 1,
  options: [
    {
      name: 'keyword',
      description: 'الكلمة',
      type: ApplicationCommandOptionType.String,
      required: true,
    },
    {
      name: 'reply',
      description: 'الرد',
      type: ApplicationCommandOptionType.String,
      required: true,
    },
    {
      name: 'role',
      description: 'حدد الرتبة المسموح بها للرد (اختياري)',
      type: ApplicationCommandOptionType.Role,
      required: false,
    },
    {
      name: 'channel',
      description: 'حدد الروم المسموح بها للرد (اختياري)',
      type: ApplicationCommandOptionType.Channel,
      required: false,
    },
    {
      name: 'embed',
      description: 'هل تريد الرد كإيمبد؟',
      type: ApplicationCommandOptionType.Boolean,
      required: false,
    },
    {
      name: 'title',
      description: 'عنوان الإيمبد (اختياري)',
      type: ApplicationCommandOptionType.String,
      required: false,
    },
    {
      name: 'image',
      description: 'رابط الصورة للإيمبد (اختياري)',
      type: ApplicationCommandOptionType.String,
      required: false,
    },
    {
      name: 'color',
      description: 'لون الايمبد',
      type: ApplicationCommandOptionType.String,
      required: false,
     choices: [ 
    { name: 'اخضر فاتح', value: '#90EE90' },
    { name: 'اخضر غامق', value: '#006400' },
    { name: 'احمر فاتح', value: '#FF6347' },
    { name: 'احمر غامق', value: '#8B0000' },
    { name: 'ازرق', value: '#0056D7' },
    { name: 'ازرق فاتح', value: '#ADD8E6' },
    { name: 'ازرق سماوي', value: '#00BFFF' },
    { name: 'اصفر', value: '#FFFF00' },
    { name: 'اصفر ذهبي', value: '#FFD700' },
    { name: 'برتقالي فاتح', value: '#FFA07A' },
    { name: 'برتقاني غامق', value: '#FF8C00' },
    { name: 'وردي', value: '#FFC0CB' },
    { name: 'وردي داكن', value: '#FF1493' },
    { name: 'بنفسجي', value: '#800080' },
    { name: 'بنفسجي فاتح', value: '#DDA0DD' },
    { name: 'بني', value: '#A52A2A' },
    { name: 'رمادي فاتح', value: '#D3D3D3' },
    { name: 'رمادي غامق', value: '#696969' },
    { name: 'فيروزي', value: '#40E0D0' },
    { name: 'نيلي', value: '#4B0082' },
    { name: 'ابيض', value: '#FFFFFF' },
    { name: 'اسود', value: '#000000' },
    { name: 'ذهبي', value: '#FFD700' },
    { name: 'ليموني', value: '#32CD32' },
    { name: 'مرجاني', value: '#FF7F50' }
],
    },
  ],
},
   {
      name: 'remove-autoreply',
      description: 'حذف رد تلقائي',
      dm_permission: false,
      default_member_permissions: 1,
      options: [
        {
          name: 'keyword',
          description: 'الكلمه المراد حذفها',
          type: ApplicationCommandOptionType.String,
          required: true,
        },
      ],
    },
      {
      name: 'list-autoreplies',
      description: 'اظهار الردود التلقائيه',
      dm_permission: false,
      default_member_permissions: 1,
    },
     {
        name: 'say-emabed',
        description: 'ارسال رساله با ايمبد',
      dm_permission: false,
      default_member_permissions: 1,
        options:[
{
          name: `msg`,
          description: 'الرساله',
          type: ApplicationCommandOptionType.String,
          required: true,      
},
  {
          name: `room`,
          description: `روم الرساله.`,
          type: ApplicationCommandOptionType.Channel,
          required: false,
          channel_types: [ChannelType.GuildText]
         },
              {
                  name: `image`,
                  description: `صورة الأميبد`,
                  type: ApplicationCommandOptionType.String,
                  required: false,
              },
             {
          name: `title`,
          description: 'العنوان',
          type: ApplicationCommandOptionType.String,
          required: false,      
},
    ]}, 
{
      name: "come",
      description: " اسـتـدعـاء عـضـو ",
      dm_permission: false,
      default_member_permissions: 1,
      options: [
        {
          name: `user`,
          description: `الشخص المرجو استدعائه `,
          type: ApplicationCommandOptionType.User,
          required: true,
        },
       {
          name: `reason`,
          description: ` سبب استدعاء الشخص `,
          type: ApplicationCommandOptionType.String,
          required: true,
        },
      ],
    }, 
{
    name: 'مزاد',
    description: 'بدء مزاد',
    dm_permission: false,
    default_member_permissions: 1,
    options: [
        {
            name: 'الشخص',
            description: 'الشخص صاحب المزاد',
            type: ApplicationCommandOptionType.User,
            required: true,
        },
        {
            name: 'السلعة',
            description: 'شرح السلعة',
            type: ApplicationCommandOptionType.String,
            required: true,
        },
        {
            name: 'السعر',
            description: 'سعر السلعة',
            type: ApplicationCommandOptionType.String,
            required: true,
        },
        {
            name: 'وقت',
            description: 'وقت انتهاء المزاد',
            type: ApplicationCommandOptionType.Integer,
            required: true,
            choices: [
                { name: '5 دقائق', value: 5 },
                { name: '6 دقائق', value: 6 },
                { name: '7 دقائق', value: 7 },
                { name: '8 دقائق', value: 8 },
                { name: '9 دقائق', value: 9 },
                { name: '10 دقائق', value: 10 },
                { name: '11 دقائق', value: 11 },
                { name: '12 دقائق', value: 12 }
            ]
        },
        {
            name: 'المنشن',
            description: 'نوع منشن المزاد',
            type: ApplicationCommandOptionType.Integer,
            required: true,
            choices: [
                { name: 'Everyone', value: 0 },
                { name: 'Here', value: 1 },
            ]
        },
        {
            name: 'channel',
            description: 'الروم التي تريد ارسال فيها المزاد',
            type: ApplicationCommandOptionType.Channel,
            required: true,
            channel_types: [ChannelType.GuildText]
        },
        {
            name: 'صوره',
            description: 'صورة للسلعة او للمزاد',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'صوره2',
            description: 'صورة ثانيه',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'صوره3',
            description: 'صورة ثالثه',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'صوره4',
            description: 'صورة رابعة',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
        {
            name: 'صوره5',
            description: 'صورة خامسة',
            type: ApplicationCommandOptionType.Attachment,
            required: false,
        },
    ]
},
{
      name: 'say-all-shops',
      description: 'ارســال رســـالة لـ كل المــتاجــر',
      dm_permission: false,
      default_member_permissions: 1,
             options: [
        {
          name: `message`,
          description: ` الكلمه `,
          type: ApplicationCommandOptionType.String,
          required: true,
        },
]
},
{
      name: 'shop',
      description: 'لإنشاء متجر في كاتيجوري محدد.',
      dm_permission: false,
      default_member_permissions: 1,
      options: [
        {
          name: `category`,
          description: `الكاتيقوري الذي سيتم انشاء المتجر به.`,
          required: true,
          type: ApplicationCommandOptionType.Channel,
          channel_types: [ChannelType.GuildCategory]
        },
        {
          name: `name`,
          description: `اسم المتجر.`,
          type: ApplicationCommandOptionType.String,
          max_length: 35,
          required: true,
        },
        {
          name: `seller`,
          description: `الشخص الذي يمكنه البيع في هذا المتجر.`,
          type: ApplicationCommandOptionType.User,
          required: true,
        },
      ]
    },
{
    name: 'add-shop-data',
    description: 'اضافة متجر للداتا',
    dm_permission: false,
    default_member_permissions: 1,
    options: [
    {
      name: 'shop',
      description: 'الـمـتـجـر',
      type: ApplicationCommandOptionType.Channel,
      required: true,
     channel_types: [ChannelType.GuildText]
      //choices: choices()
    },
{
          name: `category`,
          description: `الكاتيقوري الذي سيتم انشاء المتجر به.`,
          required: true,
          type: ApplicationCommandOptionType.Channel,
          channel_types: [ChannelType.GuildCategory]
        },
{
          name: `seller`,
          description: `الشخص الذي يمكنه البيع في هذا المتجر.`,
          type: ApplicationCommandOptionType.User,
          required: true,
        },
  ]
},
{
    name: 'remove-shop-data',
    description: 'حذف المتجر من الداتا',
    dm_permission: false,
    default_member_permissions: 1,
    options: [
    {
      name: 'shop',
      description: 'الـمـتـجـر',
      type: ApplicationCommandOptionType.Channel,
      required: true,
     channel_types: [ChannelType.GuildText]
      //choices: choices()
    },
        ]
        },
{
    name: 'shop-data',
    description: 'اظهار معلومات المتجر',
    dm_permission: false,
    default_member_permissions: 1,
    options: [
    {
      name: 'shop',
      description: 'الـمـتـجـر',
      type: ApplicationCommandOptionType.Channel,
      required: true,
     channel_types: [ChannelType.GuildText]
      //choices: choices()
    }
  ]
},
      {
            name: 'order',
        description: 'لـ طلب بروم انت تحدده',
      dm_permission: false,
      default_member_permissions: 1,
        options:[
{
          name: `الشخص`,
          description: 'صاحب الطلب',
      type: ApplicationCommandOptionType.User,
      required: true,      
},
{
          name: `الطلب`,
          description: 'السلعة المطلوبة',
          type: ApplicationCommandOptionType.String,
          required: true,      
},
{
          name: `المنشن`,
          description: 'نوع منشن الطلب',
      type: ApplicationCommandOptionType.Integer,
          required: true,  
                choices: [
                { name: 'Everyone', value: 0 },
                { name: 'Here', value: 1 },
]
},

    ]}, 
                {
  name: 'check-types',
  description: 'فحص جميع الأنواع وحذف الأنواع ذات الكاتيجوري المحذوف',
  dm_permission: false,
  default_member_permissions: 1,
  options: []
        },
        {
  name: 'edit-type',
  description: 'تعديل نوع متجر موجود بدون إعادة كتابته من الصفر',
  dm_permission: false,
  default_member_permissions: 1,
  options: [
    {
      name: 'category',
      description: 'الكاتيجوري الخاص بالنوع الذي تريد تعديله',
      type: ApplicationCommandOptionType.Channel,
      channel_types: [ChannelType.GuildCategory],
      required: true,
    },
    {
      name: 'name',
      description: 'الاسم الجديد (اختياري)',
      type: ApplicationCommandOptionType.String,
      required: false,
    },
    {
      name: 'everyone_mention_count',
      description: 'عدد منشنات everyone (اختياري)',
      type: ApplicationCommandOptionType.Integer,
      required: false,
    },
    {
      name: 'here_mention_count',
      description: 'عدد منشنات here (اختياري)',
      type: ApplicationCommandOptionType.Integer,
      required: false,
    },
    {
      name: 'shop_mention_count',
      description: 'عدد منشنات رتبة المتجر (اختياري)',
      type: ApplicationCommandOptionType.Integer,
      required: false,
    },
    {
      name: 'shop_mention',
      description: 'رتبة منشن المتجر الجديدة (اختياري)',
      type: ApplicationCommandOptionType.Role,
      required: false,
    },
    {
      name: 'shop_role',
      description: 'رتبة صاحب المتجر (اختياري)',
      type: ApplicationCommandOptionType.Role,
      required: false,
    },
    {
      name: 'pirefix',
      description: 'الزخرفة الجديدة (اختياري)',
      type: ApplicationCommandOptionType.String,
      required: false,
    },
    {
      name: 'maxwarns',
      description: 'أقصى عدد تحذيرات (اختياري)',
      type: ApplicationCommandOptionType.Integer,
      required: false,
    },
    {
      name: 'shop_price',
      description: 'السعر الجديد (اختياري)',
      type: ApplicationCommandOptionType.Integer,
      required: false,
    },
    {
      name: 'has_tax',
      description: 'هل يوجد ضريبة؟ (اختياري)',
      type: ApplicationCommandOptionType.Boolean,
      required: false,
    },
    {
      name: 'tax_price',
      description: 'سعر الضريبة (اختياري)',
      type: ApplicationCommandOptionType.Integer,
      required: false,
    },
  ]
},
{
  name: 'remove-type',
  description: 'حذف نوع كتاغوري متاجر',
  dm_permission: false,
  default_member_permissions: 1,
  options: [
   {
      name: 'category',
      description: 'الكاتيجوري الذي تريد حذفه من الداتا',
      type: ApplicationCommandOptionType.Channel,
      channel_types: [ChannelType.GuildCategory],
      required: true,
    },
      ]
},
{
  name: 'remove-all-types',
  description: 'حذف جميع انواع المتاجر',
  dm_permission: false,
  default_member_permissions: 1,
},
{
  name: 'reset',
  description: 'حذف جميع البينات المتعلقه با السيرفر',
  dm_permission: false,
  default_member_permissions: 1,
},
{
    name: 'say-voice',
    description: 'ارسال كلام صوتي باستخدام البوت',
    dm_permission: false,
    default_member_permissions: 1,
    options: [
        {
            name: 'message',
            description: 'الكلام',
            type: ApplicationCommandOptionType.String,
            required: true,
        },
        {
            name: 'language',
            description: 'اللغة',
            type: ApplicationCommandOptionType.String,
            required: true,
            choices: [
{ name: 'العربية | العربية', value: 'ar' },  
{ name: 'الإنجليزية | English', value: 'en' },  
{ name: 'الإسبانية | Español', value: 'es' },  
{ name: 'الفرنسية | Français', value: 'fr' },  
{ name: 'الألمانية | Deutsch', value: 'de' },  
{ name: 'الإيطالية | Italiano', value: 'it' },  
{ name: 'الروسية | Русский', value: 'ru' },  
{ name: 'الصينية | 中文', value: 'zh' },  
{ name: 'اليابانية | 日本語', value: 'ja' },  
{ name: 'الكورية | 한국어', value: 'ko' },  
{ name: 'الهندية | हिन्दी', value: 'hi' },  
{ name: 'البرتغالية | Português', value: 'pt' },  
{ name: 'التركية | Türkçe', value: 'tr' },  
{ name: 'الهولندية | Nederlands', value: 'nl' },  
{ name: 'البولندية | Polski', value: 'pl' } 
            ],
        },
    ],
},
{
  name: 'add-type',
  description: 'تحديد نوع كتاغوري متاجر',
  dm_permission: false,
  default_member_permissions: 1,
  options: [
    {
      name: 'name',
      description: 'اسم هاذا النوع',
      type: ApplicationCommandOptionType.String,
      required: true,
    },
    {
      name: 'category',
      description: 'الكاتيجوري الذي تريد تحديد منشناته',
      type: ApplicationCommandOptionType.Channel,
      channel_types: [ChannelType.GuildCategory],
      required: true,
    },
    {
      name: 'everyone_mention_count',
      description: 'عدد منشنات ايفري ون المسموح بها.',
      type: ApplicationCommandOptionType.Integer,
      required: true,
    },
    {
      name: 'here_mention_count',
      description: 'عدد منشنات هير المسموح بها.',
      type: ApplicationCommandOptionType.Integer,
      required: true,
    },
    {
      name: 'shop_mention_count',
      description: 'عدد منشنات رتبة المسموح بها.',
      type: ApplicationCommandOptionType.Integer,
      required: true,
    },
    {
      name: 'shop_mention',
      description: 'رتبت منشن متجر.',
      type: ApplicationCommandOptionType.Role,
      required: true,
    },
    {
      name: 'shop_role',
      description: 'رتبت صاحب المتجر من هاذا النوع.',
      type: ApplicationCommandOptionType.Role,
      required: true,
    },
{
  name: 'pirefix',
  description: 'زخرفة المتجر من هذا النوع زي 𓏲🛒𝄢・⼂',
  type: ApplicationCommandOptionType.String,
  required: true, // الحقل إجباري
},
    {
      name: 'maxwarns',
      description: 'اقصى عدد تحذيرات لهاذا النوع.',
      type: ApplicationCommandOptionType.Integer,
      required: true,
    },
    {
      name: 'shop_price',
      description: 'سعر المتجر من هاذا النوع.',
      type: ApplicationCommandOptionType.Integer,
      required: true,
    },
    {
      name: 'has_tax',
      description: 'هل يحتوي النوع على ضريبة؟',
      type: ApplicationCommandOptionType.Boolean,
      required: true,
    },
    {
      name: 'tax_price',
      description: 'سعر الضريبة لهذا النوع (في حالة وجودها).',
      type: ApplicationCommandOptionType.Integer,
      required: false,
    }
  ]
},
{
  name: 'add-type2',
  description: 'يحدد نوع كتاغوري و يضيف كل المتاجر الي فيه للداتا',
  dm_permission: false,
  default_member_permissions: 1,
  options: [
    {
      name: 'name',
      description: 'اسم هاذا النوع',
      type: ApplicationCommandOptionType.String,
      required: true,
    },
    {
      name: 'category',
      description: 'الكاتيجوري الذي تريد تحديد منشناته',
      type: ApplicationCommandOptionType.Channel,
      channel_types: [ChannelType.GuildCategory],
      required: true,
    },
    {
      name: 'everyone_mention_count',
      description: 'عدد منشنات ايفري ون المسموح بها.',
      type: ApplicationCommandOptionType.Integer,
      required: true,
    },
    {
      name: 'here_mention_count',
      description: 'عدد منشنات هير المسموح بها.',
      type: ApplicationCommandOptionType.Integer,
      required: true,
    },
    {
      name: 'shop_mention_count',
      description: 'عدد منشنات رتبة المسموح بها.',
      type: ApplicationCommandOptionType.Integer,
      required: true,
    },
    {
      name: 'shop_mention',
      description: 'رتبت منشن متجر.',
      type: ApplicationCommandOptionType.Role,
      required: true,
    },
    {
      name: 'shop_role',
      description: 'رتبت صاحب المتجر من هاذا النوع.',
      type: ApplicationCommandOptionType.Role,
      required: true,
    },
    {
      name: 'shop-pirefix',
      description: 'زخرفة المتجر من هاذا النوع',
      type: ApplicationCommandOptionType.String,
      required: true,
    },
    {
      name: 'maxwarns',
      description: 'اقصى عدد تحذيرات لهاذا النوع.',
      type: ApplicationCommandOptionType.Integer,
      required: true,
    },
    {
      name: 'shop_price',
      description: 'سعر المتجر من هاذا النوع.',
      type: ApplicationCommandOptionType.Integer,
      required: true,
    },
    {
      name: 'has_tax',
      description: 'هل يحتوي النوع على ضريبة؟',
      type: ApplicationCommandOptionType.Boolean,
      required: true,
    },
    {
      name: 'tax_price',
      description: 'سعر الضريبة لهذا النوع (في حالة وجودها).',
      type: ApplicationCommandOptionType.Integer,
      required: false,
    }
  ]
},
{ 

   name: 'active',
    description: 'لـتـفـعـيـل مـتـجـر',
    dm_permission: false,
    default_member_permissions: 1,
    options:[
    {
      name: 'shop',
      description: 'الـمـتـجـر',
      type: ApplicationCommandOptionType.Channel,
      required: false,
     channel_types: [ChannelType.GuildText]
      //choices: choices()
    }
        ] 
        }, 
{ 

   name: 'active-all',
    description: 'لـتـفـعـيـل المتاجر',
    dm_permission: false,
    default_member_permissions: 1,
        }, 
    {
    name: 'disable',
    description:'لـتـعـطـيـل مـتـجـر مـعـيـن',
    dm_permission: false,
      default_member_permissions: 1,
    options: [
      {
        name: 'shop',
        description: 'االـروم',
        type: ApplicationCommandOptionType.Channel,
        required: true,
     channel_types: [ChannelType.GuildText]
      },
      {
        name: 'reason',
        description: 'الـسـبـب',
        type: ApplicationCommandOptionType.String,
        required: true,
      },
]
    },
      {
      name: 'disable-all',
      description: 'تعطيل جميع المتاجر',
      dm_permission: false,
      default_member_permissions: 1,
    },
      {
      name: 'tax-time',
      description: 'تفعيل وضع الضريبه للمتاجر',
      dm_permission: false,
      default_member_permissions: 1,
    },
    {
    name: 'afk',
    description:'لتفعيل وضع الخمول',
    dm_permission: false,
      default_member_permissions: 1,
    options: [
      {
        name: 'reason',
        description: 'الـسـبـب',
        type: ApplicationCommandOptionType.String,
        required: false,
      },
]
    },
{
      name: 'help',
      description: ' لعرض اوامر المساعده ',
      dm_permission: false,
      default_member_permissions: 1,
    },
{
      name: 'ping',
      description: ' لرؤية سرعة استجابت البوت ',
      dm_permission: false,
      default_member_permissions: 1,
    },
{
      name: 'send-tashfeer',
      description: ' رسـالـة التـشـفـيـر ',
      dm_permission: false,
      default_member_permissions: 1,
    },
{
      name: 'types',
      description: 'لــ اظــهار معلومأت انواع المتاجر',
      dm_permission: false,
      default_member_permissions: 1,
    },
{
      name: 'set-mention',
      description: 'تحديد عدد منشنات متجر محدد',
      dm_permission: false,
      default_member_permissions: 1,
      options: [
        {
          name: `shop`,
          description: `حدد المتجر الذي تريد التعديل عليه.`,
          type: ApplicationCommandOptionType.Channel,
          required: true,
          channel_types: [ChannelType.GuildText]
        },
        {
          name: `mention`,
          description: `نوع المنشن.`,
          type: ApplicationCommandOptionType.String,
          required: true,
          choices: [
            { name: `@everyone`, value: `everyone` },
            { name: `@here`, value: `here` },
            { name: `@shop_role`, value: `shop_role` },
          ]
        },
        {
          name: `count`,
          description: `عدد المنشنات الذي سيتم تحديده.`,
          type: ApplicationCommandOptionType.Integer,
          required: true,
        },
      ]
    },
{
      name: 'add-mention',
      description: 'اضافة عدد منشنات لـ متجر محدد',
      dm_permission: false,
      default_member_permissions: 1,
      options: [
        {
          name: `shop`,
          description: `حدد المتجر الذي تريد التعديل عليه.`,
          type: ApplicationCommandOptionType.Channel,
          required: true,
          channel_types: [ChannelType.GuildText]
        },
        {
          name: `mention`,
          description: `نوع المنشن.`,
          type: ApplicationCommandOptionType.String,
          required: true,
          choices: [
            { name: `@everyone`, value: `everyone` },
            { name: `@here`, value: `here` },
            { name: `@shop_role`, value: `shop_role` },
          ]
        },
        {
          name: `count`,
          description: `عدد المنشنات الذي سيتم تحديده.`,
          type: ApplicationCommandOptionType.Integer,
          required: true,
        },
      ]
    },
{
      name: 'add-helper',
      description: ' اضـافـة مساعد للمـتـجـر ',
      dm_permission: false,
      default_member_permissions: 1,
      options: [
        {
          name: `helper`,
          description: `المـساعد.`,
          type: ApplicationCommandOptionType.User,
          required: true,
        },
        {
          name: `shop`,
          description: ` المـتـجـر.`,
          type: ApplicationCommandOptionType.Channel,
          required: false,
          channel_types: [ChannelType.GuildText]
         }
      ]
    }, 
    {
      name: 'remove-helper',
      description: ' ازالة مساعد مـن مـتـجـر مـعـيـن ',
      dm_permission: false,
      default_member_permissions: 1,
      options: [
        {
          name: `helper`,
          description: `المساعد.`,
          type: ApplicationCommandOptionType.User,
          required: true,
        },
        {
          name: `shop`,
          description: ` المـتـجـر.`,
          type: ApplicationCommandOptionType.Channel,
          required: false,
          channel_types: [ChannelType.GuildText]
         }
      ]
    }, 
    {
      name: 'show-helpers',
      description: 'رؤية مساعدين المتجر',
      dm_permission: false,
      default_member_permissions: 1,
      options: [
        {
          name: `shop`,
          description: ` المـتـجـر.`,
          type: ApplicationCommandOptionType.Channel,
          required: false,
          channel_types: [ChannelType.GuildText]
         }
      ]
    }, 
{
    name: 'owner',
    description: 'change owner of a shop',
    dm_permission: false,
      default_member_permissions: 1,
    options: [
    {
      name: 'new-owner',
      description: 'صـاحـب المـتـجـر الجـديـد',
      type: ApplicationCommandOptionType.User,
      required: true,
    },
    {
      name: 'shop',
      description: 'المـتـجـر',
      type: ApplicationCommandOptionType.Channel,
      required: false,
     channel_types: [ChannelType.GuildText]
    },
    ]
    },
 
 {
  name: 'delete-shop',
  description: 'delete a shop',
  dm_permission: false,
  default_member_permissions: 1,
  options: [
    {
      name: 'shop',
      description: 'the shop you want to delete',
      type: ApplicationCommandOptionType.Channel,
      required: true,
      channel_types: [ChannelType.GuildText]
    },
    {
      name: 'reason',
      description: 'the reason',
      type: ApplicationCommandOptionType.String,
      required: true
       },
      ]
    }, 
      {
      name: 'warns',
      description: 'عـرض تـحـذيـرات مـتـجـر مـعـيـن',
      dm_permission: false,
      default_member_permissions: 1,
    },
    {
    name: 'warn',
    description: 'warn a shop',
    dm_permission: false,
    default_member_permissions: 1,
    options: [
     {
      name: 'thewarn',
      description: 'سبب التحذير',
      type: ApplicationCommandOptionType.String,
      required: true,
    },
    {
      name: 'shop',
      description: 'المـتـجـر',
      type: ApplicationCommandOptionType.Channel,
      required: false,
     channel_types: [ChannelType.GuildText]
    },
    {
      name: 'amount',
      description: 'عـدد التـحـذيـرات',
      type: ApplicationCommandOptionType.Number,
      required: false,
    },
       {
      name: 'pic',
      description: 'صوره',
      type: ApplicationCommandOptionType.Attachment,
      required: false,
    },
    ]
    },
    {
    name: 'unwarn',
    description: 'حذف تحذير من متجر',
    dm_permission: false,
    default_member_permissions: 1,
    options: [
    {
      name: 'shop',
      description: 'المـتـجـر المراد حذف تحذيراته',
      type: ApplicationCommandOptionType.Channel,
      required: false,
     channel_types: [ChannelType.GuildText]
    },
    {
      name: 'amount',
      description: 'عـدد التـحـذيـرات',
      type: ApplicationCommandOptionType.Number,
      required: false,
    },
    ]
    },
 {
    name: 'unwarn-all',
    description: 'حذف كل التحذيرات من المتاجر او متجر',
    dm_permission: false,
    default_member_permissions: 1,
    options: [
    {
      name: 'shop',
      description: 'المـتـجـر المراد حذف تحذيراته',
      type: ApplicationCommandOptionType.Channel,
      required: false,
     channel_types: [ChannelType.GuildText]
    },
    ]
    },
  {
      name: 'mentions',
      description: 'اظهار عدد منشنات المتجر',
      dm_permission: false,
      default_member_permissions: 1,
    },
    {
      name: 'add-emoji-button',
      description: 'اضافة زر ايموجي لرسالة من رسائل البوت',
      dm_permission: false,
      default_member_permissions: '8',
      options: [
        { name: 'message_id', description: 'ايدي الرسالة', type: ApplicationCommandOptionType.String, required: true },
        { name: 'emoji', description: 'الايموجي اللي تبي يطلع على الزر', type: ApplicationCommandOptionType.String, required: true },
      ],
    },
    {
      name: 'ticket-panel',
      description: 'إرسال بانل التذاكر (طلب / مزاد / متجر / دعم فني)',
      dm_permission: false,
      default_member_permissions: '8',
      options: [
        { name: 'title', description: 'عنوان البانل (اختياري)', type: ApplicationCommandOptionType.String, required: false },
        { name: 'description', description: 'وصف البانل (اختياري)', type: ApplicationCommandOptionType.String, required: false },
      ],
    },
    {
      name: 'bot-avatar',
      description: 'تغيير صورة البوت',
      dm_permission: false,
      default_member_permissions: '8',
      options: [
        { name: 'image', description: 'الصورة الجديدة للبوت', type: ApplicationCommandOptionType.Attachment, required: true },
      ],
    },
    {
      name: 'bot-banner',
      description: 'تغيير بنر البوت',
      dm_permission: false,
      default_member_permissions: '8',
      options: [
        { name: 'image', description: 'البنر الجديد للبوت', type: ApplicationCommandOptionType.Attachment, required: true },
      ],
    },
    ];

        const rest = new REST({ version: 10 }).setToken(token);

    try {
        // تسجيل كل الأوامر في طلب واحد (الطلب الثاني كان يمسح الأوامر العامة)
        const allCommands = client.user.id === allowedBotId
            ? [...globalCommands, ...restrictedCommands]
            : globalCommands;
        if (config.guildId) {
            await rest.put(Routes.applicationGuildCommands(client.user.id, config.guildId), { body: allCommands });
        } else {
            await rest.put(Routes.applicationCommands(client.user.id), { body: allCommands });
        }
        console.log(`✅ Registered ${allCommands.length} slash commands.`);
    } catch (error) {
        console.error('❌ An error occurred while registering commands:', error);
    }
})

const BOT_IDS = [
    "1333876835758374923",
    "1184438673320706128",
    "1403075633105469642",
      "1337486964823425125",
      "1348241958602145892",
      "1343533533825597470",
    "1340778883246460998" ,
      "1315623935911526442"
     
];

const IGNORED_GUILDS = [
    "1322845612919619604",
    "1384831324015296614"
];
const replacements = {
    "متجر": "مــ.ـتـجر",
    "متجري": "مــ.ــتجري",
    "متجرها": "مــ.ـتـجرها",
    "متجره": "مــ.ـتـجره",
    "متجرك": "مــ.ــتجرك",
    "متجركم": "مــ.ــتجركم",
    "متجرهم": "مــ.ـتجرهم",
    "متجرنا": "مــ.ـنتجرنا",
    "عرض": "عــ.ـرض",
    "عرضي": "عــ.ــرضي",
    "عرضك": "عــ.ــرضك",
    "عرضكم": "عــ.ــرضكم",
    "عرضهم": "عــ.ــرضهم",
    "عرضنا": "عــ.ــرضنا",
    "عروض": "عــ.ــروض",
    "عروضي": "عــ.ــروضي",
    "عروضك": "عــ.ــروضك",
    "عروضكم": "عــ.ــروضكم",
    "عروضهم": "عــ.ــروضهم",
    "عروضنا": "عــ.ــروضنا",
    "حساب": "حــ.ــساب",
    "حسابي": "حــ.ــسابي",
    "حسابك": "حــ.ــسابك",
    "حسابكم": "حــ.ــسابكم",
    "حسابهم": "حــ.ــسابهم",
    "حسابنا": "حــ.ــسابنا",
    "حسابات": "حــ.ــسابات",
    "حساباتي": "حــ.ــساباتي",
    "حساباتك": "حــ.ــساباتك",
    "حساباتكم": "حــ.ــساباتكم",
    "حساباتهم": "حــ.ــساباتهم",
    "حساباتنا": "حــ.ــساباتنا",
    "متوفر": "مــ.ــتوفر",
    "متوفري": "مــ.ــتوفري",
    "متوفرها": "مــ.ــتوفرها",
    "متوفره": "مــ.ــتوفره",
    "متوفرك": "مــ.ــتوفرك",
    "متوفركم": "مــ.ــتوفركم",
    "متوفرهم": "مــ.ــتوفرهم",
    "متوفرنا": "مــ.ــتوفرنا",
    "شوب": "شــ.ــوب",
    "شوبك": "شــ.ــوبك",
    "شوبكم": "شــ.ــوبكم",
    "شوبهم": "شــ.ــوبهم",
    "شوبنا": "شــ.ــوبنا",
    "اوفر": "أــ.ــوفر",
    "اوفرها": "أــ.ــوفرها",
    "اوفره": "أــ.ــوفره",
    "اوفرك": "أــ.ــفرك",
    "اوفركم": "أــ.ــفركم",
    "اوفرهم": "أــ.ــوفرهم",
    "اوفرنا": "أــ.ــوفرنا",
    "بيع": "بــ.ــيع",
    "بيعي": "بــ.ــيعي",
    "بيعك": "بــ.ــيعك",
    "بيعكم": "بــ.ــيعكم",
    "بيعهم": "بــ.ــيعهم",
    "بيعنا": "بــ.ــيعنا",
    "للبيع": "للــ.ــبيع",
    "للبيعي": "للــ.ــبيعي",
    "للبيعك": "للــ.ــبيعك",
    "للبيعكم": "للــ.ــبيعكم",
    "للبيعهم": "للــ.ــبيعهم",
    "للبيعنا": "للــ.ــبيعنا",
    "ابيع": "أبــ.ــيع",
    "ابيعك": "أبــ.ــيعك",
    "ابيعكم": "أبــ.ــيعكم",
    "ابيعهم": "أبــ.ــيعهم",
    "ابيعنا": "أبــ.ــيعنا",
    "بوست": "بــ.ــوست",
    "بوستك": "بــ.ــوستك",
    "بوستكم": "بــ.ــوستكم",
    "بوستهم": "بــ.ــوستهم",
    "بوستنا": "بــ.ــوستنا",
    "نيترو": "نيــ.ــترو",
    "نيتروك": "نيــ.ــتروك",
    "نيتروكم": "نيــ.ــتروكم",
    "نيتروهم": "نيــ.ــتروهم",
    "نيترونا": "نيــ.ــترونا",
    "روبكس": "روبكــ.ــس",
    "روبكسك": "روبكســ.ــك",
    "روبكسكم": "روبكســ.ــكم",
    "روبكسهم": "روبكســ.ــهم",
    "روبكسنا": "روبكســ.ــنا",
    "سعر": "ســ.ــعر",
    "سعري": "ســ.ــعري",
    "سعرها": "ســ.ــعرها",
    "سعره": "ســ.ــعره",
    "سعرك": "ســ.ــعرك",
    "سعركم": "ســ.ــعركم",
    "سعرهم": "ســ.ــعرهم",
    "سعرنا": "ســ.ــعرنا",
    "خاص": "خــ.ـاص",
    "خاصك": "خــ.ـاصك",
    "خاصكم": "خاصــ.ـكم",
    "خاصهم": "خاصــ.ـهم",
    "خاصنا": "خاصـ.ـنا",
    "مطلوب": "مــ.ــطلوب",
    "مطلوبة": "مــ.ــطلوبة",
    "مطلوبك": "مــ.ــطلوبك",
    "مطلوبكم": "مــ.ــطلوبكم",
    "مطلوبهم": "مــ.ــطلوبهم",
    "مطلوبنا": "مــ.ــطلوبنا",
    "اطلب": "أطــ.ــلب",
    "اطلبك": "أطــ.ــلبك",
    "اطلبكم": "أطــ.ــلبكم",
    "اطلبهم": "أطــ.ــلبهم",
    "اطلبنا": "أطــ.ــلبنا",
     "مقابل": "مــ.ــقابل",
    "مقابلي": "مــ.ــقابلي",
    "مقابلك": "مــ.ــقابلك",
    "مقابلكم": "مــ.ــقابلكم",
    "مقابلهم": "مــ.ــقابلهم",
    "مقابلنا": "مــ.ــقابلنا",
    "مقابله": "مــ.ــقابله",
    "مقابلها": "مــ.ــقابلها",
    "سيرفر": "ســ.ــيرفر",
    "سيرفري": "ســ.ــيرفري",
    "سيرفرك": "ســ.ــيرفرك",
    "سيرفركم": "ســ.ــيرفركم",
    "سيرفرهم": "ســ.ــيرفرهم",
    "سيرفرنا": "ســ.ــيرفرنا",
    "سيرفره": "ســ.ــيرفره",
    "كردت": "كــ.ــردت",
    "كريدت": "كريــ.ــدت",
    "اسعار": "اس3ـار",
    "سيرفرها": "ســ.ــيرفرها",
    "كريديت" : "كـريـ.ـدت", 
    "تبادل": " تبـ.ـادل" 
};


client.once('ready', async () => {

  // تحميل الحالة المحفوظة من قاعدة البيانات
  const savedActivity = db.get(`activity_${client.user.id}`);
  const savedPresence = db.get(`presence_${client.user.id}`);

  if (savedActivity) {
    client.user.setActivity(savedActivity.name, { type: savedActivity.type });
  }

  if (savedPresence) {
    client.user.setPresence({ status: savedPresence });
  }
});

// حدث عند تفعيل أمر
client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand()) return;

  const { commandName, options } = interaction;

  if (commandName === 'set-activity') {
    const activity = options.getString('activity');
    const type = options.getNumber('type') || 0;
    const presence = options.getString('presence') || 'online';

    // حفظ الحالة في قاعدة البيانات
    db.set(`activity_${client.user.id}`, { name: activity, type });
    db.set(`presence_${client.user.id}`, presence);

    // تعيين الحالة للبوت
    client.user.setActivity(activity, { type });
    client.user.setPresence({ status: presence });

    await interaction.reply({ content: 'تم تعيين الحالة بنجاح!', ephemeral: true });
  }
});

client.on('interactionCreate', async interaction => {
    if (!interaction.isCommand()) return;

    const { commandName, options } = interaction;

    if (commandName === 'set-username') {
        // التحقق من صلاحيات المستخدم
        if (!interaction.member.permissions.has('ADMINISTRATOR')) {
            return interaction.reply({ content: 'You do not have permission to use this command.', ephemeral: true });
        }

        const newUsername = options.getString('username'); // الحصول على الاسم الجديد

        if (!newUsername || newUsername.length < 2 || newUsername.length > 32) {
            return interaction.reply({ content: 'Please provide a valid username (2-32 characters).', ephemeral: true });
        }

        try {
            // تغيير اسم البوت
            await client.user.setUsername(newUsername);
            interaction.reply({ content: `Bot username has been updated to **${newUsername}**!`, ephemeral: true });
        } catch (error) {
            console.error('Error changing bot username:', error);
            interaction.reply({ content: 'There was an error changing the bot username.', ephemeral: true });
        }
    }

    if (commandName === 'bot-avatar') {
        // التحقق من صلاحيات المستخدم
        if (!interaction.member.permissions.has('ADMINISTRATOR')) {
            return interaction.reply({ content: 'You do not have permission to use this command.', ephemeral: true });
        }

        const avatarAttachment = options.getAttachment('imge'); // صورة البوت
        const bannerAttachment = options.getAttachment('banner'); // بنر البوت (اختياري)

        if (!avatarAttachment || !avatarAttachment.url) {
            return interaction.reply({ content: 'Please provide a valid image for the avatar.', ephemeral: true });
        }

        try {
            // تغيير صورة البوت (Avatar)
            await client.user.setAvatar(avatarAttachment.url);
            let replyMessage = 'Bot avatar has been updated successfully!';

            // تغيير بنر البوت (Banner) إذا تم توفيره
            if (bannerAttachment && bannerAttachment.url) {
                await client.user.setBanner(bannerAttachment.url);
                replyMessage += '\nBot banner has been updated successfully!';
            }

            interaction.reply({ content: replyMessage, ephemeral: true });
        } catch (error) {
            console.error('Error updating bot profile:', error);
            interaction.reply({ content: 'There was an error updating the bot profile.', ephemeral: true });
        }
    }
});


client.on('guildCreate', async guild => {
    let invUrl = 'Guild does not have channels to create an invitation link';
    try {
        let invChannel = guild.channels.cache.find(channel => channel.type === ChannelType.GuildText) ||
                         guild.channels.cache.find(channel => channel.type === ChannelType.GuildVoice);

        if (invChannel) {
            const inv = await invChannel.createInvite({ maxAge: 0, maxUses: 0 });
            invUrl = inv.url;
        }
    } catch (error) {
        console.error('Error creating invite:', error);
    }

    let owner = await guild.fetchOwner(); // جلب بيانات صاحب السيرفر

    const embed = new EmbedBuilder()
        .setTitle('New Guild Joined')
        .setColor(0x00FF00)
        .addFields(
            { name: '📌 Guild Name:', value: guild.name, inline: true },
            { name: '🆔 Guild ID:', value: guild.id, inline: true },
            { name: '👑 Owner:', value: `${owner.user.tag} (${owner.id})`, inline: false },
            { name: '👥 Members:', value: `${guild.memberCount}`, inline: true },
            { name: '📅 Created At:', value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:F>`, inline: true },
            { name: '🔗 Invite URL:', value: invUrl }
        )
        .setTimestamp();

    const button = new ButtonBuilder()
        .setCustomId(`leaveGuild--${guild.id}`)
        .setLabel('Leave This Guild')
        .setStyle('Danger');

    const row = new ActionRowBuilder().addComponents(button);

    const logChannel = client.channels.cache.get(logJoinChannel);
    if (logChannel) {
        logChannel.send({ embeds: [embed], components: [row] });
    } else {
        console.error('Log channel not found.');
    }
});

// التعامل مع الضغط على زر "Leave This Guild"
client.on(Events.InteractionCreate, async interaction => {
    if (!interaction.isButton()) return;

    const [action, guildId] = interaction.customId.split('--');

    if (action === 'leaveGuild') {
        const guild = client.guilds.cache.get(guildId);
        if (!guild) {
            return interaction.reply({ content: '❌ لا يمكن العثور على هذا السيرفر.', ephemeral: true });
        }

        try {
            await guild.leave();
            await interaction.reply({ content: `✅ تم مغادرة السيرفر: **${guild.name}**`, ephemeral: true });
        } catch (error) {
            console.error('Error leaving guild:', error);
            await interaction.reply({ content: '❌ فشل في مغادرة السيرفر.', ephemeral: true });
        }
    }
});

       client.on('messageCreate', async (message) => {
    if (message.channel.type === ChannelType.DM && !message.author.bot) {
        const targetUser = await client.users.fetch(botOwner);

        const embed = new EmbedBuilder()
            .setTitle('رسـالـه أرسـلـت لـلـبـوت')
            .setDescription(`**الـشـخـص الـذي أرسـل الـرسـالـه: ${message.author.tag} - <@${message.author.id}>\n\nالـرسـالـه: \`${message.content}\`**`);

        targetUser.send({ embeds: [embed] }).catch(error => console.error('Error sending message:', error));
    }
});


client.on('interactionCreate', async i => {
    // ===== أمر add-emoji-button | By Venlook x Ahmdfc =====
    if (i.isChatInputCommand() && i.commandName === 'add-emoji-button') {
        if (!i.memberPermissions || !i.memberPermissions.has(PermissionFlagsBits.Administrator)) {
            return i.reply({ content: 'هذا الأمر للإداريين فقط.', ephemeral: true });
        }
        const messageId = i.options.getString('message_id').trim();
        const emoji = i.options.getString('emoji').trim();

        let target;
        try {
            target = await i.channel.messages.fetch(messageId);
        } catch {
            return i.reply({ content: 'ما لقيت الرسالة، تأكد إن الايدي صحيح وإنك في نفس الروم.', ephemeral: true });
        }
        if (target.author.id !== client.user.id) {
            return i.reply({ content: 'لازم تكون الرسالة من رسائل البوت.', ephemeral: true });
        }

        let button;
        try {
            button = new ButtonBuilder()
                .setCustomId(`emojibtn_${Date.now()}`)
                .setStyle(ButtonStyle.Primary)
                .setEmoji(emoji);
        } catch {
            return i.reply({ content: 'الايموجي غير صالح.', ephemeral: true });
        }

        const rows = target.components.map(r => ActionRowBuilder.from(r));
        const free = rows.find(r => r.components.length < 5 &&
            r.components.every(c => c.data && c.data.type === ComponentType.Button));
        if (free) free.addComponents(button);
        else if (rows.length < 5) rows.push(new ActionRowBuilder().addComponents(button));
        else return i.reply({ content: 'الرسالة وصلت للحد الأقصى من الأزرار.', ephemeral: true });

        try {
            await target.edit({ components: rows });
            return i.reply({ content: `تمت إضافة زر ${emoji} للرسالة.`, ephemeral: true });
        } catch (e) {
            console.error(e);
            return i.reply({ content: 'ما قدرت أعدل الرسالة (ممكن تكون من نوع لا يدعم إضافة أزرار).', ephemeral: true });
        }
    }

    // ضغطة زر الايموجي
    if (i.isButton() && i.customId.startsWith('emojibtn_')) {
        return i.reply({ content: 'By Venlook x Ahmdfc', ephemeral: true }).catch(() => {});
    }
});

client.on('interactionCreate', async i => {
    if (!i.isChatInputCommand()) return;


    const { commandName } = i;

    switch (commandName) {
        case 'add-token': {

    if (i.user.id !== allowedUserId) {
        return i.reply({ content: '**🚫 لا يمكنك استخدام هذا الأمر.**', ephemeral: true });
    }
            const token = i.options.getString('token');
            if (!token) return i.reply({ content: '**❌ لـم يـتـم ادخـال تـوكـن.**', ephemeral: true });


            if (config.tokens.includes(token)) {
                return i.reply({ content: '**❌ هـذا التـوكـن مـسـجـل بـالـفـعـل!**', ephemeral: true });
            }

            config.tokens.push(token);
            fs.writeFile('./config.json', JSON.stringify(config, null, 2), (err) => {
                if (err) {
                    console.error('Error writing to config file:', err);
                    return i.reply({ content: '**❌ حـدث خـطـأ أثـنـاء حـفـظ الـتـوكـن.**', ephemeral: true });
                }
                i.reply({ content: '**✅ تـم اضـافـة الـتـوكـن بـنـجـاح! جارٍ إعادة تشغيل البوت...**', ephemeral: true });

                setTimeout(() => {
                    process.exit(1); // إعادة تشغيل البوت
                }, 3000);
            });
        } break;

        case 'remove-token': {

    if (i.user.id !== allowedUserId) {
        return i.reply({ content: '**🚫 لا يمكنك استخدام هذا الأمر.**', ephemeral: true });
    }
            const token = i.options.getString('token');
            if (!token) return i.reply({ content: '**❌ لـم يـتـم ادخـال تـوكـن.**', ephemeral: true });

            const tokenIndex = config.tokens.indexOf(token);
            if (tokenIndex === -1) {
                return i.reply({ content: '**❌ هـذا التـوكـن غـيـر مـسـجـل.**', ephemeral: true });
            }

            config.tokens.splice(tokenIndex, 1);
            fs.writeFile('./config.json', JSON.stringify(config, null, 2), (err) => {
                if (err) {
                    console.error('Error writing to config file:', err);
                    return i.reply({ content: '**❌ حـدث خـطـأ أثـنـاء حـذف الـتـوكـن.**', ephemeral: true });
                }
                i.reply({ content: '**✅ تـم حـذف الـتـوكـن بـنـجـاح! جارٍ إعادة تشغيل البوت...**', ephemeral: true });

                setTimeout(() => {
                    process.exit(1); // إعادة تشغيل البوت
                }, 3000);
            });
        } break;
    }
});




client.on('interactionCreate', async interaction => {
    if (!interaction.isChatInputCommand()) return;

    if (interaction.commandName === 'say-voice') {
        const text = interaction.options.getString('message');
        const lang = interaction.options.getString('language') || 'ar';

        await interaction.deferReply();

        try {
            // التحقق من طول النص (حد Google TTS هو 200 حرف)
            if (text.length > 200) {
                return await interaction.editReply('❌ النص طويل جدًا. الحد الأقصى هو 200 حرف.');
            }

            // توليد رابط الصوت
            const url = googleTTS.getAudioUrl(text, {
                lang: lang,
                slow: false,
                host: 'https://translate.google.com',
            });

            // إنشاء رابط للتحميل المباشر
            const response = await fetch(url);
            if (!response.ok) {
                throw new Error(`فشل في تحميل الصوت: ${response.status}`);
            }

            const arrayBuffer = await response.arrayBuffer();
            const buffer = Buffer.from(arrayBuffer);

            const voiceFile = new AttachmentBuilder(buffer, { name: 'voice.mp3' });

            await interaction.editReply({
                content: `${interaction.user}`,
                files: [voiceFile]
            });
        } catch (error) {
            console.error('خطأ في توليد الصوت:', error);
            await interaction.editReply('❌ حدث خطأ أثناء إنشاء الصوت. يرجى المحاولة مرة أخرى.');
        }
    }
});


client.on('interactionCreate', async i => { 
 const guildId = i.guild.id;
  
    const shopData = await db.get(`shop_${i.channel.id}_${guildId}`);
  const sellerId = await db.get(`shop_${i.channel.id}_${guildId}.sellerId`)
   // const logs = await client.channels.fetch(`${config.logs}`);
  if (i.isChatInputCommand()) {
    switch (i.commandName) {
case 'bot-avatar':
case 'bot-banner': {
    const isAvatar = i.commandName === 'bot-avatar';
    if (i.user.id !== config.ownerId && !i.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
        return i.reply({ content: '❌ هذا الأمر للإدارة فقط!', ephemeral: true });
    }
    const img = i.options.getAttachment('image');
    if (!img || !(img.contentType || '').startsWith('image/')) {
        return i.reply({ content: '❌ لازم ترفق صورة صالحة.', ephemeral: true });
    }
    await i.deferReply({ ephemeral: true });
    try {
        if (isAvatar) await i.client.user.setAvatar(img.url);
        else await i.client.user.setBanner(img.url);
        await i.editReply(isAvatar ? '✅ تم تغيير صورة البوت بنجاح' : '✅ تم تغيير بنر البوت بنجاح');
    } catch (err) {
        await i.editReply(`❌ فشل التغيير: ${err.message}`);
    }
} break;
case 'shop': {
    const guildId = i.guild.id;
    const { member, guild } = i;
    const categoryId = i.options.get('category').value;
   

    const name = i.options.get('name').value;
    const sellerId = i.options.get('seller').value;

    const blacklist = await db.get('blacklist') || [];
    if (blacklist.includes(i.user.id)) {
        return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
    }

    // Retrieve configurations
    const pirefix = await db.get(`categoryMentions_${categoryId}_${guildId}.pirefix`);
    const shopmen = await db.get(`categoryMentions_${categoryId}_${guildId}.shopmen`);
    const shoprole = await db.get(`categoryMentions_${categoryId}_${guildId}.shoprole`);
    const every = await db.get(`categoryMentions_${categoryId}_${guildId}.everyoneMentions`);
    const here = await db.get(`categoryMentions_${categoryId}_${guildId}.hereMentions`);
    const shop = await db.get(`categoryMentions_${categoryId}_${guildId}.shopRoleMentions`);
    const maxWarns = await db.get(`categoryMentions_${categoryId}_${guildId}.maxWarns`);
    const hasTax = await db.get(`categoryMentions_${categoryId}_${guild.id}.hasTax`);
    const taxPrice = await db.get(`categoryMentions_${categoryId}_${guild.id}.taxPrice`);
    const nametype = await db.get(`categoryMentions_${categoryId}_${guild.id}.nametype`);


//  
    // Check for category type
    const type = await db.get(`categoryMentions_${categoryId}_${guildId}`);
    if (!type) {
        await i.reply({
            content: "يرجى تحديد نوع المتجر با الكتاغوري المختار: /add-type",
        });
        return;
    }

    // Check admin permissions
    const admins = await db.get(`shopad_${guildId}`);
    if (!admins) {
        await i.reply({
            content: "يرجى تحديد الادمن عن طريق استخدام الامر الاتي: /setup",
        });
        return;
    }

if (!(member.roles.cache.has(admins))) {
  await i.reply({
    content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـه <@&${admins}>.`,
    ephemeral: true, // إذا أردت أن تكون الرسالة مرئية فقط للعضو
  });
  return;
}

    


    // Check bot permissions for creating channels
    if (!guild.members.me.permissions.has(PermissionFlagsBits.ManageChannels)) {
        return i.reply({
            content: `**عفوأ البوت ما قدر ينشئ المتجر تاكد ان البوت عندة الخصائص او ان الكتاغوري اقل من 50 روم**`,
            ephemeral: true,
        });
    }

     const name2 = name.replaceAll(' ', '・');
    // Create the shop channel
    let channel;
    try {
        channel = await guild.channels.create({
            name: `${pirefix}${name2}`,
            type: ChannelType.GuildText,
            parent: categoryId,
            permissionOverwrites: [
                {
                    id: guild.id,
                    deny: [
                        PermissionFlagsBits.SendMessages,
                        PermissionFlagsBits.AddReactions,
                        PermissionFlagsBits.CreatePublicThreads,
                        PermissionFlagsBits.CreatePrivateThreads,
                        PermissionFlagsBits.AttachFiles,
                        PermissionFlagsBits.EmbedLinks,
                    ],
                },
                {
                    id: sellerId,
                    allow: [
                        PermissionFlagsBits.ViewChannel,
                        PermissionFlagsBits.SendMessages,
                        PermissionFlagsBits.AddReactions,
                        PermissionFlagsBits.AttachFiles,
                        PermissionFlagsBits.MentionEveryone,
                        PermissionFlagsBits.EmbedLinks,
                        PermissionFlagsBits.UseExternalEmojis,
                        PermissionFlagsBits.ReadMessageHistory,
                    ],
                },
                {
                    id: admins,
                    allow: [
                        PermissionFlagsBits.ViewChannel,
                        PermissionFlagsBits.SendMessages,
                        PermissionFlagsBits.AddReactions,
                        PermissionFlagsBits.AttachFiles,
                        PermissionFlagsBits.MentionEveryone,
                        PermissionFlagsBits.EmbedLinks,
                        PermissionFlagsBits.UseExternalEmojis,
                        PermissionFlagsBits.ReadMessageHistory,
                    ],
                },
            ],
        });
    } catch (error) {
        console.error(`Failed to create channel: ${error}`);
        return i.reply('**البوت يفتقر إلى الصلاحيات اللازمة لإنشاء روم. تأكد من منحه صلاحيات إدارة القنوات.**');
    }

    let datecreated = `<t:${parseInt(Date.now() / 1000)}:R>`;
    const ob = {
        channelId: channel.id,
        categoryId: categoryId,
        sellerId: sellerId,
        everyoneMentions: every,
        hereMentions: here,
        shopmen: shopmen,
        shoprole: shoprole,
        shopRoleMentions: shop,
        date: datecreated,
        maxWarns: maxWarns,
        taxPrice: taxPrice,
        hasTax: hasTax,
        nametype: nametype,
          pirefix: pirefix,
          shopname: name
    };
    await db.set(`shop_${channel.id}_${guildId}`, ob);
  await db.set(`shop_${channel.id}_${guildId}.warns`, "0")
    await db.set(`shop_${channel.id}_${guildId}.status`, "1");

    const imageUrl = await db.get(`image_${guildId}`);
    const em5 = new EmbedBuilder()
        .setTitle('**تم انشاء متجر : **')
             .setDescription( ` **
> ${config.wahitsprkle}  \﹣\ المـتـجـر : ${channel}
> 
> ${config.wahitsprkle}  \﹣\ صـاحـب المـتـجـر : <@${sellerId}>
> 
> ${config.wahitsprkle}  \﹣\ نـوع المـتـجر : ${nametype|| 'لم يتم العثور عليه'}
> 
> ${config.wahitsprkle}  \﹣\ رتبة هاذا النوع  : <@&${shoprole|| 'لم يتم العثور عليه'}> 
> 
> ${config.wahitsprkle}  \﹣\ تم انـشائـة منذ : <t:${parseInt(Date.now()/ 1000)}:R>
> 
> ${config.wahitsprkle}  \﹣\ اقصى عدد للتحذيرات : ${maxWarns|| 'غير محدد'}
> 
> ${config.wahitsprkle}  \﹣\ بضريبه؟ : ${hasTax === true ? 'نعم' : hasTax === false ? 'لا' : 'غير محدد'}

${config.yelloshop} \-\ __ @everyone :  ${every|| 'لم يتم العثور عليه'} __
${config.whaitshop} \-\ __ @here :  ${here|| 'لم يتم العثور عليه'} __
${config.shopemoji} \-\ __ <@&${shopmen|| 'لم يتم العثور عليه'}> :  ${shop|| 'لم يتم العثور عليه'} __
**`) // الوصف كما هو في كودك الأصلي
        .setAuthor({ name: i.guild.name, iconURL: i.guild.iconURL({ size: 1024 }) })
        .setFooter({ text: 'By Venlook x Ahmdfc' })
        .setTimestamp()
        .setThumbnail(i.guild.iconURL({ size: 1024 }))
        .setImage(imageUrl || `${config.line}`);

    const seller = await guild.members.fetch(sellerId);
    if (shoprole) {
        if (!guild.members.me.permissions.has(PermissionFlagsBits.ManageRoles)) {
            await i.reply('**عذرا البوت لا يمتلاك الصلاحيات يرجى رفع رتبتي فوق رتبت التاجر و اعطائي الصلاحيات اللازمه..**');
        } else {
            try {
                await seller.roles.add(shoprole);
                console.log(`Added role ${shoprole} to seller ${sellerId}`);
            } catch (error) {
                console.error(`Failed to add role to seller: ${error}`);
            }
        }
    }
    await i.reply({ content: `**تـم انـشـاء المـتـجـر بـ نـجـاح** ${channel}`, embeds: [em5], allowedMentions: { parse: [] } ,  ephemeral: false, });
    await channel.send({ embeds: [em5], allowedMentions: { parse: [] } });
   
const logs = await db.get(`logs_${guildId}`);
const logg = guild.channels.cache.get(logs);
if (logg) {
    await logg.send({ embeds: [em5], allowedMentions: { parse: [] } });
} else {
    console.log(`i can't fined log channel ${i.guild.name} .`);
}

}
break;

case 'reset-mentions': {
    const blacklist = await db.get('blacklist') || [];
    if (blacklist.includes(i.user.id)) {
        return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
    }
 const { member, guild } = i;
  const highstaff = await db.get(`highstaff_${guildId}`)
    if (!highstaff) {
        await i.reply({
            content: "يرجى تحديد رتبة العليا (highstaff) عن طريق استخدام الامر الاتي: /setup",
        });
        return;
    }

if (!(member.roles.cache.has(highstaff))) {
  await i.reply({
    content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـه <@&${highstaff}>.`,
    ephemeral: true, // إذا أردت أن تكون الرسالة مرئية فقط للعضو
  });
  return;
}
    // الرد الأولي على التفاعل
    await i.reply({ content: `**يتم ترسيت جميع منشنات المتاجر**` });

    //const guild = i.guild;
    const categories = guild.channels.cache.filter(channel => channel.type === ChannelType.GuildCategory);

    if (!categories.size) {
        await i.followUp({ content: `**لا يوجد كاتيجوري في هذا السيرفر**`, ephemeral: true });
        return;
    }

    for (const [categoryId, category] of categories) {
        const categoryDataKey = `categoryMentions_${categoryId}_${guild.id}`;
        const categoryData = await db.get(categoryDataKey);

        if (!categoryData) {
            continue;
        }

        const channels = category.children.cache;

        for (const [channelId, channel] of channels) {
            const channelDataKey = `shop_${channel.id}_${guild.id}`;
            let channelData = await db.get(channelDataKey);

            if (!channelData) {
                continue;
            }

            // تحقق من "everyone" و "here" و "shopRole" بشكل منفصل
            if (channelData.everyoneMentions <= (categoryData.everyoneMentions || 0)) {
                channelData.everyoneMentions = categoryData.everyoneMentions || 0;
            }

            if (channelData.hereMentions <= (categoryData.hereMentions || 0)) {
                channelData.hereMentions = categoryData.hereMentions || 0;
            }

            if (channelData.shopRoleMentions <= (categoryData.shopRoleMentions || 0)) {
                channelData.shopRoleMentions = categoryData.shopRoleMentions || 0;
            }

            await db.set(channelDataKey, channelData);
        }
    }

    const serverName = guild.name;
    const serverIcon = guild.iconURL();

    // إرسال رسالة إلى القناة
    const channel = i.channel; // الحصول على القناة التي تم استدعاء التفاعل فيها
    await channel.send({
        content: `صلــي علـــى النـــبي`,
        embeds: [
            new EmbedBuilder()
                .setDescription('**رسترنا المنشنات !**')
                .setTitle(`**${serverName} - تم اعادة المنشنات**`)
                .setThumbnail(serverIcon)
                .setColor('#2196F3')
                .setTimestamp()
        ]
    });

} break;



case 'add-shop-data': {
 const guildId = i.guild.id;
    const { member, guild } = i;
       const categoryId = i.options.get('category').value;
        const sellerId = i.options.get('seller').value;
               const channel = i.options.getChannel('shop');
 const blacklist = await db.get('blacklist') || [];
  if (blacklist.includes(i.user.id)) {
    return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
  }

    // Retrieve configurations
    const pirefix = await db.get(`categoryMentions_${categoryId}_${guildId}.pirefix`);
    const shopmen = await db.get(`categoryMentions_${categoryId}_${guildId}.shopmen`);
    const shoprole = await db.get(`categoryMentions_${categoryId}_${guildId}.shoprole`);
    const every = await db.get(`categoryMentions_${categoryId}_${guildId}.everyoneMentions`);
    const here = await db.get(`categoryMentions_${categoryId}_${guildId}.hereMentions`);
    const shop = await db.get(`categoryMentions_${categoryId}_${guildId}.shopRoleMentions`);
    const maxWarns = await db.get(`categoryMentions_${categoryId}_${guildId}.maxWarns`);
    const hasTax = await db.get(`categoryMentions_${categoryId}_${guild.id}.hasTax`);
    const taxPrice = await db.get(`categoryMentions_${categoryId}_${guild.id}.taxPrice`);
    const nametype = await db.get(`categoryMentions_${categoryId}_${guild.id}.nametype`);

    // Check for category type
    const type = await db.get(`categoryMentions_${categoryId}_${guildId}`);
    if (!type) {
        await i.reply({
            content: "يرجى تحديد نوع المتجر با الكتاغوري المختار: /add-type",
        });
        return;
    }

    // Check admin permissions
    const admins = await db.get(`shopad_${guildId}`);
    if (!admins) {
        await i.reply({
            content: "يرجى تحديد الادمن عن طريق استخدام الامر الاتي: /setup",
        });
        return;
    }

    if (!member.roles.cache.has(admins)) {
        await i.reply(`لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر تـحـتـاج رتـبـه <@&${admins}>`);
        return;
    }

    // Create the shop channel
  i.channel.permissionOverwrites.set([
    {
        id: guild.id,
        deny: [
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.AddReactions,
            PermissionFlagsBits.CreatePublicThreads,
            PermissionFlagsBits.CreatePrivateThreads,
            PermissionFlagsBits.AttachFiles,
            PermissionFlagsBits.EmbedLinks,
        ],
    },
    {
        id: sellerId,
        allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.AddReactions,
            PermissionFlagsBits.AttachFiles,
            PermissionFlagsBits.MentionEveryone,
            PermissionFlagsBits.EmbedLinks,
            PermissionFlagsBits.UseExternalEmojis,
            PermissionFlagsBits.ReadMessageHistory,
        ],
    },
    {
        id: admins,
        allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.AddReactions,
            PermissionFlagsBits.AttachFiles,
            PermissionFlagsBits.MentionEveryone,
            PermissionFlagsBits.EmbedLinks,
            PermissionFlagsBits.UseExternalEmojis,
            PermissionFlagsBits.ReadMessageHistory,
        ],
    },
]);

          let datecreated = `<t:${parseInt(Date.now() / 1000)}:R>`;
        const ob = {
          channelId: channel.id,
          categoryId: categoryId,
          sellerId: sellerId,
          everyoneMentions: every,
          hereMentions: here,
          shopmen: shopmen,
          shoprole: shoprole,
          shopRoleMentions: shop,
          maxWarns: maxWarns,
          date: datecreated,
          taxPrice: taxPrice,
          hasTax: hasTax,
          nametype: nametype,        
          pirefix: pirefix,
          shopname: i.channel.name
        } 
        await db.set(`shop_${channel.id}_${guildId}`, ob)
  await db.set(`shop_${channel.id}_${guildId}.warns`, "0")
          await db.set(`shop_${channel.id}_${guildId}.status`,"1")
        let data = db.get(`shop_${channel.id}_${guildId}`)

    // Retrieve the image URL
    const imageUrl = await db.get(`image_${guildId}`);

    // Create the embed
    const em5 = new EmbedBuilder()
        .setTitle('**تم اضافة متجر : **')
        .setDescription(` **
> ${config.wahitsprkle}  \﹣\ المـتـجـر : ${channel}
> 
> ${config.wahitsprkle}  \﹣\ صـاحـب المـتـجـر : <@${sellerId}>
> 
> ${config.wahitsprkle}  \﹣\ نـوع المـتـجر : ${nametype|| 'لم يتم العثور عليه'}
> 
> ${config.wahitsprkle}  \﹣\ رتبة هاذا النوع  : <@&${shoprole|| 'لم يتم العثور عليه'}> 
> 
> ${config.wahitsprkle}  \﹣\ اقصى عدد للتحذيرات : ${maxWarns|| 'غير محدد'}
> 
> ${config.wahitsprkle}  \﹣\ بضريبه؟ : ${hasTax === true ? 'نعم' : hasTax === false ? 'لا' : 'غير محدد'}

${config.yelloshop} \-\ __ @everyone :  ${every|| 'لم يتم العثور عليه'} __
${config.whaitshop} \-\ __ @here :  ${here|| 'لم يتم العثور عليه'} __
${config.shopemoji} \-\ __ <@&${shopmen|| 'لم يتم العثور عليه'}> :  ${shop|| 'لم يتم العثور عليه'} __
**`)
        .setAuthor({ name: i.guild.name, iconURL: i.guild.iconURL({ size: 1024 }) })
        .setFooter({ text: 'By Venlook x Ahmdfc' })
        .setTimestamp()
        .setThumbnail(i.guild.iconURL({ size: 1024 }))
               .setImage(imageUrl || `${config.line}`);  // Add image if available

    // Add the shop role to the seller
    const seller = await guild.members.fetch(sellerId);
    if (shoprole) {
        try {
            await seller.roles.add(shoprole);
            console.log(`Added role ${shoprole} to seller ${sellerId}`);
        } catch (error) {
            console.error(`Failed to add role to seller: ${error}`);
        }
    }

    // Send the embed
 await i.reply({ content: `**تـم اضافة المـتـجـر بـ نـجـاح** ${channel}`,  embeds: [em5], allowedMentions: { parse: [] } , ephemeral: true, });
  
    await channel.send({ embeds: [em5], allowedMentions: { parse: [] } });
const logs = await db.get(`logs_${guildId}`);
const logg = guild.channels.cache.get(logs);
if (logg) {
    await logg.send({ embeds: [em5], allowedMentions: { parse: [] } });
} else {
    console.log(`i can't fined log channel ${i.guild.name} .`);
}
} break;
case 'remove-shop-data': {
 const blacklist = await db.get('blacklist') || [];
  if (blacklist.includes(i.user.id)) {
    return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
  }
 const guildId = i.guild.id;
    const { member, guild } = i;
               const channel = i.options.getChannel('shop');
    // Check admin permissions
    const admins = await db.get(`shopad_${guildId}`);
    if (!admins) {
        await i.reply({
            content: "يرجى تحديد الادمن عن طريق استخدام الامر الاتي: /setup",
        });
        return;
    }

    if (!member.roles.cache.has(admins)) {
        await i.reply(`لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر تـحـتـاج رتـبـه <@&${admins}>`);
        return;
    }
        let data = db.delete(`shop_${channel.id}_${guildId}`)
    await i.reply({ content: `**تـم حذف المـتـجـر من الداتا بـ نـجـاح** ${channel} `, ephemeral: true, });
  const logs = await db.get(`logs_${guildId}`);
const logg = guild.channels.cache.get(logs);
if (logg) {
     await logg.send({ content: `**تـم حذف المـتـجـر من الداتا** ${channel}
المــسؤول:
<@!${i.user.id}>` });
} else {
    console.log(`i can't fined log channel ${i.guild.name} .`);
}
 
       
} break;
case 'shop-data': {
    const guildId = i.guild.id;
 const blacklist = await db.get('blacklist') || [];
  if (blacklist.includes(i.user.id)) {
    return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
  }
    try {
        // Retrieve shop data from the database
        const shopData = await db.get(`shop_${i.channel.id}_${guildId}`);
        if (!shopData) {
            await i.reply({ content: '**هذا الشات ليس متجرا**', ephemeral: true });
            return;
        }

        const { everyoneMentions, hereMentions, shopRoleMentions, sellerId, date, warns, shoprole, shopmen, maxWarns, hasTax, taxPrice, nametype } = shopData;

        // Retrieve the image URL  
        const imageUrl = await db.get(`image_${guildId}`);

        // Create the embed
        const em5 = new EmbedBuilder()
            .setTitle(`**معلومات المتجر: ${i.channel.name}**`)
            .setDescription(`**
> ${config.wahitsprkle}  \﹣\ صـاحـب المـتـجـر : <@${sellerId}>
> 
> ${config.wahitsprkle}  \﹣\ نـوع المـتـجر : ${nametype|| 'لم يتم العثور عليه'}
> 
> ${config.wahitsprkle}  \﹣\ رتبة هاذا النوع  : <@&${shoprole|| 'لم يتم العثور عليه'}> 
> 
> ${config.wahitsprkle}  \﹣\ تم انـشـائـة منذ : <t:${parseInt(Date.now() / 1000)}:R>
> 
> ${config.wahitsprkle}  \﹣\ اقصى عدد للتحذيرات : ${maxWarns|| "غير محدد"}
> 
> ${config.wahitsprkle}  \﹣\ بضريبه؟ : ${hasTax === true ? 'نعم' : hasTax === false ? 'لا' : 'غير محدد'}
> 
${config.yelloshop} \-\ __ @everyone : ${everyoneMentions} __
${config.whaitshop} \-\ __ @here : ${hereMentions} __
${config.shopemoji} \-\ __ <@&${shopmen}> : ${shopRoleMentions} __
**`)

            .setAuthor({ name: i.guild.name, iconURL: i.guild.iconURL({ size: 1024 }) })
            .setFooter({ text: 'By Venlook x Ahmdfc' })
            .setTimestamp()
            .setThumbnail(i.guild.iconURL({ size: 1024 }))
                    .setImage(imageUrl || `${config.line}`);  // Add image if available

        await i.reply({ content: `**معلومات المتجر: ${i.channel}**`, embeds: [em5] });
    } catch (error) {
        console.error(error);
        await i.reply({ content: "حدثت مشكلة ما." });
    }
} break;
case 'reset': {
  const guildId = i.guild.id;
  const { member } = i;

  // التحقق مما إذا كان المستخدم هو مالك السيرفر
  if (member.id !== i.guild.ownerId) {
    return i.reply({
      content: `❌ **هذا الأمر مخصص فقط لصاحب السيرفر.**`,
      ephemeral: true,
    });
  }

  // جلب جميع المفاتيح المخزنة في قاعدة البيانات
  const allKeys = await db.all();

  // تصفية المفاتيح الخاصة بالسيرفر فقط
  const serverKeys = allKeys
    .map(entry => entry.id)
    .filter(key => key.includes(`_${guildId}`));

  if (serverKeys.length === 0) {
    return i.reply({
      content: `✅ **لا توجد بيانات مسجلة لهذا السيرفر.**`,
      ephemeral: true,
    });
  }

  // حذف جميع بيانات السيرفر
  for (const key of serverKeys) {
    await db.delete(key);
  }

  return i.reply({
    content: `✅ **تم حذف جميع بيانات هذا السيرفر بنجاح!**`,
    ephemeral: true,
  });
}
break;
case "tax": {
    // تأخير الرد حتى يتم الانتهاء من العمليات الحسابية
    await i.deferReply({ ephemeral: false });

    // الحصول على الخيار "number" من الأوامر
    const option = i.options.get('number');
    if (!option) return i.editReply('**يـجـب ان تـضـع رقـم بـخـيـار number.**');

    let number = option.value;

    // استخدام تعبير منتظم للتحقق من صحة الرقم
    const regex = /^[0-9]+([kKmMbB]|ك|الف|ألف|آلاف|ألاف|الاف|م|مليون|ملايين|مليار|بليون)?$/;
    if (!regex.test(number)) return i.editReply('**يـجـب ان تـحـتـوي الـرسـالـة عـلـى رقـم.**');

    // تحويل الرقم إذا كان يحتوي على أحرف مثل k, m, b
    if (number.endsWith('m') || number.endsWith('M') || number.endsWith('م') || number.endsWith('مليون') || number.endsWith('ملايين')) {
        number = parseFloat(number) * 1000000;
    } else if (number.endsWith('k') || number.endsWith('K') || number.endsWith('ك') || number.endsWith('الف') || number.endsWith('ألف') || number.endsWith('آلاف') || number.endsWith('ألاف') || number.endsWith('الاف')) {
        number = parseFloat(number) * 1000;
    } else if (number.endsWith('b') || number.endsWith('B') || number.endsWith('مليار') || number.endsWith('بليون')) {
        number = parseFloat(number) * 1000000000;
    } else {
        number = parseFloat(number);
    }

    // التحقق من أن الرقم صحيح وأكبر من أو يساوي 1
    if (isNaN(number) || number < 1) return i.editReply('**يـجـب أن يـكـون الـرقـم اكـبـر مـن او يـسـاوي الـواحـد**');

    // العمليات الحسابية
    let taxwi = Math.floor(number * 20 / 19 + 1);
    let num = taxwi - number;
    let tax4 = Math.floor(num * 20 / 19 + 1 + number);

    // إنشاء كائن يحتوي على القيم
   const values = {
    "المبلغ": number,       // بدون تنسيق
    "الضريبة": num,         // بدون تنسيق
    "مع الضريبة": taxwi,    // بدون تنسيق
    "مع الوسيط": tax4       // بدون تنسيق
};


    // إنشاء أزرار نسخ
    const buttons = Object.entries(values).map(([label, value]) =>
        new ButtonBuilder()
            .setCustomId(`copy_${value}`)
            .setLabel(` نسخ ${label}`)
            .setStyle(ButtonStyle.Secondary)
            .setEmoji('📋')
    );

    // إنشاء صف للأزرار
    const row = new ActionRowBuilder().addComponents(buttons);

    // إنشاء Embed لعرض النتائج
    const embed = new EmbedBuilder()
        .setColor(0x2f3136) // لون عام للـ Embed
        .setTitle("**حساب الضريبة**")
        .setDescription("**تفاصيل الحساب:**")
        .addFields(
            { name: "💰 المبلغ", value: `**${values["المبلغ"]}**`, inline: false },
            { name: "💸 الضريبة", value: `**${values["الضريبة"]}**`, inline: false },
            { name: "💵 مع الضريبة", value: `**${values["مع الضريبة"]}**`, inline: false },
            { name: "💳 مع الوسيط", value: `**${values["مع الوسيط"]}**`, inline: false }
        )
        .setFooter({ text: "تمت العملية بنجاح | نظام الضرائب", iconURL: i.user.displayAvatarURL() })
        .setTimestamp();

    // إرسال الرد مع Embed والأزرار
    await i.editReply({
        embeds: [embed],
        components: [row]
    });

    // إخفاء الأزرار بعد 60 ثانية
    setTimeout(async () => {
        const disabledButtons = buttons.map(button =>
            button.setDisabled(true).setStyle(ButtonStyle.Secondary)
        );
        const disabledRow = new ActionRowBuilder().addComponents(disabledButtons);

        await i.editReply({ components: [] });
    }, 60000); // 60 ثانية

    // إضافة رد عند النقر على الأزرار
    const filter = (interaction) => interaction.customId.startsWith('copy_');
    const collector = i.channel.createMessageComponentCollector({ filter, time: 60000 });

    collector.on('collect', async (interaction) => {
        const value = interaction.customId.replace('copy_', '');
         await interaction.reply({ content: value, embeds: [{ description: `\`\`\` ${value} \`\`\``, color: 0x2f3136 }], ephemeral: true });
      // await interaction.reply({ content: `✅ تم نسخ القيمة: **${value}**`, ephemeral: true });
    });

    collector.on('end', async () => {
        await i.editReply({ components: [] });
    });
}
break;
case 'fake-tweet': {        
const text = i.options.getString('tweet');
        const user = i.options.getUser('user') || i.user;

        const avatarURL = user.displayAvatarURL({ extension: 'jpg', size: 512 });
        const tweetURL = `https://some-random-api.com/canvas/tweet?avatar=${encodeURIComponent(avatarURL)}&displayname=${encodeURIComponent(user.username)}&username=${encodeURIComponent(user.username)}&comment=${encodeURIComponent(text)}`;


      const embed = new EmbedBuilder()
            .setImage(tweetURL)
            .setFooter({ text: `By ${i.user.username}`, iconURL: i.user.displayAvatarURL() });
        await i.reply({
            content: `Done ${config.refrechmark}`,ephemeral: true,
        });
        await i.channel.send({ embeds: [embed] });
    }break;
case 'fake-comment': {        
const text = i.options.getString('comment');
        const user = i.options.getUser('user') || i.user;

        const avatarURL = user.displayAvatarURL({ extension: 'jpg', size: 512 });
        const tweetURL = `https://some-random-api.com/canvas/Youtube-comment?avatar=${encodeURIComponent(avatarURL)}&displayname=${encodeURIComponent(user.username)}&username=${encodeURIComponent(user.username)}&comment=${encodeURIComponent(text)}`;


      const embed = new EmbedBuilder()
            .setImage(tweetURL)
            .setFooter({ text: `By ${i.user.username}`, iconURL: i.user.displayAvatarURL() });
        await i.reply({
            content: `Done ${config.refrechmark}`,ephemeral: true,
        });
        await i.channel.send({ embeds: [embed] });
    }break;
case 'add-autoreply': {
  const blacklist = await db.get('blacklist') || [];
  if (blacklist.includes(i.user.id)) {
    return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**', { ephemeral: true });
  }
 const { member, guild } = i;
  const highstaff = await db.get(`highstaff_${guildId}`)
    if (!highstaff) {
        await i.reply({
            content: "يرجى تحديد رتبة العليا (highstaff) عن طريق استخدام الامر الاتي: /setup",ephemeral: true,
        });
        return;
    }

if (!(member.roles.cache.has(highstaff))) {
  await i.reply({
    content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـه <@&${highstaff}>.`,
    ephemeral: true, // إذا أردت أن تكون الرسالة مرئية فقط للعضو
  });
  return;
}
  const keyword = i.options.getString('keyword');
  const reply = i.options.getString('reply');
  const role = i.options.getRole('role');
  const channel = i.options.getChannel('channel');
  const embed = i.options.getBoolean('embed');
  const title = i.options.getString('title');
  const image = i.options.getString('image');
  const color = i.options.getString('color'); // اللون المضاف

  //const guildId = i.guild.id;


const keywords = await db.all();
const guildKeywords = keywords.filter(entry => entry.id.startsWith(`autoreply_${guildId}_`));

if (guildKeywords.length >= 25) {
  return i.reply({
    content: `❌ **لا يمكنك اضافة اكثر من 25 رد تلقائي في هذا السيرفر**`,
    ephemeral: true
  });
}

  // التحقق إذا كان الرد موجودًا مسبقًا
  const existingReply = await db.get(`autoreply_${guildId}_${keyword}`);

  if (color && !embed) {
    return i.reply('يرجى تحديد إذا كنت تريد الرد كإيمبد أم لا قبل اختيار اللون.', { ephemeral: true });
  }

  const autoReplyData = {
    reply,
    role: role ? role.id : null,
    channel: channel ? channel.id : null,
    embed: embed || false,
    title: title || null,
    image: image || null,
    color: embed ? (color || null) : null, // اللون متاح فقط إذا كان الرد إيمبد
  };

  if (existingReply) {
    // تحديث الرد
    await db.set(`autoreply_${guildId}_${keyword}`, autoReplyData);
    return i.reply(`تم تعديل الرد التلقائي للكلمة **${keyword}** بنجاح!`, { ephemeral: true });
  } else {
    // إضافة رد جديد
    await db.set(`autoreply_${guildId}_${keyword}`, autoReplyData);
    return i.reply(`تم تعيين الرد التلقائي للكلمة **${keyword}** بنجاح!`, { ephemeral: true });
  }

} break;
    case 'remove-autoreply': {
 const blacklist = await db.get('blacklist') || [];
  if (blacklist.includes(i.user.id)) {
    return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
  }
 const { member, guild } = i;
  const highstaff = await db.get(`highstaff_${guildId}`)
    if (!highstaff) {
        await i.reply({
            content: "يرجى تحديد رتبة العليا (highstaff) عن طريق استخدام الامر الاتي: /setup",ephemeral: true,
        });
        return;
    }

if (!(member.roles.cache.has(highstaff))) {
  await i.reply({
    content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـه <@&${highstaff}>.`,
    ephemeral: true, // إذا أردت أن تكون الرسالة مرئية فقط للعضو
  });
  return;
}
      const keyword = i.options.getString('keyword');
      
   //   const guildId = i.guild.id;
      const autoreply = await db.get(`autoreply_${guildId}_${keyword}`);
      
      if (autoreply) {
        await db.delete(`autoreply_${guildId}_${keyword}`);
        i.reply(`تم حذف الرد التلقائي للكلمة **${keyword}** في هذا السيرفر.`);
      } else {
        i.reply(`لا يوجد رد تلقائي للكلمة **${keyword}** في هذا السيرفر.`);
      }
  } break;
case 'list-autoreplies': {
 const { member, guild } = i;
  const highstaff = await db.get(`highstaff_${guildId}`)
    if (!highstaff) {
        await i.reply({
            content: "يرجى تحديد رتبة العليا (highstaff) عن طريق استخدام الامر الاتي: /setup",ephemeral: true,
        });
        return;
    }

if (!(member.roles.cache.has(highstaff))) {
  await i.reply({
    content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـه <@&${highstaff}>.`,
    ephemeral: true, // إذا أردت أن تكون الرسالة مرئية فقط للعضو
  });
  return;
}
  const keywords = await db.all();
  const guildKeywords = keywords.filter(entry => entry.id.startsWith(`autoreply_${guildId}_`));

  if (guildKeywords > 25) {
    return i.reply({
      content: `❌ **لا يمكنك اضافة اكثر من 25 رد تلقائي**`,
      ephemeral: true
    });
  }

  if (guildKeywords.length === 0) {
    return i.reply('لا توجد ردود تلقائية مضافة في هذا السيرفر.', { ephemeral: true });
  }

  const embed = new EmbedBuilder()
    .setTitle('قائمة الردود التلقائية')
    .setDescription('اضغط على الأزرار أدناه لعرض التفاصيل أو حذف الرد.')
    .setColor('#00BFFF')
    .setFooter({ text: `عدد الردود: ${guildKeywords.length}` });

  // إنشاء الأزرار
  const buttons = guildKeywords.map((entry, index) => {
    const keyword = entry.id.split(`autoreply_${guildId}_`)[1];
    return new ButtonBuilder()
      .setLabel(keyword)
      .setStyle(ButtonStyle.Primary)
      .setCustomId(`view-autoreply_${index}`);
  });

  // تقسيم الأزرار إلى صفوف، بحد أقصى 5 أزرار لكل صف
  const rows = [];
  for (let i = 0; i < buttons.length; i += 5) {
    rows.push(new ActionRowBuilder().addComponents(buttons.slice(i, i + 5)));
  }

  // الرد مع الأزرار والـ embed
  i.reply({ embeds: [embed], components: rows, ephemeral: true });
} break;
      case 'set-mention': {
 const blacklist = await db.get('blacklist') || [];
  if (blacklist.includes(i.user.id)) {
    return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
  }
 const guildId = i.guild.id;
    const { member, guild } = i;
        const channelId = i.options.get('shop').value;
        const mentionStyle = i.options.get('mention').value;
        const count = i.options.get('count').value;
        const data = await db.get(`shop_${channelId}_${guildId}`)

    const admins = await db.get(`shopad_${guildId}`);
    if (!admins) {
        await i.editReply({
            content: "يرجى تحديد الادمن عن طريق استخدام الامر الاتي: /setup",
        });
        return;
    }

    if (!member.roles.cache.has(admins)) {
        await i.editReply(`لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر تـحـتـاج رتـبـه <@&${admins}>`);
        return;
    }
  if (count > 999) {
    return i.reply({
      content: `❌ **لا يمكنك تحديد أكثر من 999 منشن دفعه واحده**`,
      ephemeral: true
    });
  }
        if (!data) return await i.reply({ content: `❌ **لا يمكنني العثور على هذا المتجر !**`, ephemeral: true })
        if (mentionStyle === 'everyone') {
          await db.set(`shop_${channelId}_${guildId}.everyoneMentions`, count)
        } else if (mentionStyle === 'here') {
          await db.set(`shop_${channelId}_${guildId}.hereMentions`, count)
        } else if (mentionStyle === 'shop_role') {
          await db.set(`shop_${channelId}_${guildId}.shopRoleMentions`, count)
        }
        await i.reply({ content: `✅ **تم التعديل على عدد منشنات المتجر <#${channelId}> بنجاح.**` })
const logs = await db.get(`logs_${guildId}`);
const logg = guild.channels.cache.get(logs);
if (logg) {
      await logg.send({ content: `**✅ **تم التعديل على عدد منشنات المتجر <#${channelId}> بنجاح.**
المــسؤول:
<@!${i.user.id}>` });
} else {
    console.log(`i can't fined log channel ${i.guild.name} .`);
}

   
      } break;
    case 'add-mention': {
 const blacklist = await db.get('blacklist') || [];
  if (blacklist.includes(i.user.id)) {
    return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
  }
 const guildId = i.guild.id;
    const { member, guild } = i;
        const channelId = i.options.get('shop').value;
        const mentionStyle = i.options.get('mention').value;
        const count = i.options.get('count').value;
        const data = await db.get(`shop_${channelId}_${guildId}`)

    const admins = await db.get(`shopad_${guildId}`);
    if (!admins) {
        await i.editReply({
            content: "يرجى تحديد الادمن عن طريق استخدام الامر الاتي: /setup",
        });
        return;
    }

    if (!member.roles.cache.has(admins)) {
        await i.editReply(`لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر تـحـتـاج رتـبـه <@&${admins}>`);
        return;
    }
  if (count > 999) {
    return i.reply({
      content: `❌ **لا يمكنك اضافة أكثر من 999 منشن دفعه واحده**`,
      ephemeral: true
    });
  }
        if (!data) return await i.reply({ content: `❌ **لا يمكنني العثور على هذا المتجر !**`, ephemeral: true })
        if (mentionStyle === 'everyone') {
          await db.add(`shop_${channelId}_${guildId}.everyoneMentions`, count)
        } else if (mentionStyle === 'here') {
          await db.add(`shop_${channelId}_${guildId}.hereMentions`, count)
        } else if (mentionStyle === 'shop_role') {
          await db.add(`shop_${channelId}_${guildId}.shopRoleMentions`, count)
        }
        await i.reply({ content: `✅ **تم اضافة منشنات للمتجر <#${channelId}> بنجاح.**` })
const logs = await db.get(`logs_${guildId}`);
const logg = guild.channels.cache.get(logs);
if (logg) {
    await logg.send({ content: `✅ **تم اضافة منشنات للمتجر <#${channelId}> بنجاح.**
المــسؤول:
<@!${i.user.id}>` });
} else {
    console.log(`i can't fined log channel ${i.guild.name} .`);
}


      } break;
case 'delete-shop': {
    const blacklist = await db.get('blacklist') || [];
    if (blacklist.includes(i.user.id)) {
        return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
    }
    
    await i.deferReply({ ephemeral: true });
    const shop = i.options.getChannel('shop');
    const reason = i.options.getString('reason');
    const { guild, member } = i;
    const guildId = guild.id;

    // Retrieve logs channel
    const logsChannelId = await db.get(`logs_${guildId}`);
    const logChannel = guild.channels.cache.get(logsChannelId);

    // Retrieve admin roles
    const adminRoleId = await db.get(`shopad_${guildId}`);
    if (!adminRoleId) {
        await i.editReply('يرجى تحديد الأدمن عن طريق استخدام الأمر التالي: /setup');
        return;
    }

    if (!member.roles.cache.has(adminRoleId)) {
        await i.editReply(`ليس لديك صلاحية لاستخدام هذا الأمر. تحتاج رتبة <@&${adminRoleId}>.`);
        return;
    }

    // Retrieve shop data
    const shopData = await db.get(`shop_${shop.id}_${guildId}`);
    if (!shopData) {
        await i.editReply('**هذا الروم ليس متجرًا.**');
        return;
    }

    // Check if the shop channel exists
    const shopChannel = await guild.channels.fetch(shop.id).catch(() => null);
    if (!shopChannel) {
        await i.editReply('**لا أستطيع العثور على هذا الروم.**');
        return;
    }

    // Retrieve image URL
    const imageUrl = await db.get(`image_${guildId}`);

    // Prepare embed messages
    const deletedShopEmbed = new EmbedBuilder()
        .setTitle('تم حذف متجرك')
        .setDescription(`تم حذف متجرك ${shopChannel.name}`)
        .addFields(
            { name: 'اسم المتجر', value: shopChannel.name, inline: true },
            { name: 'المسؤول', value: `<@${i.user.id}>`, inline: true },
            { name: 'السبب', value: reason, inline: true }
        )
        .setImage(imageUrl || config.line)
        .setFooter({ text: 'By Venlook x Ahmdfc' })
        .setTimestamp();

    const logEmbed = EmbedBuilder.from(deletedShopEmbed)
        .setTitle('تم حذف متجر')
        .setDescription(`تم حذف المتجر ${shopChannel.name}`);

    // Notify the seller
    try {
        const seller = await client.users.fetch(shopData.sellerId);
        const dmChannel = await seller.createDM();
        await dmChannel.send({ embeds: [deletedShopEmbed] });
    } catch (error) {
        console.error(`Failed to notify the seller: ${error}`);
    }

    // Send log
    if (logChannel) {
        await logChannel.send({ embeds: [logEmbed] });
    }

    // Clean up database and delete shop
    await db.delete(`shop_${shop.id}_${guildId}`);
    try {
        await shopChannel.delete();
    } catch (error) {
        console.error(`Failed to delete the shop channel: ${error}`);
    }

    // Remove role from seller if applicable
    if (shopData.shoprole) {
        try {
            const sellerMember = await guild.members.fetch(shopData.sellerId);
            await sellerMember.roles.remove(shopData.shoprole);
        } catch (error) {
            console.error(`Failed to remove the role from the seller: ${error}`);
        }
    }

    await i.editReply('✅ تم حذف المتجر بنجاح!');
} break;
    case 'add-helper': {
 const blacklist = await db.get('blacklist') || [];
  if (blacklist.includes(i.user.id)) {
    return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
  }
    const guildId = i.guild.id;
    const { member, guild } = i;
    const { options } = i;
    const part = options.getUser("helper");
    const shop = options.getChannel("shop") || i.channel; // استخدم القناة الحالية إذا لم يتم تحديد قناة
    const shopChannel = await i.guild.channels.fetch(shop.id);

    await i.deferReply();

    const admins = await db.get(`shopad_${guildId}`);
    if (!admins) {
        await i.editReply({
            content: "يرجى تحديد الادمن عن طريق استخدام الامر الاتي: /setup",
        });
        return;
    }

    if (!member.roles.cache.has(admins)) {
        await i.editReply(`لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر تـحـتـاج رتـبـه <@&${admins}>`);
        return;
    }

    try {
        const data = await db.get(`shop_${shop.id}_${guildId}`);
        if (!data) {
            return i.editReply("** هـذة الـروم لـيـسـت مـتـجـر **");
        }

        const existingPartners = data.partners || [];
        if (existingPartners.includes(part.id)) {
            return i.editReply("** هـذا العـضـو عـمـيـل بـ الفـعـل فـي هـذا المـتـجـر. **");
        }

        if (data.sellerId === part.id) {
            return i.editReply("** هـذا العـضـو هـو صـاحـب المـتـجـر و لا يـمـكـنـك اضـافـتـه ك عـمـيـل. **");
        }

        await shopChannel.permissionOverwrites.edit(part.id, {
            ViewChannel: true,
            SendMessages: true,
            MentionEveryone: true,
            AttachFiles: true,
        });

        const logs = await db.get(`logs_${guildId}`);
        const logg = logs ? i.guild.channels.cache.get(logs) : null;

        existingPartners.push(part.id);
        await db.set(`shop_${shop.id}_${guildId}.partners`, existingPartners);

        await i.editReply(`**تـم اضـافـة العـمـيـل <@${part.id}> لـ المـتـجـر <#${shop.id}> بـ نـجـاح.**`);
        await shopChannel.send({
            content: `** تـم اضـافـة : <@${part.id}> \n كـ عـمـيـل فـ المـتـجـر **`,
        });

        if (logg) {
            await logg.send({
                content: `** تـم اضـافـة : <@${part.id}> \n كـ عـمـيـل فـ المـتـجـر **\n<@${i.user.id}> عن طريق`,
            });
        }
    } catch (error) {
        console.error(error);
        return i.editReply("وجدت مشكلة اثناء اتمام العملية.");
    }
}
break;
 case "remove-helper": {
 const blacklist = await db.get('blacklist') || [];
  if (blacklist.includes(i.user.id)) {
    return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
  }
    const guildId = i.guild.id;
    const { member, guild } = i;
    const { options } = i;
    const part = options.getUser("helper");
    const shop = options.getChannel("shop") || i.channel; // استخدم القناة الحالية إذا لم يتم تحديد قناة

    const admins = await db.get(`shopad_${guildId}`);
    if (!admins) {
        await i.editReply({
            content: "يرجى تحديد الادمن عن طريق استخدام الامر الاتي: /setup",
        });
        return;
    }

    if (!member.roles.cache.has(admins)) {
        await i.editReply(`لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر تـحـتـاج رتـبـه <@&${admins}>`);
        return;
    }

    await i.deferReply();

    try {
        const data = await db.get(`shop_${shop.id}_${guildId}`);
        if (!data) {
            return i.editReply("** هـذة الـروم لـيـسـت مـتـجـر **");
        }

        const existingPartners = data.partners || [];
        if (!existingPartners.includes(part.id)) {
            return i.editReply("** هـذا العـضـو لـيـس عـمـيـل فـي هـذا المـتـجـر. **");
        }

        const shopChannel = await i.guild.channels.fetch(shop.id);
        await shopChannel.permissionOverwrites.delete(part.id);

        const updatedPartners = existingPartners.filter(partnerId => partnerId !== part.id);
        await db.set(`shop_${shop.id}_${guildId}.partners`, updatedPartners);

        const logs = await db.get(`logs_${guildId}`);
        const logg = logs ? i.guild.channels.cache.get(logs) : null;

        await i.editReply(`** العـمـيـل <@${part.id}> تـم ازالـتـه مـن المـتـجـر <#${shop.id}> بـ نـجـاح. **`);
        await shopChannel.send({
            content: `** تـم ازالـة : <@${part.id}> \n كـ عـمـيـل مـن المـتـجـر **`,
        });

        if (logg) {
            await logg.send({
                content: `** تـم ازالـة : <@${part.id}> \n كـ عـمـيـل مـن المـتـجـر **\n<@${i.user.id}> عن طريق`,
            });
        }
    } catch (error) {
        console.error(error);
        return i.editReply("وجدت مشكلة أثناء إزالة العميل من المتجر.");
    }
}
break;
      case "come": {
 const blacklist = await db.get('blacklist') || [];
  if (blacklist.includes(i.user.id)) {
    return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
  }
 const guildId = i.guild.id;
    const { member, guild } = i;
          let user = i.options.getUser('user');
          let reason = i.options.getString('reason');
          if (i.user.id == user.id)
          {
        return i.reply({ content: `**ما تقدر تنادي نفسك 👽**` });
          }

    const admins = await db.get(`shopad_${guildId}`);
    if (!admins) {
        await i.reply({
            content: "يرجى تحديد الادمن عن طريق استخدام الامر الاتي: /setup",
        });
        return;
    }

    if (!member.roles.cache.has(admins)) {
        await i.reply(`لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر تـحـتـاج رتـبـه <@&${admins}>`);
        return;
    }
          const callEmbed = {
              title: 'تـم اسـتـدعـائـك',
              description: `مـرحـبـا ${user}, ${i.user.username} قـام بـ اسـتـدعـائـك`,
              fields: [
                  {
                      name: 'تـوجـه لـروم',
                      value: `<#${i.channel.id}>`,
                      inline: true
                  },
                  {
                      name: 'سـبـب اسـتـدعـائـك',
                      value: `**${reason}**` || 'No reason provided',
                      inline: true
                  },
                  {
                      name: 'قـام بـ اسـتـدعـائـك',
                      value: `<@${i.user.id}>`,
                      inline: true
                  }
              ],
              footer: {
                  text: 'يرجـى التوجه للروم بـا اسرع وقت مـمكن',
                  iconURL: i.user.displayAvatarURL(),
              }
          };
          i.reply({ content: ` بنجاح يرجـى عدم السـبام ${user} تم استدعاء ` });
          try {
              await user.send({ embeds: [callEmbed] });
          } catch (error) {
              console.error(`حـدثـت مـشـكـلـة أثـنـاء الارسـال ${user.tag}: ${error}`);
          }

} break;             
 case 'show-helpers': {
 const blacklist = await db.get('blacklist') || [];
  if (blacklist.includes(i.user.id)) {
    return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
  }
    const guildId = i.guild.id;
    const { member, guild } = i;
    const shop = i.options.getChannel("shop") || i.channel; // استخدم القناة الحالية إذا لم يتم تحديد متجر
    const data = await db.get(`shop_${shop.id}_${guildId}`);

    if (!data) {
        return await i.reply({
            content: `❌ **لـم يـتـم العـثـور عـلـى المـتـجـر!**`,
            ephemeral: true,
        });
    }

    const partnerMentions = data.partners && data.partners.length > 0 
        ? data.partners.map(partnerId => `<@${partnerId}>`).join(", ") 
        : null;

    if (!partnerMentions) {
        return await i.reply({
            content: `❌ **لا يـوجـد عـمـلاء مـسـجـلـيـن فـي هـذا المـتـجـر.**`,
            ephemeral: true,
        });
    }

    const embed = new EmbedBuilder()
        .setColor("#06063e")
        .setTitle(`🛍️ عـملاء المـتـجـر`)
        .setDescription(`**- العـملاء:** ${partnerMentions}`)
        .setFooter({ text: `${i.guild.name}`, iconURL: i.guild.iconURL() })
        .setTimestamp();

    await i.reply({ embeds: [embed], ephemeral: true }); // جعل الرسالة مخفية
}
break;case "مزاد": {
    const blacklist = await db.get('blacklist') || [];
    if (blacklist.includes(i.user.id)) {
        return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
    }

    const channelssend = i.options.getChannel('channel');
    const ui = i.options.getUser('الشخص');
    const re = i.options.getString('السلعة');
    const pr = i.options.getString('السعر');
    const ti = i.options.getInteger('وقت');
    const men = i.options.getInteger('المنشن');
    const att = i.options.getAttachment('صوره');
    const att2 = i.options.getAttachment('صوره2');
    const att3 = i.options.getAttachment('صوره3');
    const att4 = i.options.getAttachment('صوره4');
    const att5 = i.options.getAttachment('صوره5');

    const guildId = i.guild.id;
    const { member } = i;

    const admins = await db.get(`auctionad_${guildId}`);
    if (!admins) {
        await i.reply({
            content: "يرجى تحديد الادمن عن طريق استخدام الامر الاتي: /setup",
            ephemeral: true
        });
        return;
    }

    if (!member.roles.cache.has(admins)) {
        await i.reply({
            content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر تـحـتـاج رتـبـه <@&${admins}>`,
            ephemeral: true
        });
        return;
    }

    let op = men === 0 ? "@everyone" : "@here";

    const files = [];
    if (att) files.push({ attachment: att.attachment, name: 'image1.png' });
    if (att2) files.push({ attachment: att2.attachment, name: 'image2.png' });
    if (att3) files.push({ attachment: att3.attachment, name: 'image3.png' });
    if (att4) files.push({ attachment: att4.attachment, name: 'image4.png' });
    if (att5) files.push({ attachment: att5.attachment, name: 'image5.png' });

    await channelssend.permissionOverwrites.edit(channelssend.guild.roles.everyone, { SendMessages: true });

    await channelssend.send({
        content: `
> **__
> \`#\` ${config.mzademoji} الـسـلعـة : ${re}
>
> \`#\` ${config.mzademoji} صـاحـب السـلعـة : <@${ui.id}>
>
> \`#\` ${config.mzademoji} السـ3ـر المـبـدئـي : ${pr}
>
> \`#\` ${config.mzademoji} الـوقـت : ${ti}min
>
>
> \`#\` ${config.mzademoji} الـمـنـشـن : ${op}
> __**
`,
        files: files.length > 0 ? files : undefined
    });

    const countdownMessage = await channelssend.send(`الوقت المتبقي للمزاد: ${ti} دقيقة`);

    let remainingTime = ti * 60;
    let oneMinuteNoticeSent = false;

    const interval = setInterval(async () => {
        remainingTime--;

        const minutes = Math.floor(remainingTime / 60);
        const seconds = remainingTime % 60;

        try {
            await countdownMessage.edit(`الوقت المتبقي للمزاد: ${minutes} دقيقة و ${seconds} ثانية`);
        } catch {
            const endAuctionEmbed = new EmbedBuilder()
                .setTitle("تم حذف رسالة المزاد")
                .setDescription("تم حذف رسالة العد التنازلي. هل تريد إنهاء المزاد؟")
                .setColor("Grey");

            const endAuctionButton = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId("end_auction")
                    .setLabel("إنهاء المزاد")
                    .setStyle(ButtonStyle.Secondary)
            );

            const endAuctionMessage = await channelssend.send({
                embeds: [endAuctionEmbed],
                components: [endAuctionButton]
            });

            const filter = (interaction) => interaction.customId === "end_auction" && interaction.user.id === ui.id;
            const collector = endAuctionMessage.createMessageComponentCollector({ filter, time: remainingTime * 1000 });

            collector.on("collect", async (interaction) => {
                clearInterval(interval);
                collector.stop();
                await endAuctionMessage.delete();
                await channelssend.send("**# المزاد انتهى بواسطة مسؤول المزاد**");
                await channelssend.permissionOverwrites.edit(channelssend.guild.roles.everyone, { SendMessages: false });
            });

            collector.on("end", async () => {
                if (endAuctionMessage.deletable) await endAuctionMessage.delete();
            });

            clearInterval(interval);
            return;
        }

        if (remainingTime === 60 && !oneMinuteNoticeSent) {
            oneMinuteNoticeSent = true;
            await channelssend.send(`**سينتهي المزاد بعد دقيقة واحدة.**`);
        }

        if (remainingTime <= 0) {
            clearInterval(interval);
            await channelssend.send(`**# انتهى وقت المزاد**`);

            setTimeout(async () => {
                await channelssend.permissionOverwrites.edit(channelssend.guild.roles.everyone, { SendMessages: false });
                await channelssend.send(`**__
يرجى التواصل مع صاحب المزاد
<@${ui.id}>
و يرجى طلب وسيط لضمان عدم السرقة
__**`);
            }, 6000);
        }
    }, 1000);

    i.reply({ content: '**Done ✅**', ephemeral: true });
}
break;

case "send-tashfeer": {
    const blacklist = await db.get('blacklist') || [];
    if (blacklist.includes(i.user.id)) {
        return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
    }

    const guildId = i.guild.id;
    const { member } = i;

    const highstaff = await db.get(`highstaff_${guildId}`);
    if (!highstaff) {
        await i.reply({
            content: "يرجى تحديد رتبة العليا (highstaff) عن طريق استخدام الامر الاتي: /setup",
            ephemeral: true
        });
        return;
    }

    if (!member.roles.cache.has(highstaff)) {
        await i.reply({
            content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـه <@&${highstaff}>.`,
            ephemeral: true
        });
        return;
    }

    const imageUrl = await db.get(`image_${guildId}`);

    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("tashfeerk")
            .setLabel("تـشـفـيـر مـنشـورك")
            .setStyle(ButtonStyle.Secondary)
    );

    await i.reply({ content: 'done', ephemeral: true });

    await i.channel.send({
        embeds: [
            {
                title: `**التـشـفـيـر**`,
                description: `**❦\`-\` __ لتشفير منشورك يرجى الضغط على اسفل الايمبد، \`وكتابة منشورك\`.__**`,
                author: {
                    name: `${i.guild.name}`,
                    icon_url: i.guild.iconURL({ size: 1024 }),
                },
                footer: {
                    text: `By Venlook x Ahmdfc`,
                },
                timestamp: new Date(),
                ...(imageUrl ? { image: { url: imageUrl } } : {})
            }
        ],
        components: [row]
    });
}
break;

case "afk": {
  const reason = i.options.getString('reason') || 'لا يوجد سبب'; // Ensure default value is used correctly
  const userId = i.user.id; // الحصول على معرف المستخدم الذي قام بتنفيذ الأمر


  const linkRegex = /\b((https?:\/\/|www\.)[^\s]+(?:\.[a-z]{2,}|\/[^\s]*)?|https?:\/\/(?:discord\.gg|discord\.com\/invite|discord\.com\/channels\/[0-9]+\/[0-9]+\/[0-9]+))/gi;
  
  if (linkRegex.test(reason)) {
    return i.channel.send({
      content: '❌ **غير مسموح بوضع روابط في سبب الـ AFK.**',
      ephemeral: true 
    });
  }

  await db.set(`afk_${userId}`, reason); // تعيين حالة AFK للمستخدم

  const afkEmbed = new EmbedBuilder()
    .setColor('#FF0000')
    .setDescription(`تم تعيين حالتك كـ AFK: ${reason}`);

  await i.reply({ embeds: [afkEmbed], ephemeral: true }); // الرد برسالة AFK
}
break;

case "ping": {
  // Calculate Uptime
  let days = Math.floor(i.client.uptime / 86400000);
  let hours = Math.floor(i.client.uptime / 3600000) % 24;
  let minutes = Math.floor(i.client.uptime / 60000) % 60;
  let seconds = Math.floor(i.client.uptime / 1000) % 60;
  const uptimeString = `${days} days, ${hours} hours, ${minutes} minutes, ${seconds} seconds`;

  // Send initial message
  const sent = await i.channel.send('⏳ **Measuring performance...**'); 
  const ping = Date.now() - i.createdTimestamp;
  const apiPing = Math.round(i.client.ws.ping); // تصحيح هنا: استخدام client.ws.ping بدلاً من message.client.ws.ping

  // Determine color and emoji
  let color;
  let emoji;
  if (ping < 300) {
    color = 0x00FF00; // Green
    emoji = "🟢";
  } else if (ping < 400) {
    color = 0xFFFF00; // Yellow
    emoji = "🟡";
  } else {
    color = 0xFF0000; // Red
    emoji = "🔴";
  }

  // Create embed
  const embed = new EmbedBuilder()
    .setTitle('**🏓 Pong!**')
    .addFields(
      { name: '⏱️ **Latency(ping)**', value: `**${emoji} ${ping}ms**`, inline: true },
      { name: '🌐 **API Latency**', value: `**${apiPing}ms**`, inline: true },
      { name: '🔄 **Uptime**', value: `**${uptimeString}**` }
    )
    .setColor(color)
    .setTimestamp()
  //  .setFooter({ iconURL: i.author.displayAvatarURL() });

  // Create button
  const button = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setLabel("انضم لـسيرفر السبورت")
        .setStyle(ButtonStyle.Link)
        .setURL("https://discord.gg/mEdX6D7Bjz"),
      new ButtonBuilder()
        .setLabel("ضيف البوت")
        .setStyle(ButtonStyle.Link)
        .setURL(`https://discord.com/oauth2/authorize?client_id=${i.client.user.id}`) // تصحيح هنا: استخدام client.user.id بدلاً من message.client.id
    );

  // Edit initial message with embed and button
  await sent.edit({ content: null, embeds: [embed], components: [button] });
}
break;
case "help": {
  const blacklist = await db.get('blacklist') || [];
  if (blacklist.includes(i.user.id)) {
    return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
  }

  const guild = i.guild;
  const { member } = i;

  try {
    // Embed Message
    const embed = new EmbedBuilder()
      .setColor(0xffffff)
      .setTitle('**قائمة المساعدة**')
      .setDescription(`
        أهلاً بك! اختر أحد الخيارات من الأسفل للحصول على المساعدة.
        إذا كنت بحاجة إلى مزيد من الدعم، قم بزيارة سيرفر الدعم.
      `)
      .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
      .setImage('https://i.postimg.cc/BngHxr28/nooobot.webp'); // ضع رابط الصورة الرئيسية هنا

    // Buttons Row
    const buttonsRow1 = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setLabel('اوامر الاونر')
        .setStyle(ButtonStyle.Secondary)
        .setCustomId('ownerCommands'),
      new ButtonBuilder()
        .setLabel('اوامر الاداره')
        .setStyle(ButtonStyle.Secondary)
        .setCustomId('adminCommands')
      // يمكنك إضافة المزيد من الأزرار هنا إذا لزم الأمر
    );

    const buttonsRow2 = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setLabel('اضافة البوت')
        .setStyle(ButtonStyle.Link)
        .setURL(`https://discord.com/oauth2/authorize?client_id=${client.user.id}`), // تصحيح هنا: استخدام client.user.id بدلاً من i.clinet.id
      new ButtonBuilder()
        .setLabel('سيرفر السبورت')
        .setStyle(ButtonStyle.Link)
        .setURL('https://discord.gg/T7fQKJfFDa')
    );

    // Select Menu
    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId('helpMenu')
      .setPlaceholder('اختر الامر اللذي تريد المساعده فيه.')
      .addOptions(
        { label: 'كيف تضبط البوت بسيرفرك', value: 'multiBot' },
        { label: 'كيف تسوي متاجر', value: 'createStore' },
        { label: 'كيف تسوي بيع تلقائي للطلبات', value: 'autoSellOrders' },
        { label: 'كيف تسوي بيع تلقائي للمزاد', value: 'autoAuction' },
        { label: 'معلومات عن البوت', value: 'botInfo' },
        { label: 'إعادة تشغيل القائمة', value: 'resetMenu' }
      );

    const selectMenuRow = new ActionRowBuilder().addComponents(selectMenu);

    // Reply with embed and components
    const sentMessage = await i.reply({
      embeds: [embed],
      components: [buttonsRow1, buttonsRow2, selectMenuRow],
      ephemeral: true // إضافة هذه الخيار لجعل الرسالة مرئية فقط للمستخدم
    });

    // Disable components after a delay
    setTimeout(async () => {
      const disabledButtonsRow1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setLabel('اوامر الاونر')
          .setStyle(ButtonStyle.Secondary)
          .setCustomId('ownerCommands')
          .setDisabled(true),
        new ButtonBuilder()
          .setLabel('اوامر الاداره')
          .setStyle(ButtonStyle.Secondary)
          .setCustomId('adminCommands')
          .setDisabled(true)
      );

      const disabledSelectMenuRow = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId('helpMenu')
          .setPlaceholder('تم تعطيل القائمة.')
          .setDisabled(true)
      );

      await sentMessage.edit({ components: [disabledButtonsRow1, buttonsRow2, disabledSelectMenuRow] });
    }, 300000); // 5 دقائق

  } catch (error) {
    console.error(error);
    await i.reply({ content: 'حدث خطأ أثناء عرض قائمة المساعدة.', ephemeral: true });
  }
}
break;
case "price-panel": {
 const blacklist = await db.get('blacklist') || [];
  if (blacklist.includes(i.user.id)) {
    return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
  }
    const guild = i.guild;
 const { member} = i;
  const highstaff = await db.get(`highstaff_${guildId}`)
    if (!highstaff) {
        await i.reply({
            content: "يرجى تحديد رتبة العليا (highstaff) عن طريق استخدام الامر الاتي: /setup",ephemeral: true,
        });
        return;
    }
const text = i.options.getString('embed-text');
if (!(member.roles.cache.has(highstaff))) {
  await i.reply({
    content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـه <@&${highstaff}>.`,
    ephemeral: true, // إذا أردت أن تكون الرسالة مرئية فقط للعضو
  });
  return;
}
    // استرجاع رابط الصورة المحددة من قاعدة البيانات
    const imageUrl = await db.get(`priceImage_${guildId}`);

    const row = new ActionRowBuilder().addComponents(
new ButtonBuilder()
             .setCustomId('order-price')
             .setLabel('اســـعار الـــطلــبات')
             .setStyle(ButtonStyle.Secondary),
  new ButtonBuilder()
            .setCustomId("auctionpri")
            .setLabel("اسعار الــمــزادات")
            .setStyle(ButtonStyle.Secondary),
  new ButtonBuilder()
            .setCustomId("shoppri")
            .setLabel("اسعار المــتاجــر")
            .setStyle(ButtonStyle.Secondary)

    );

    await i.reply({ content: 'done', ephemeral: true });

    // إرسال الرسالة مع صفوف الأزرار
    await i.channel.send({
        embeds: [
            {
                title: `الاســعــار`,
                description:`${text|| `
**اهلا و ســهلا هــنا قسـم الاســعار لــسيرفر**
__${i.guild.name}__
كل الي عليك عشان تعرف الاســعار 
تــختار زر مــن الازرار الــي تـحت
نأمل ان تنــال اســعارنا رضـــاكم`}`,
                author: {
                    name: `${i.guild.name}`,
                    icon_url: i.guild.iconURL({ size: 1024 }),
                },
                footer: {
                    text: `By Venlook x Ahmdfc`,
                },
                timestamp: new Date(),
                // إضافة الصورة إذا كانت موجودة
                ...(imageUrl ? { image: { url: imageUrl } } : {})
            }
        ],
        // تصحيح الجزء الخاص بالأزرار
        components: [row]
    });
} break;
case "buy-panel": {
 const blacklist = await db.get('blacklist') || [];
  if (blacklist.includes(i.user.id)) {
    return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
  }
    const guild = i.guild;
 const { member} = i;
  const highstaff = await db.get(`highstaff_${guildId}`)
    if (!highstaff) {
        await i.reply({
            content: "يرجى تحديد رتبة العليا (highstaff) عن طريق استخدام الامر الاتي: /setup",ephemeral: true,
        });
        return;
    }
const text = i.options.getString('embed-text');
if (!(member.roles.cache.has(highstaff))) {
  await i.reply({
    content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـه <@&${highstaff}>.`,
    ephemeral: true, // إذا أردت أن تكون الرسالة مرئية فقط للعضو
  });
  return;
}
    // استرجاع رابط الصورة المحددة من قاعدة البيانات
    const imageUrl = await db.get(`image_${guildId}`);

    const row = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
            .setCustomId("buy_panel_select")
            .setPlaceholder("اختر نوع الشراء")
            .addOptions(
                { label: "شــراء طـــلب", value: "order" },
                { label: "شــراء مــزاد", value: "ticket-auction" },
                { label: "شــراء متجر", value: "buy_shop" }
            )
    );

    await i.reply({ content: 'done', ephemeral: true });

    // إرسال الرسالة مع صفوف الأزرار
    await i.channel.send({
        embeds: [
            {
                title: `قســم الشــراء`,
                description:`${text|| `
**اهلا و ســهلا هــنا قسـم الشراء لــسيرفر**
__${i.guild.name}__
### هنا تقدر تشتري
__طــلبات__
__مـــزادات__
__متاجر__
نأمل ان تنــال اســعارنا رضـــاكم`}`,
                author: {
                    name: `${i.guild.name}`,
                    icon_url: i.guild.iconURL({ size: 1024 }),
                },
                footer: {
                    text: `By Venlook x Ahmdfc`,
                },
                timestamp: new Date(),
                // إضافة الصورة إذا كانت موجودة
                ...(imageUrl ? { image: { url: imageUrl } } : {})
            }
        ],
        // تصحيح الجزء الخاص بالأزرار
        components: [row]
    });
} break;
case "shop-panel": {
 const blacklist = await db.get('blacklist') || [];
  if (blacklist.includes(i.user.id)) {
    return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
  }
    const guild = i.guild;
  const { member} = i;
const text = i.options.getString('embed-text');
  const highstaff = await db.get(`highstaff_${guildId}`)
    if (!highstaff) {
        await i.reply({
            content: "يرجى تحديد رتبة العليا (highstaff) عن طريق استخدام الامر الاتي: /setup",ephemeral: true,
        });
        return;
    }

if (!(member.roles.cache.has(highstaff))) {
  await i.reply({
    content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـه <@&${highstaff}>.`,
    ephemeral: true, // إذا أردت أن تكون الرسالة مرئية فقط للعضو
  });
  return;
}

    // استرجاع رابط الصورة المحددة من قاعدة البيانات
  
 const imageUrl = await db.get(`buyshopimage_${guildId}`);
    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("buy_shop")
            .setLabel("شــراء متجر")
            .setStyle(ButtonStyle.Secondary)
    );

    await i.reply({ content: 'done', ephemeral: true });

    // إرسال الرسالة مع صفوف الأزرار
    await i.channel.send({
        embeds: [
            {
                title: `بانل شــراء متاجر`,
                description: `${text|| `
** اهلا و ســهلا هــنا قسـم شراء المتاجر لــسيرفر**
__${i.guild.name}__
اذا تبي متجر؟
ب اسعار رهيبه؟
اضغط على الزر الي تحت راح يفتح تكت مباشر
نأمل ان تنــال اســعارنا رضـــاكم`}`,
                author: {
                    name: `${i.guild.name}`,
                    icon_url: i.guild.iconURL({ size: 1024 }),
                },
                footer: {
                    text: `By Venlook x Ahmdfc`,
                },
                timestamp: new Date(),
                // إضافة الصورة إذا كانت موجودة
                ...(imageUrl ? { image: { url: imageUrl } } : {})
            }
        ],
        // تصحيح الجزء الخاص بالأزرار
        components: [row]
    });
} break;
case "order-panel": {
 const blacklist = await db.get('blacklist') || [];
  if (blacklist.includes(i.user.id)) {
    return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
  }
const text = i.options.getString('embed-text');
    const guild = i.guild;
  const { member} = i;
  const highstaff = await db.get(`highstaff_${guildId}`)
    if (!highstaff) {
        await i.reply({
            content: "يرجى تحديد رتبة العليا (highstaff) عن طريق استخدام الامر الاتي: /setup",ephemeral: true,
        });
        return;
    }

if (!(member.roles.cache.has(highstaff))) {
  await i.reply({
    content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـه <@&${highstaff}>.`,
    ephemeral: true, // إذا أردت أن تكون الرسالة مرئية فقط للعضو
  });
  return;
}

    // استرجاع رابط الصورة المحددة من قاعدة البيانات
  
 const imageUrl = await db.get(`buyorderimage_${guildId}`);
    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("order")
            .setLabel("شــراء طـــلب")
            .setStyle(ButtonStyle.Secondary),
             new ButtonBuilder()
             .setCustomId('order-price')
             .setLabel('اســـعار الـــطلــبات')
             .setStyle(ButtonStyle.Secondary),
    );
                                 

    await i.reply({ content: 'done', ephemeral: true });

    // إرسال الرسالة مع صفوف الأزرار
    await i.channel.send({
        embeds: [
            {
                title: `بانل شــراء طــلبات`,
                description: `${text||`
** اهلا و ســهلا هــنا قسـم شراء الـطلبات لــسيرفر**
__${i.guild.name}__
نأمل ان تنــال اســعارنا رضـــاكم`}`,
                author: {
                    name: `${i.guild.name}`,
                    icon_url: i.guild.iconURL({ size: 1024 }),
                },
                footer: {
                    text: `By Venlook x Ahmdfc`,
                },
                timestamp: new Date(),
                // إضافة الصورة إذا كانت موجودة
                ...(imageUrl ? { image: { url: imageUrl } } : {})
            }
        ],
        // تصحيح الجزء الخاص بالأزرار
        components: [row]
    });
} break;
case "auction-panel": {
 const blacklist = await db.get('blacklist') || [];
  if (blacklist.includes(i.user.id)) {
    return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
  }
    const guild = i.guild;
const { member} = i;
  const highstaff = await db.get(`highstaff_${guildId}`)
    if (!highstaff) {
        await i.reply({
            content: "يرجى تحديد رتبة العليا (highstaff) عن طريق استخدام الامر الاتي: /setup",ephemeral: true,
        });
        return;
    }

const text = i.options.getString('embed-text');
if (!(member.roles.cache.has(highstaff))) {
  await i.reply({
    content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـه <@&${highstaff}>.`,
    ephemeral: true, // إذا أردت أن تكون الرسالة مرئية فقط للعضو
  });
  return;
}

    // استرجاع رابط الصورة المحددة من قاعدة البيانات
     const imageUrl = await db.get(`buyauctionimage_${guildId}`);


    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("ticket-auction")
            .setLabel("شــراء مــزاد")
            .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
            .setCustomId("auctionpri")
            .setLabel("اسعار المزادات")
            .setStyle(ButtonStyle.Secondary)
        //    .setDisabled(true)
    );

    await i.reply({ content: 'done', ephemeral: true });

    // إرسال الرسالة مع صفوف الأزرار
    await i.channel.send({
        embeds: [
            {
                title: `بانل شــراء مــزاد`,
                description: `${text||`
**اهلا و ســهلا هــنا قسـم شراء مـزادات لــسيرفر**
__${i.guild.name}__
نأمل ان تنــال اســعارنا رضـــاكم`}`,
                author: {
                    name: `${i.guild.name}`,
                    icon_url: i.guild.iconURL({ size: 1024 }),
                },
                footer: {
                    text: `By Venlook x Ahmdfc`,
                },
                timestamp: new Date(),
                // إضافة الصورة إذا كانت موجودة
                ...(imageUrl ? { image: { url: imageUrl } } : {})
            }
        ],
        // تصحيح الجزء الخاص بالأزرار
        components: [row]
    });
} break;
case 'say-all-shops': {
    const blacklist = await db.get('blacklist') || [];
    if (blacklist.includes(i.user.id)) {
        return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
    }
    const messageContent = i.options.getString("message");

    await i.deferReply({ ephemeral: true });

    const guild = i.guild;
  
const { member} = i;
  const highstaff = await db.get(`highstaff_${guildId}`)
    if (!highstaff) {
        await i.editReply({
            content: "يرجى تحديد رتبة العليا (highstaff) عن طريق استخدام الامر الاتي: /setup",ephemeral: true,
        });
        return;
    }

if (!(member.roles.cache.has(highstaff))) {
  await i.editReply({
    content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـه <@&${highstaff}>.`,
    ephemeral: true, // إذا أردت أن تكون الرسالة مرئية فقط للعضو
  });
  return;
}


    const categories = guild.channels.cache.filter(channel => channel.type === ChannelType.GuildCategory);
    if (!categories.size) {
        await i.editReply('**لا يوجد كاتيجوري في هذا السيرفر**');
        return;
    }

    const imageUrl = await db.get(`image_${guild.id}`);

    // زر تأكيد
    const confirmButton = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('confirm-send-message')
                .setLabel('تأكيد الإرسال')
                .setStyle('Primary')
        );

    const confirmationEmbed = new EmbedBuilder()
        .setTitle('تأكيد الإرسال')
        .setDescription('هل تريد بالتأكيد إرسال الرسالة لجميع المتاجر؟')
        .addFields({ name: 'الرسالة:', value: messageContent })
        .setFooter({ text: 'By Venlook x Ahmdfc' })
        .setTimestamp(new Date());

    await i.editReply({
        embeds: [confirmationEmbed],
        components: [confirmButton],
    });

    // استجابة الزر
    const filter = interaction => interaction.customId === 'confirm-send-message' && interaction.user.id === i.user.id;
    const collector = i.channel.createMessageComponentCollector({ filter, time: 60000 });

    collector.on('collect', async buttonInteraction => {
        await buttonInteraction.deferUpdate();

        for (const [categoryId, category] of categories) {
            const channels = category.children.cache;

            for (const [channelId, channel] of channels) {
                const channelDataKey = `shop_${channel.id}_${guild.id}`;
                const channelData = await db.get(channelDataKey);

                if (channelData) {
                    // إرسال الرسالة داخل امبد بدون عنوان + منشن صاحب المتجر تحتها
                    const shopEmbed = new EmbedBuilder()
                        .setDescription(`${messageContent}`);
                    await channel.send({ embeds: [shopEmbed] });
                    if (channelData.sellerId) {
                        await channel.send({
                            content: `<@${channelData.sellerId}>`,
                            allowedMentions: { users: [channelData.sellerId] }
                        });
                    }
                }
            }
        }

        const logChannelId = await db.get(`logs_${guild.id}`);
        const logChannel = await i.guild.channels.fetch(logChannelId);
        const logEmbed = new EmbedBuilder()
            .setTitle("تـم ارسال رسالة لجميع المتاجر!")
            .setDescription(`الـمـسـؤول : <@${i.user.id}>
الرسالة
${messageContent}`)
            .setFooter({ text: "By Venlook x Ahmdfc" })
            .setTimestamp(new Date())
            .setImage(imageUrl || "");

        if (logChannel) {
            await logChannel.send({ embeds: [logEmbed] });
        }

        await i.editReply({
            content: '**تـم ارسال الرسالة للمتاجر بنجاح **',
            embeds: [],
            components: [],
        });

        collector.stop();
    });

    collector.on('end', collected => {
        if (!collected.size) {
            i.editReply({
                content: '**تم إلغاء الإجراء بسبب عدم التأكيد.**',
                embeds: [],
                components: [],
            });
        }
    });
} break;


case "warns": {
 const blacklist = await db.get('blacklist') || [];
  if (blacklist.includes(i.user.id)) {
    return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
  }
    const guildId = i.guild.id;
    const { member, guild } = i;

    try {
        // استرجاع بيانات المتجر من قاعدة البيانات
        const shopData = await db.get(`shop_${i.channel.id}_${guildId}`);
        if (!shopData) {
            return await i.reply({
                content: `❌ **هذا الشات ليس متجرا.**`,
                ephemeral: true,
            });
        }

        // استرجاع عدد التحذيرات
        const warns = shopData.warns || 0;

        // استرجاع رابط الصورة من قاعدة البيانات
        const imageUrl = await db.get(`image_${guildId}`);

        // إعداد الـ Embed
        const embed = new EmbedBuilder()
            .setAuthor({
                name: `${i.guild.name}`,
                iconURL: i.guild.iconURL({ size: 1024 }),
            })
            .setTitle("🚨 تحذيرات المتجر")
            .setColor("#FF0000")
            .addFields([
                {
                    name: "عدد التحذيرات:",
                    value: `${warns}`,
                },
            ])
            .setFooter({
                text: `By Venlook x Ahmdfc`,
            })
            .setTimestamp();

        // إضافة الصورة إذا كانت موجودة
        if (imageUrl) {
            embed.setImage(imageUrl);
        }

        // إرسال الـ Embed
        await i.reply({ embeds: [embed] });
    } catch (error) {
        console.error(error);
        await i.reply({
            content: "❌ **حدثت مشكلة أثناء تنفيذ الأمر.**",
            ephemeral: true,
        });
    }
}
break;
case "warn": {
    const blacklist = await db.get('blacklist') || [];
    if (blacklist.includes(i.user.id)) {
        return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
    }
    const guildId = i.guild.id;
    const { member } = i;

    try {
        await i.deferReply({ ephemeral: true });

        const sellerId = await db.get(`shop_${i.channel.id}_${guildId}.sellerId`);
        const admins = await db.get(`shopad_${guildId}`);
        const shop = i.options.getChannel('shop') || i.channel;
        const pic = i.options.getAttachment('pic')?.url;
        const thewarn = i.options.getString('thewarn') || "لا يوجد سبب محدد.";
        let amount = i.options.get('amount')?.value ?? 1;

        // التحقق من الصلاحيات
        if (!admins) {
            return await i.editReply({
                content: "❌ يرجى تحديد الأدمن باستخدام الأمر: `/setup`",
            });
        }

        if (!member.roles.cache.has(admins)) {
            return await i.editReply({
                content: `❌ لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـة <@&${admins}>`,
            });
        }

        // التحقق من العدد
        if (amount < 1 || !Number.isInteger(amount)) {
            return await i.editReply({
                content: "❌ يجب أن يكون عدد التحذيرات عددًا صحيحًا أكبر من أو يساوي 1.",
            });
        }

        if (amount > 999) {
            return i.editReply({
                content: `❌ **لا يمكنك تحذير أكثر من 999 تحذير ._.**
-# يا ساتر المتجر وش مسوي `,
                ephemeral: true
            });
        }

        const shopData = await db.get(`shop_${shop.id}_${guildId}`);
        if (!shopData) {
            return await i.editReply({
                content: `❌ **هذا الشات ليس متجرا.**`,
            });
        }

        // تحديث التحذيرات
         const updatedWarns = (shopData.warns) + amount;
        await db.add(`shop_${shop.id}_${guildId}.warns`, amount);

        // إنشاء Embed التحذير
        const warningEmbed = new EmbedBuilder()
            .setTitle(`**تم تحذير المتجر ${shop} ${config.whaitshop}**`)
            .setDescription(`${config.warn} اسـتـبـيـان تحـذيـر المـتـاجـر`)
                .addFields(
                { name: `صـاحب الـمـتجــر ${config.whaitshop}`, value: `<@!${sellerId}>`, inline: true },
                { name: `عـدد تـحذيـرات الـمتجـر ${config.whaitshop}`, value: `${updatedWarns}`, inline: true },
                { name: `سـبب تحـذير الــمتجر ${config.whaitshop}`, value: `${thewarn}`, inline: true },
                { name: `المــسؤول ${config.whaitshop}`, value: `<@${i.user.id}>`, inline: true }
            )
            .setImage(pic)
            .setTimestamp();

        // إرسال التحذير في القناة
        await shop.send({ embeds: [warningEmbed] });

        // إرسال Embed في قناة السجلات إذا كانت موجودة
        const logsChannelId = await db.get(`logs_${guildId}`);
        if (logsChannelId) {
            const logsChannel = await i.guild.channels.fetch(logsChannelId);
            if (logsChannel) {
                await logsChannel.send({ embeds: [warningEmbed] });
                
            }
        }

        // إرسال رابط الصورة إذا كان موجودًا
        const imageUrl = await db.get(`image_${guildId}`);
        if (imageUrl) {
            await shop.send({ content: imageUrl });
            if (logsChannelId) {
                const logsChannel = await i.guild.channels.fetch(logsChannelId);
                if (logsChannel) {
                    await logsChannel.send({ content: imageUrl });
                }
            }
        }

        // الرد على المستخدم
        await i.editReply({
            content: `✅ **تـم تحذير مـتـجـر ${shop} \n بـ ${amount} تـحـذيـر \n عـدد تـحـذيـرات المـتـجـر الآن: ${updatedWarns}**`,
        });

    } catch (error) {
        console.error(error);
        await i.editReply({
            content: "❌ **حدثت مشكلة أثناء تنفيذ الأمر.**",
        });
    }
}
break;
case "unwarn": {
    const blacklist = await db.get('blacklist') || [];
    if (blacklist.includes(i.user.id)) {
        return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
    }
    const { member, channel } = i;
    const guildId = i.guild.id;
    await i.deferReply({ ephemeral: true });

    let amount = i.options.get('amount')?.value || 1;
    let shop = i.options.getChannel('shop') || channel;

    shop = i.guild.channels.cache.get(shop.id);
    const data = await db.get(`shop_${shop.id}_${guildId}`);
    const admins = await db.get(`shopad_${guildId}`);

    if (!admins) {
        await i.editReply({
            content: "يرجى تحديد الادمن عن طريق استخدام الامر الاتي: /setup",
        });
        return;
    }

    if (!member.roles.cache.has(admins)) {
        await i.editReply(`لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر تـحـتـاج رتـبـه <@&${admins}>`);
        return;
    }

    if (!data) {
        await i.editReply({ content: `** هـذة الـروم لـيـسـت مـتـجـرا  **` });
        return;
    }

    // التحقق من العدد
    if (amount < 1 || !Number.isInteger(amount)) {
        return await i.editReply({
            content: "❌ يجب أن يكون عدد التحذيرات المراد إزالتها عددًا صحيحًا أكبر من أو يساوي 1.",
        });
    }

    if (data.warns - amount < 0) {
        await i.editReply({ content: `** بـتـشـيـل ${amount} كـيـف و عـدد تـحـذيـرات المـتـجـر ${data.warns} اصـلا **` });
        return;
    }

    if (shop && data) {
        // تحديث عدد التحذيرات
        await db.sub(`shop_${shop.id}_${guildId}.warns`, amount);
        const updatedWarns = data.warns - amount;

        // إنشاء Embed لإزالة التحذيرات
        const removeWarnEmbed = new EmbedBuilder()
            .setTitle("📋 **تـم ازالـة تحـذيـر مـن مـتـجـر**")
                .addFields(
                    { name: `${config.whaitshop} **الـمـتـجـر**`, value: `${shop}`, inline: true },
                    { name: `${config.whaitshop} **عدد التحذيرات التي تمت إزالتها**`, value: `${data.warns}`, inline: true },
                    { name: `${config.whaitshop} **التحذيرات المتبقية**`, value: `0`, inline: true },
                    { name: `${config.whaitshop} **صاحب المتجر**`, value: `<@${data.sellerId}>`, inline: true },
                    { name: `${config.whaitshop} **المسؤول**`, value: `<@${i.user.id}>`, inline: true }
                )
            .setTimestamp()
            .setFooter({ text: "تم حذف التحذيرات بنجاح" });

        // إرسال الإيمبد في المتجر
        await shop.send({ embeds: [removeWarnEmbed] });

        // إرسال الإيمبد في السجلات
        const logsChannelId = await db.get(`logs_${guildId}`);
        if (logsChannelId) {
            const logsChannel = await i.guild.channels.fetch(logsChannelId).catch(() => null);
            if (logsChannel) {
                await logsChannel.send({ embeds: [removeWarnEmbed] });
            }
        }

        // الرد على المستخدم
        await i.editReply({
            content: `✅ **تـم ازالـة ${amount} تـحـذيـرات مـن مـتـجـر ${shop}\nعـدد تـحـذيـرات المـتـجـر الآن: ${data.warns}**`,
        });
    }
}
break;
case "unwarn-all": {
    const blacklist = await db.get('blacklist') || [];
    if (blacklist.includes(i.user.id)) {
        return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
    }

    const { member, channel } = i;
    const guildId = i.guild.id;
    await i.deferReply({ ephemeral: true });

    let shop = i.options.getChannel('shop');

//const { member} = i;
  const highstaff = await db.get(`highstaff_${guildId}`)
    if (!highstaff) {
        await i.editReply({
            content: "يرجى تحديد رتبة العليا (highstaff) عن طريق استخدام الامر الاتي: /setup", ephemeral: true,
        });
        return;
    }

if (!(member.roles.cache.has(highstaff))) {
  await i.editReply({
    content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـه <@&${highstaff}>.`,
    ephemeral: true, // إذا أردت أن تكون الرسالة مرئية فقط للعضو
  });
  return;
}

    // زر التأكيد
    const confirmButton = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId('confirm_unwarn_all')
            .setLabel('تأكيد حذف التحذيرات')
            .setStyle(ButtonStyle.Danger)
    );

    await i.editReply({
        content: "❗ هل أنت متأكد من رغبتك بحذف التحذيرات؟",
        components: [confirmButton],
    });

    const filter = (interaction) => interaction.customId === 'confirm_unwarn_all' && interaction.user.id === i.user.id;
    const collector = channel.createMessageComponentCollector({ filter, time: 60000 });

    collector.on('collect', async (interaction) => {
        if (!shop) {
            // حذف التحذيرات من جميع المتاجر
            const shops = await db.all();
            const shopKeys = shops.filter((entry) => entry.id.startsWith(`shop_`) && entry.id.endsWith(`_${guildId}`));

            for (const shopKey of shopKeys) {
                await db.set(shopKey.id, { ...shopKey.value, warns: 0 });
            }

            await interaction.update({
                content: `✅ **تـم ازالـة جـمـيـع الـتـحـذيـرات مـن كـل الـمـتـاجـر**`,
                components: [],
            });
        } else {
            shop = i.guild.channels.cache.get(shop.id);
            const data = await db.get(`shop_${shop.id}_${guildId}`);

            if (!data) {
                await interaction.update({ content: `** هـذة الـروم لـيـسـت مـتـجـرا  **`, components: [] });
                return;
            }

            await db.set(`shop_${shop.id}_${guildId}.warns`, 0);

            const removeAllWarnsEmbed = new EmbedBuilder()
                .setTitle("📋 **تـم ازالـة كـل تـحـذيـرات مـتـجـر**")
                .addFields(
                    { name: `${config.whaitshop} **الـمـتـجـر**`, value: `${shop}`, inline: true },
                    { name: `${config.whaitshop} **عدد التحذيرات التي تمت إزالتها**`, value: `${data.warns}`, inline: true },
                    { name: `${config.whaitshop} **التحذيرات المتبقية**`, value: `0`, inline: true },
                    { name: `${config.whaitshop} **صاحب المتجر**`, value: `<@${data.sellerId}>`, inline: true },
                    { name: `${config.whaitshop} **المسؤول**`, value: `<@${i.user.id}>`, inline: true }
                )
                .setTimestamp()
                .setFooter({ text: "تم حذف جميع التحذيرات بنجاح" });

            await shop.send({ embeds: [removeAllWarnsEmbed] });

            const logsChannelId = await db.get(`logs_${guildId}`);
            if (logsChannelId) {
                const logsChannel = await i.guild.channels.fetch(logsChannelId).catch(() => null);
                if (logsChannel) {
                    await logsChannel.send({ embeds: [removeAllWarnsEmbed] });
                }
            }

            await interaction.update({
                content: `✅ **تـم ازالـة جـمـيـع الـتـحـذيـرات مـن مـتـجـر ${shop}**`,
                components: [],
            });
        }

        collector.stop();
    });

    collector.on('end', async (_, reason) => {
        if (reason !== 'collect') {
            const disabledButton = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId('confirm_unwarn_all')
                    .setLabel('تأكيد حذف التحذيرات')
                    .setStyle(ButtonStyle.Danger)
                    .setDisabled(true)
            );

            await i.editReply({
                content: "❗ هل أنت متأكد من رغبتك بحذف التحذيرات؟",
                components: [disabledButton],
            });
        }
    });
}
break;
   case "order": {
   
 const blacklist = await db.get('blacklist') || [];
  if (blacklist.includes(i.user.id)) {
    return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
  }
 const guildId = i.guild.id;
 const ordersroomId = await db.get(`orderroom_${guildId}`);
       const ch =  i.guild.channels.cache.get(ordersroomId);
  const imageUrl = await db.get(`image_${guildId}`);
     // let Ourderadmins = i.guild.roles.cache.get(config.Ourderadmins)
  const Ourderadmins = await db.get(`orderad_${guildId}`);
            const ui = i.options.getUser(`الشخص`);
            const re = i.options.getString(`الطلب`);
            const men = i.options.getInteger(`المنشن`);

            
               if (!i.member.roles.cache.has(`${Ourderadmins}`)) { return i.reply({ content: '** انت لا تمتلك الصلاحيات الكافيه لأستخدام هذا الامر **', ephemeral: true }); }
      let op;
      if(men === 0){
op ="everyone"
}else if (men === 1){
op ='here'
}
  const embed = {
            description: `**- الطلـــلـب : ${re}\n\n- صـاحـب الطلـــلـب : <@${ui.id}>**`,
            image: imageUrl ? { url: imageUrl } : undefined,
            footer: { text: `By: ${i.user.username}` },
        };
const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
        .setCustomId('order')
        .setLabel('شــراء طــلب')
        .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
        .setCustomId('order-price')
        .setLabel('اســـعار الـــطلــبات')
        .setStyle(ButtonStyle.Secondary),
 new ButtonBuilder()
.setLabel('صاحب الطــلب')
.setStyle(ButtonStyle.Link)
.setURL(`https://discord.com/users/${ui.id}`)
);     
   await ch.send({content:`@${op}
`, embeds: [embed],components: [row],}) 
  
       
        i.reply({ content: '** Done ✅ **', ephemeral: true });           
    } break;
  case 'owner': {
 const blacklist = await db.get('blacklist') || [];
  if (blacklist.includes(i.user.id)) {
    return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
  }
    await i.deferReply();
    const interaction = i;
    const shop = interaction.options.getChannel('shop')|| i.channel;
    let newOwner = interaction.options.getMember('new-owner');
    const guildId = i.guild.id;
    const { member, guild } = i;
    const admins = await db.get(`shopad_${guildId}`);
    const imageUrl = await db.get(`image_${guildId}`);

    if (!admins) {
        await i.editReply({
            content: "يرجى تحديد الادمن عن طريق استخدام الامر الاتي: /setup", ephemeral: true,
        });
        return;
    }

    if (!member.roles.cache.has(admins)) {
        await i.editReply(`لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر تـحـتـاج رتـبـه <@&${admins}>`);
        return;
    }

    try {
        const shopData = await db.get(`shop_${shop.id}_${guildId}`);
        const settings = shopData;
        if (!settings) {
            return interaction.editReply({ content: 'هـذة الـروم لـيـست مـتـجـرا.', ephemeral: true });
        }

        const oldOwnerId = shopData.sellerId;
        const oldOwner = interaction.guild.members.cache.get(oldOwnerId);
        if (!newOwner) {
            return interaction.editReply({ content: 'المـالـك الجـديـد غـيـر صـحـيـح.', ephemeral: true });
        }

        if (oldOwnerId === newOwner.id) {
            return interaction.editReply({ content: `هـذا الشـخـص : <@${newOwner.id}> هـو مـالـك المـتـجـر بـالفـعـل.`, ephemeral: true });
        }


                                         
                                            
                                         

        // تحديث الأذونات
        await shop.permissionOverwrites.delete(oldOwnerId);
        await shop.permissionOverwrites.edit(newOwner, {
            ViewChannel: true,
            SendMessages: true,
            EmbedLinks: true,
            AddReactions: true,
            UseExternalEmojis: true,
            ReadMessageHistory: true,
            MentionEveryone: true,
            AttachFiles: true
        });

        // تحديث قاعدة البيانات
        await db.set(`shop_${shop.id}_${guildId}.sellerId`, newOwner.id);

        // إرسال الرد في الرسالة المؤقتة
        await interaction.editReply({
            content: `تـم نـقـل مـلـكـيـة المـتـجـر :${shop} الـي : ${newOwner}`
        });

        // إرسال الرسالة في قناة السجلات
        const channelToSendId = await db.get(`logs_${guildId}`);
        const channelToSend = await i.guild.channels.fetch(channelToSendId);

        // إنشاء Embed لتفاصيل نقل الملكية
        const transferEmbed = new EmbedBuilder()
            .setTitle('نقل ملكية المتجر')
            .setDescription(`تـم نـقـل مـلـكـيـة مـتـجـر ${shop} بـنـجـاح.`)
            .addFields(
                { name: 'صاحب المتجر القديم', value: oldOwner ? `<@${oldOwner.id}>` : 'غير محدد', inline: true },
                { name: 'صاحب المتجر الجديد', value: `<@${newOwner.id}>`, inline: true },
                { name: 'المسؤول', value: `<@${i.user.id}>`, inline: true },
                { name: 'تاريخ النقل', value: new Date().toLocaleString(), inline: true },
                { name: 'اسم المتجر', value: shop.name, inline: true }
            )
                 

        // إرسال الـ Embed في قناة السجلات وفي المتجر
        await channelToSend.send({ embeds: [transferEmbed] });
        await shop.send({ embeds: [transferEmbed] });

        // إرسال رابط الصورة إذا كانت موجودة
        if (imageUrl) {
            await shop.send({ content: imageUrl });
            await channelToSend.send({ content: imageUrl });
        }

        const logs = await db.get(`logs_${guildId}`);
const logg = guild.channels.cache.get(logs);
if (logg) {
    await logg.send({ embeds: [transferEmbed] });
} else {
    console.log(`i can't fined log channel ${i.guild.name} .`);
}
    } catch (error) {
        console.error('Error transferring ownership:', error);
        await interaction.editReply({ content: 'حـدثـت مـشـكـلـة مـا.', ephemeral: true });
    }break;
}

case "mentions": {
  const blacklist = await db.get('blacklist') || [];
  if (blacklist.includes(i.user.id)) {
    return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
  }

  const guildId = i.guild.id;
  const data = await db.get(`shop_${i.channel.id}_${guildId}`);
  if (!data) return await i.reply({ content: `❌ **هذا الروم ليس مسجل كمتجر**`, ephemeral: true });

  const imageUrl = await db.get(`image_${guildId}`);

const container = new ContainerBuilder()
      .setAccentColor(0x00ccff) // لون جانبي مثل الإيمبد
      .addSectionComponents((section) =>
        section
          .addTextDisplayComponents((td) =>
            td.setContent(`**\`-\`. 𒆜__Everyone__ : ${data.everyoneMentions}**`)
          )
          .setButtonAccessory((btn) =>
            btn
              .setCustomId("dashboardshop")
              .setLabel("تحكــم بـ المــتجــر")
              .setStyle(ButtonStyle.Secondary)
          )
      )
      .addSectionComponents((section) =>
        section
          .addTextDisplayComponents((td) => td.setContent(`**\`-\`. 𒆜__Here__ : ${data.hereMentions}**`))
          .setButtonAccessory((btn) =>
            btn
              .setCustomId("tashfeerk")
              .setLabel("تشفــير")
              .setStyle(ButtonStyle.Secondary)
          )
      )
      .addSectionComponents((section) =>
        section
          .addTextDisplayComponents((td) => td.setContent(`**\`-\`. 𒆜 __Shop mention__ : ${data.shopRoleMentions}**`)) 
           .setButtonAccessory((btn) => btn .setCustomId("mention") 
                 .setLabel("شراء منشات") .setStyle(ButtonStyle.Secondary) 
          )
                            );

    await i.reply({
      components: [container],
      flags: MessageFlags.IsComponentsV2,
    });

} break;

case 'add-tax-channel': {
 const guildId = i.guild.id;
  const blacklist = await db.get('blacklist') || [];
  if (blacklist.includes(i.user.id)) {
    return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
  }

const { member} = i;
  const highstaff = await db.get(`highstaff_${guildId}`)
    if (!highstaff) {
        await i.reply({
            content: "يرجى تحديد رتبة العليا (highstaff) عن طريق استخدام الامر الاتي: /setup", ephemeral: true,
        });
        return;
    }

if (!(member.roles.cache.has(highstaff))) {
  await i.reply({
    content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـه <@&${highstaff}>.`,
    ephemeral: true, // إذا أردت أن تكون الرسالة مرئية فقط للعضو
  });
  return;
}

  const channelId = i.options.get('channel').value;
  if (!channelId) {
    return i.reply({ content: '** لـم يـتـم ادخـال ايـدي روم . **' });
  }

  const channel = i.guild.channels.cache.get(channelId);
  if (!channel) {
    return i.reply({ content: '** تـم ادخـال ايـدي روم خـاطـئ. **' });
  }

  // حفظ روم الضرائب بحيث يكون واحدًا فقط لكل سيرفر
  await db.set(`tax-channel_${guildId}`, channelId);

  i.reply({ content: `**تـم تعيين الروم : <#${channelId}> كـ روم الضرائب للسيرفر.**` });
} break;
case 'remove-tax-channel': {
  const blacklist = await db.get('blacklist') || [];
  if (blacklist.includes(i.user.id)) {
    return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
  }
const { member} = i;
  const highstaff = await db.get(`highstaff_${guildId}`)
    if (!highstaff) {
        await i.reply({
            content: "يرجى تحديد رتبة العليا (highstaff) عن طريق استخدام الامر الاتي: /setup", ephemeral: true,
        });
        return;
    }

if (!(member.roles.cache.has(highstaff))) {
  await i.reply({
    content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـه <@&${highstaff}>.`,
    ephemeral: true, // إذا أردت أن تكون الرسالة مرئية فقط للعضو
  });
  return;
}

  const taxChannel = await db.get(`tax-channel_${i.guild.id}`);
  if (!taxChannel) {
    return i.reply({ content: '** لا يوجد روم ضرائب معين لهذا السيرفر. **' });
  }

  // إزالة روم الضرائب
  await db.delete(`tax-channel_${i.guild.id}`);

  i.reply({ content: `**تـم ازالـة روم الضرائب : <#${taxChannel}> بـ نـجـاح.**` });
} break;
case 'show-tax-channels': {
    const taxChannel = await db.get(`tax-channel_${i.guild.id}`) || 'غير مسجل';
const { member} = i;
  const highstaff = await db.get(`highstaff_${guildId}`)
    if (!highstaff) {
        await i.reply({
            content: "يرجى تحديد رتبة العليا (highstaff) عن طريق استخدام الامر الاتي: /setup", ephemeral: true,
        });
        return;
    }

if (!(member.roles.cache.has(highstaff))) {
  await i.reply({
    content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـه <@&${highstaff}>.`,
    ephemeral: true, // إذا أردت أن تكون الرسالة مرئية فقط للعضو
  });
  return;
}

    const embed = new EmbedBuilder()
        .setTitle('💰 روم الضرائب')
        .setDescription(taxChannel !== 'غير مسجل' ? `الروم المسجل: <#${taxChannel}>` : '🚫 لا يوجد روم ضرائب مسجل.')
        .setColor(taxChannel !== 'غير مسجل' ? '#00FF00' : '#FF0000') // لون مختلف بناءً على الحالة
        .setTimestamp();

    await i.reply({ embeds: [embed] }); // إرسال الـ Embed
} break;
case 'add-emoji-channel': {
  const guildId = i.guild.id;
  const blacklist = await db.get('blacklist') || [];
  if (blacklist.includes(i.user.id)) {
    return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
  }
const { member} = i;
  const highstaff = await db.get(`highstaff_${guildId}`)
    if (!highstaff) {
        await i.reply({
            content: "يرجى تحديد رتبة العليا (highstaff) عن طريق استخدام الامر الاتي: /setup", ephemeral: true,
        });
        return;
    }

if (!(member.roles.cache.has(highstaff))) {
  await i.reply({
    content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـه <@&${highstaff}>.`,
    ephemeral: true, // إذا أردت أن تكون الرسالة مرئية فقط للعضو
  });
  return;
}

  const channelId = i.options.get('channel').value;
  if (!channelId) {
    return i.reply({ content: '** لـم يـتـم ادخـال ايـدي روم . **' });
  }

  const channel = i.guild.channels.cache.get(channelId);
  if (!channel) {
    return i.reply({ content: '** تـم ادخـال ايـدي روم خـاطـئ. **' });
  }

  // حفظ القناة لكل سيرفر فقط
  await db.set(`emoji-channel_${guildId}`, channelId);

  i.reply({ content: `**تـم تعيين الروم : <#${channelId}> كـ روم الإيموجي للسيرفر.**` });
} break;
case 'remove-emoji-channel': {
  const guildId = i.guild.id;
  const blacklist = await db.get('blacklist') || [];
  if (blacklist.includes(i.user.id)) {
    return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
  }
const { member} = i;
  const highstaff = await db.get(`highstaff_${guildId}`)
    if (!highstaff) {
        await i.reply({
            content: "يرجى تحديد رتبة العليا (highstaff) عن طريق استخدام الامر الاتي: /setup", ephemeral: true,
        });
        return;
    }

if (!(member.roles.cache.has(highstaff))) {
  await i.reply({
    content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـه <@&${highstaff}>.`,
    ephemeral: true, // إذا أردت أن تكون الرسالة مرئية فقط للعضو
  });
  return;
}

  const emojiChannel = await db.get(`emoji-channel_${i.guild.id}`);
  if (!emojiChannel) {
    return i.reply({ content: '** لا يوجد روم إيموجي معين لهذا السيرفر. **' });
  }

  // إزالة روم الإيموجي
  await db.delete(`emoji-channel_${i.guild.id}`);

  i.reply({ content: `**تـم ازالـة روم الإيموجي : <#${emojiChannel}> بـ نـجـاح.**` });
} break;
case 'show-emoji-channels': {
  const guildId = i.guild.id;
    const emojiChannel = await db.get(`emoji-channel_${i.guild.id}`) || 'غير مسجل';
const { member} = i;
  const highstaff = await db.get(`highstaff_${guildId}`)
    if (!highstaff) {
        await i.reply({
            content: "يرجى تحديد رتبة العليا (highstaff) عن طريق استخدام الامر الاتي: /setup", ephemeral: true,
        });
        return;
    }

if (!(member.roles.cache.has(highstaff))) {
  await i.reply({
    content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـه <@&${highstaff}>.`,
    ephemeral: true, // إذا أردت أن تكون الرسالة مرئية فقط للعضو
  });
  return;
}

    const embed = new EmbedBuilder()
        .setTitle('😀 روم الإيموجي')
        .setDescription(emojiChannel !== 'غير مسجل' ? `الروم المسجل: <#${emojiChannel}>` : '🚫 لا يوجد روم إيموجي مسجل.')
        .setColor(emojiChannel !== 'غير مسجل' ? '#00FF00' : '#FF0000') // لون مختلف بناءً على الحالة
        .setTimestamp();

    await i.reply({ embeds: [embed] }); // إرسال الـ Embed
} break;
case 'add-sticker-channel': {
  const guildId = i.guild.id;
    const blacklist = await db.get('blacklist') || [];
    if (blacklist.includes(i.user.id)) {
        return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
    }
const { member} = i;
  const highstaff = await db.get(`highstaff_${guildId}`)
    if (!highstaff) {
        await i.reply({
            content: "يرجى تحديد رتبة العليا (highstaff) عن طريق استخدام الامر الاتي: /setup", ephemeral: true,
        });
        return;
    }

if (!(member.roles.cache.has(highstaff))) {
  await i.reply({
    content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـه <@&${highstaff}>.`,
    ephemeral: true, // إذا أردت أن تكون الرسالة مرئية فقط للعضو
  });
  return;
}

    const sticker = i.options.getChannel('channel');

    const oldSticker = await db.get(`sticker_${guildId}`);

    if (oldSticker) {
        if (oldSticker === sticker.id) {
            i.reply('هذا هو روم لوقات المتاجر بالفعل.');
        } else {
            await db.set(`sticker_${guildId}`, sticker.id);
            i.reply(`تم تحديد ${sticker.name} كروم ستيكر جديد لهذا السيرفر.`);
        }
    } else {
        await db.set(`sticker_${guildId}`, sticker.id);
        i.reply(`تم تحديد ${sticker.name} كروم ستيكر.`);
    }
} break;

// أمر حذف روم الاستيكر
case 'remove-sticker-channel': {
  const guildId = i.guild.id;
    const blacklist = await db.get('blacklist') || [];
    if (blacklist.includes(i.user.id)) {
        return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
    }

    const oldSticker = await db.get(`sticker_${guildId}`);
const { member} = i;
  const highstaff = await db.get(`highstaff_${guildId}`)
    if (!highstaff) {
        await i.reply({
            content: "يرجى تحديد رتبة العليا (highstaff) عن طريق استخدام الامر الاتي: /setup", ephemeral: true,
        });
        return;
    }

if (!(member.roles.cache.has(highstaff))) {
  await i.reply({
    content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـه <@&${highstaff}>.`,
    ephemeral: true, // إذا أردت أن تكون الرسالة مرئية فقط للعضو
  });
  return;
}

    if (oldSticker) {
        await db.delete(`sticker_${guildId}`);
        i.reply('تم حذف روم الاستيكر بنجاح.');
    } else {
        i.reply('لا يوجد روم استيكر محدد لهذا السيرفر.');
    }
} break;
case 'show-sticker-channels': {
    const blacklist = await db.get('blacklist') || [];
    if (blacklist.includes(i.user.id)) {
        return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
    }

    const guildId = i.guild.id;
    const stickerChannelId = await db.get(`sticker_${guildId}`) || 'غير مسجل';
const { member} = i;
  const highstaff = await db.get(`highstaff_${guildId}`)
    if (!highstaff) {
        await i.reply({
            content: "يرجى تحديد رتبة العليا (highstaff) عن طريق استخدام الامر الاتي: /setup", ephemeral: true,
        });
        return;
    }

if (!(member.roles.cache.has(highstaff))) {
  await i.reply({
    content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـه <@&${highstaff}>.`,
    ephemeral: true, // إذا أردت أن تكون الرسالة مرئية فقط للعضو
  });
  return;
}

    const embed = new EmbedBuilder()
        .setTitle('روم الاستيكر')
        .setDescription(stickerChannelId !== 'غير مسجل' ? `الروم المسجل: <#${stickerChannelId}>` : '🚫 لا يوجد روم استيكر مسجل.')
        .setColor(stickerChannelId !== 'غير مسجل' ? '#00FF00' : '#FF0000') // لون مختلف بناءً على الحالة
        .setTimestamp();

    await i.reply({ embeds: [embed] }); // إرسال الـ Embed
} break;
case 'add-type': {
  const blacklist = await db.get('blacklist') || [];
  if (blacklist.includes(i.user.id)) {
    return i.reply('**أنت في البلاك لست، لمعلومات أكثر تعال إلى سيرفر الدعم!**');
  }

  const categoryId = i.options.get('category').value;
  const nametype = i.options.getString('name');
  const evcount = i.options.get('everyone_mention_count').value;
  const hecount = i.options.get('here_mention_count').value;
  const shcount = i.options.get('shop_mention_count').value;
  const pirefix = i.options.getString('pirefix');
  const shoprole = i.options.getRole('shop_role').id;
  const shopmen = i.options.getRole('shop_mention').id;
  const maxWarns = i.options.get('maxwarns').value;
  const hasTax = i.options.getBoolean('has_tax');
  let taxPrice = i.options.get('tax_price')?.value || 0;
  const shopPrice = i.options.get('shop_price')?.value || 0;

  const category = await i.guild.channels.fetch(categoryId).catch(() => {
    return i.reply({ content: `❌ **لا يمكنني الوصول إلى هذا الكاتيجوري!**`, ephemeral: true });
  });

  if (!category) return;

  const guildId = i.guild.id;
  const key = `categoryMentions_${categoryId}_${guildId}`;

  // الحصول على جميع الكاتيجوريات في السيرفر
  const allCategories = await db.all();
  const categoryCount = allCategories.filter(entry => entry.id.startsWith(`categoryMentions_`) && entry.id.endsWith(`_${guildId}`)).length;

  if (categoryCount > 15) {
    return i.reply({
      content: `❌ **لا يمكنك تحديد أكثر من 15 كاتيجوريات في هذا السيرفر.**`,
      ephemeral: true
    });
  }

  if (evcount > 9999) {
    return i.reply({
      content: `❌ **لا يمكنك تحديد أكثر من 999 منشنات ايفري ._.**`,
      ephemeral: true
    });
  }
  if (hecount > 9999) {
    return i.reply({
      content: `❌ **لا يمكنك تحديد أكثر من 9999 منشنات هير ._.**`,
      ephemeral: true
    });
  }
  if (shcount > 9999) {
    return i.reply({
      content: `❌ **لا يمكنك تحديد أكثر من 9999 منشنات شوب ._.**`,
      ephemeral: true
    });
  }
  if (maxWarns > 999) {
    return i.reply({
      content: `❌ **لا يمكنك تحديد أكثر من 999 أقصى عدد لتحذيرات ._.**`,
      ephemeral: true
    });
  }

  // تحقق من شروط الضريبة
  if (hasTax && taxPrice === 0) {
    return i.reply({ content: 'يجب تحديد سعر الضريبة إذا كانت الضريبة مفعّلة ويكون أكبر من 0.', ephemeral: true });
  }
  if (!hasTax && taxPrice > 0) {
    return i.reply({ content: 'لا يمكنك تحديد سعر ضريبة إذا كانت الضريبة غير مفعّلة.', ephemeral: true });
  }

  const { member } = i;
  const highstaff = await db.get(`highstaff_${guildId}`);
  if (!highstaff) {
    await i.reply({
      content: "يرجى تحديد رتبة العليا (highstaff) عن طريق استخدام الامر الاتي: /setup", ephemeral: true,
    });
    return;
  }

  if (!(member.roles.cache.has(highstaff))) {
    await i.reply({
      content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـه <@&${highstaff}>.`,
      ephemeral: true,
    });
    return;
  }

  // ضبط الضريبة إلى 0 إذا كانت غير مفعّلة
  if (!hasTax) {
    taxPrice = 0;
  }

  const op = {
    categoryId: categoryId,
    everyoneMentions: evcount,
    hereMentions: hecount,
    shopRoleMentions: shcount,
    pirefix: pirefix,
    shoprole: shoprole,
    shopmen: shopmen,
    maxWarns: maxWarns,
    hasTax: hasTax,
    taxPrice: taxPrice,
    shopPrice: shopPrice,
    nametype: nametype,
    guildId: guildId
  };

  const imageUrl = await db.get(`image_${guildId}`);

  const existingData = await db.get(key);

  if (existingData) {
    // تحديث البيانات
    await db.set(key, op);
    await i.reply({ content: `✅ `, ephemeral: true });
    await i.channel.send({
      embeds: [
        new EmbedBuilder()
          .setTitle(`**تم التحديد معلومات النــوع: ${nametype || 'غير محدد'}**`)
          .setDescription(`
          **
          > ${config.wahitsprkle}  \﹣\ رتــبة هاذا الــنوع : <@&${shoprole || 'غير محدد'}>
          > ${config.wahitsprkle}  \﹣\ بضريبه؟ : ${hasTax === true ? 'نعم' : hasTax === false ? 'لا' : 'غير محدد'}
          > ${config.wahitsprkle}  \﹣\ سعر الضريبه : ${taxPrice || 'غير محدد'}
          > ${config.wahitsprkle}  \﹣\ سعر هاذا النوع : ${shopPrice || 'غير محدد'} 
          > ${config.wahitsprkle}  \﹣\ الـــزخرفــة : ${pirefix || 'لا يوجد'}
          ${config.yelloshop} \-\ __ @everyone : ${evcount || 'غير محدد'} __
          ${config.whaitshop} \-\ __ @here : ${hecount || 'غير محدد'} __
          ${config.shopemoji} \-\ __ <@&${shopmen || 'غير محدد'}> : ${shcount || 'غير محدد'} __
          ${config.warn} \-\ __ أقصى عدد تحذيرات: ${maxWarns || 'غير محدد'} __
          **`)
          .addFields(
            { name: 'الكتاغوري', value: `(${i.guild.channels.cache.get(categoryId)?.id || 'غير معروف'})`, inline: true }
          )
          .setImage(imageUrl || `${config.line}`)
      ]
    });
  } else {
    // إضافة بيانات جديدة
    await db.set(key, op);
    await i.reply({ content: `✅ `, ephemeral: true });
    await i.channel.send({
      embeds: [
        new EmbedBuilder()
          .setTitle(`**تم تحديث معلومات هاذا النــوع: ${category.nametype || 'غير محدد'}**`)
          .setDescription(`
          **
          > ${config.wahitsprkle}  \﹣\ رتــبة هاذا الــنوع : <@&${shoprole || 'غير محدد'}>
          > ${config.wahitsprkle}  \﹣\ بضريبه؟ : ${hasTax === true ? 'نعم' : hasTax === false ? 'لا' : 'غير محدد'}
          > ${config.wahitsprkle}  \﹣\ سعر الضريبه : ${taxPrice || 'غير محدد'}
          > ${config.wahitsprkle}  \﹣\ سعر هاذا النوع : ${shopPrice || 'غير محدد'} 
          > ${config.wahitsprkle}  \﹣\ الـــزخرفــة : ${pirefix || 'لا يوجد'}
          ${config.yelloshop} \-\ __ @everyone : ${evcount || 'غير محدد'} __
          ${config.whaitshop} \-\ __ @here : ${hecount || 'غير محدد'} __
          ${config.shopemoji} \-\ __ <@&${shopmen || 'غير محدد'}> : ${shcount || 'غير محدد'} __
          ${config.warn} \-\ __ أقصى عدد تحذيرات: ${maxWarns || 'غير محدد'} __
          **`)
          .addFields(
            { name: 'الكتاغوري', value: `(${i.guild.channels.cache.get(categoryId)?.id || 'غير معروف'})`, inline: true }
          )
          .setImage(imageUrl || `${config.line}`)
      ]
    });
  }

    const idToUpdate = categoryId;
        
 // types = types.map(type => type.id === idToUpdate ? newObject : type);
  //      updateCommands();

  // تحديث ملف types.js
  fs.readFile(typesPath, 'utf8', (err, data) => {
    if (err) {
      console.error('Error reading types.js:', err);
      return;
    }

    let typesData = [];
    try {
      typesData = require('./types.js');
    } catch (e) {
      console.error('Error parsing types.js:', e);
    }

    typesData.push(op);

    fs.writeFile(typesPath, `const types = ${JSON.stringify(typesData, null, 4)};\nmodule.exports = types;`, 'utf8', (err) => {
      if (err) {
        console.error('Error writing to types.js:', err);
        return;
      }

      console.log('Successfully added new type!');
  //    updateTypesAndCommands(typesData); // تحديث الأنواع والأوامر بعد إضافة نوع جديد
    });
  });
} break;
 case 'add-type2': {
  const blacklist = await db.get('blacklist') || [];
  if (blacklist.includes(i.user.id)) {
    return i.reply('**أنت في البلاك لست، لمعلومات أكثر تعال إلى سيرفر الدعم!**');
  }
const guildId = i.guild.id;
  const categoryId = i.options.get('category').value;
  const nametype = i.options.getString('name');
  const evcount = i.options.get('everyone_mention_count').value;
  const hecount = i.options.get('here_mention_count').value;
  const shcount = i.options.get('shop_mention_count').value;
  const pirefix = i.options.getString('shop-pirefix');
  const shoprole = i.options.getRole('shop_role').id;
  const shopmen = i.options.getRole('shop_mention').id;
  const maxWarns = i.options.get('maxwarns').value;
  const hasTax = i.options.getBoolean('has_tax');
  let taxPrice = i.options.get('tax_price')?.value || 0;
  const shopPrice = i.options.get('shop_price')?.value || 0;
const imageUrl = await db.get(`image_${guildId}`);



        const category = await i.guild.channels.fetch(categoryId).catch(async () => {
          return i.reply({ content: `❌ **لا يمكنني الوصول على هذا الكاتيجوري !**`, ephemeral: true })
        })

  const allCategories = await db.all();
  const categoryCount = allCategories.filter(entry => entry.id.startsWith(`categoryMentions_`) && entry.id.endsWith(`_${guildId}`)).length;

  if (categoryCount > 15) {
    return i.reply({
      content: `❌ **لا يمكنك تحديد أكثر من 15 كاتيجوريات في هذا السيرفر.**`,
      ephemeral: true
    });
  }

  if (evcount > 9999) {
    return i.reply({
      content: `❌ **لا يمكنك تحديد أكثر من 9999 منشنات ايفري ._.**`,
      ephemeral: true
    });
  }
  if (hecount > 9999) {
    return i.reply({
      content: `❌ **لا يمكنك تحديد أكثر من 9999 منشنات هير ._.**`,
      ephemeral: true
    });
  }
  if (shcount > 9999) {
    return i.reply({
      content: `❌ **لا يمكنك تحديد أكثر من 9999 منشنات شوب ._.**`,
      ephemeral: true
    });
  }
  if (maxWarns > 999) {
    return i.reply({
      content: `❌ **لا يمكنك تحديد أكثر من 999 أقصى عدد لتحذيرات ._.**`,
      ephemeral: true
    });
  }

  // تحقق من شروط الضريبة
  if (hasTax && taxPrice === 0) {
    return i.reply({ content: 'يجب تحديد سعر الضريبة إذا كانت الضريبة مفعّلة ويكون أكبر من 0.', ephemeral: true });
  }
  if (!hasTax && taxPrice > 0) {
    return i.reply({ content: 'لا يمكنك تحديد سعر ضريبة إذا كانت الضريبة غير مفعّلة.', ephemeral: true });
  }


const { member} = i;
  const highstaff = await db.get(`highstaff_${guildId}`)
    if (!highstaff) {
        await i.reply({
            content: "يرجى تحديد رتبة العليا (highstaff) عن طريق استخدام الامر الاتي: /setup", ephemeral: true,
        });
        return;
    }

if (!(member.roles.cache.has(highstaff))) {
  await i.reply({
    content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـه <@&${highstaff}>.`,
    ephemeral: true, // إذا أردت أن تكون الرسالة مرئية فقط للعضو
  });
  return;
}

  // ضبط الضريبة إلى 0 إذا كانت غير مفعّلة
  if (!hasTax) {
    taxPrice = 0;
  }

 let datecreated = `<t:${parseInt(Date.now() / 1000)}:R>`;
        for (const channel of category.children.cache) {
          const op = {
            channelId: channel[0],
        categoryId: categoryId,
        everyoneMentions: evcount,
        hereMentions: hecount,
        shopmen: shopmen,
        shoprole: shoprole,
        shopRoleMentions: shcount,
        date: datecreated,
        maxWarns: maxWarns,
        taxPrice: taxPrice,
        hasTax: hasTax,
        nametype: nametype,
          pirefix: pirefix,
    shopname: channel[1].name
          }
          await db.set(`shop_${channel[0]}_${guildId}`, op)
  await db.set(`shop_${channel[0]}_${guildId}.warns`, "0")
  await db.set(`shop_${channel[0]}_${guildId}.status`, "1");
        }
          const ob = {
    categoryId: categoryId,
    everyoneMentions: evcount,
    hereMentions: hecount,
    shopRoleMentions: shcount,
    pirefix: pirefix,
    shoprole: shoprole,
    shopmen: shopmen,
    maxWarns: maxWarns, // إضافة أقصى عدد تحذيرات
    hasTax: hasTax,
    taxPrice: taxPrice,
    shopPrice: shopPrice,
    nametype: nametype,
          }
        await db.set(`categoryMentions_${categoryId}_${guildId}`, ob)
  //  await i.reply({ content: `✅ ` })
    await i.channel.send({
      embeds: [
        new EmbedBuilder()
          .setTitle(`**تم التحديد معلومات النــوع: ${nametype || 'غير محدد'}**`)
          .setDescription(`
          **
          > ${config.wahitsprkle}  \﹣\ رتــبة هاذا الــنوع : <@&${shoprole || 'غير محدد'}>
          > ${config.wahitsprkle}  \﹣\ بضريبه؟ : ${hasTax === true ? 'نعم' : hasTax === false ? 'لا' : 'غير محدد'}
          > ${config.wahitsprkle}  \﹣\ سعر الضريبه : ${taxPrice || 'غير محدد'}
          > ${config.wahitsprkle}  \﹣\ سعر هاذا النوع : ${shopPrice || 'غير محدد'} 
          > ${config.wahitsprkle}  \﹣\ الـــزخرفــة : ${pirefix || 'لا يوجد'}
          ${config.yelloshop} \-\ __ @everyone : ${evcount || 'غير محدد'} __
          ${config.whaitshop} \-\ __ @here : ${hecount || 'غير محدد'} __
          ${config.shopemoji} \-\ __ <@&${shopmen || 'غير محدد'}> : ${shcount || 'غير محدد'} __
          ${config.warn} \-\ __ أقصى عدد تحذيرات: ${maxWarns || 'غير محدد'} __
          **`)
          .addFields(
            { name: 'الكتاغوري', value: `(${i.guild.channels.cache.get(categoryId)?.id || 'غير معروف'})`, inline: true }
          )
          .setImage(imageUrl || `${config.line}`)
      ]
       });
         
      } break;
                       case 'edit-type': {
  const blacklist = await db.get('blacklist') || [];
  if (blacklist.includes(i.user.id)) {
    return i.reply('**أنت في البلاك لست، لمعلومات أكثر تعال إلى سيرفر الدعم!**');
  }

  const categoryId = i.options.get('category').value;
  const key = `categoryMentions_${categoryId}_${i.guild.id}`;
  const oldData = await db.get(key);

  if (!oldData) {
    return i.reply({ content: "❌ **هذا النوع غير موجود، لا يمكن تعديله.**", ephemeral: true });
  }

  const { member } = i;
  const guildId = i.guild.id;
  const highstaff = await db.get(`highstaff_${guildId}`);

  if (!highstaff) {
    return i.reply({
      content: "يرجى تحديد رتبة العليا (highstaff) عن طريق استخدام الامر الاتي: /setup",
      ephemeral: true
    });
  }

  if (!member.roles.cache.has(highstaff)) {
    return i.reply({
      content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـه <@&${highstaff}>.`,
      ephemeral: true
    });
  }

  // 🔥 جمع القيم الجديدة إذا موجودة، وإذا ما أرسلها يأخذ القديمة مثل ما هي
  const newData = {
    categoryId,
    nametype: i.options.getString('name') || oldData.nametype,
    everyoneMentions: i.options.getInteger('everyone_mention_count') ?? oldData.everyoneMentions,
    hereMentions: i.options.getInteger('here_mention_count') ?? oldData.hereMentions,
    shopRoleMentions: i.options.getInteger('shop_mention_count') ?? oldData.shopRoleMentions,
    pirefix: i.options.getString('pirefix') || oldData.pirefix,
    shoprole: i.options.getRole('shop_role')?.id || oldData.shoprole,
    shopmen: i.options.getRole('shop_mention')?.id || oldData.shopmen,
    maxWarns: i.options.getInteger('maxwarns') ?? oldData.maxWarns,
    shopPrice: i.options.getInteger('shop_price') ?? oldData.shopPrice,
    hasTax: i.options.getBoolean('has_tax') ?? oldData.hasTax,
    taxPrice: i.options.getInteger('tax_price') ?? oldData.taxPrice,
    guildId
  };

  // إذا الضريبة صايرة false نخلي السعر 0
  if (newData.hasTax === false) newData.taxPrice = 0;

  await db.set(key, newData);

  const imageUrl = await db.get(`image_${guildId}`);

  await i.reply({ content: "✅ **تم تعديل النوع بنجاح!**", ephemeral: true });

  await i.channel.send({
    embeds: [
      new EmbedBuilder()
        .setTitle(`**تم تعديل النوع: ${newData.nametype}**`)
        .setDescription(`
**> رتبة النوع: <@&${newData.shoprole}>
> هل يوجد ضريبة؟: ${newData.hasTax ? "نعم" : "لا"}
> سعر الضريبة: ${newData.taxPrice}
> سعر النوع: ${newData.shopPrice}
> الزخرفة: ${newData.pirefix || "لا يوجد"}

${config.yelloshop} - @everyone: ${newData.everyoneMentions}
${config.whaitshop} - @here: ${newData.hereMentions}
${config.shopemoji} - <@&${newData.shopmen}>: ${newData.shopRoleMentions}
${config.warn} - أقصى التحذيرات: ${newData.maxWarns}
**`)
        .addFields({ name: "الكتاغوري", value: `(${categoryId})` })
        .setImage(imageUrl || config.line)
    ]
  });

} break;
                   case 'check-types': {
  const guildId = i.guild.id;
  const { member } = i;

  const highstaff = await db.get(`highstaff_${guildId}`);
  if (!highstaff) {
    return i.reply({
      content: "يرجى تحديد رتبة العليا (highstaff) من خلال /setup",
      ephemeral: true,
    });
  }

  if (!member.roles.cache.has(highstaff)) {
    return i.reply({
      content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـه <@&${highstaff}>.`,
      ephemeral: true,
    });
  }

  const all = await db.all();
  const types = all.filter(e => e.id.startsWith('categoryMentions_') && e.id.endsWith(`_${guildId}`));

  if (types.length === 0) {
    return i.reply({
      content: '❌ لا توجد أنواع متاجر في السيرفر.',
      ephemeral: true,
    });
  }

  let valid = 0;
  let deleted = 0;

  for (const entry of types) {
    const data = entry.value;
    const cat = i.guild.channels.cache.get(data.categoryId);

    if (!cat) {
      await db.delete(entry.id);
      deleted++;
    } else {
      valid++;
    }
  }

  const embed = new EmbedBuilder()
    .setTitle('🛠️ فحص الأنواع')
    .setDescription(`
**الأنواع الصالحة:** ${valid}
**الأنواع المحذوفة:** ${deleted}
    `)
    .setTimestamp();

  return i.reply({ embeds: [embed] });
}  break;
 case "remove-helper": {
 const blacklist = await db.get('blacklist') || [];
  if (blacklist.includes(i.user.id)) {
    return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
  }
    const guildId = i.guild.id;
    const { member, guild } = i;
    const { options } = i;
    const part = options.getUser("helper");
    const shop = options.getChannel("shop") || i.channel; // استخدم القناة الحالية إذا لم يتم تحديد قناة

    const admins = await db.get(`shopad_${guildId}`);
    if (!admins) {
        await i.editReply({
            content: "يرجى تحديد الادمن عن طريق استخدام الامر الاتي: /setup",
        });
        return;
    }

    if (!member.roles.cache.has(admins)) {
        await i.editReply(`لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر تـحـتـاج رتـبـه <@&${admins}>`);
        return;
    }

    await i.deferReply();

    try {
        const data = await db.get(`shop_${shop.id}_${guildId}`);
        if (!data) {
            return i.editReply("** هـذة الـروم لـيـسـت مـتـجـر **");
        }

        const existingPartners = data.partners || [];
        if (!existingPartners.includes(part.id)) {
            return i.editReply("** هـذا العـضـو لـيـس عـمـيـل فـي هـذا المـتـجـر. **");
        }

        const shopChannel = await i.guild.channels.fetch(shop.id);
        await shopChannel.permissionOverwrites.delete(part.id);

        const updatedPartners = existingPartners.filter(partnerId => partnerId !== part.id);
        await db.set(`shop_${shop.id}_${guildId}.partners`, updatedPartners);

        const logs = await db.get(`logs_${guildId}`);
        const logg = logs ? i.guild.channels.cache.get(logs) : null;

        await i.editReply(`** العـمـيـل <@${part.id}> تـم ازالـتـه مـن المـتـجـر <#${shop.id}> بـ نـجـاح. **`);
        await shopChannel.send({
            content: `** تـم ازالـة : <@${part.id}> \n كـ عـمـيـل مـن المـتـجـر **`,
        });

        if (logg) {
            await logg.send({
                content: `** تـم ازالـة : <@${part.id}> \n كـ عـمـيـل مـن المـتـجـر **\n<@${i.user.id}> عن طريق`,
            });
        }
    } catch (error) {
        console.error(error);
        return i.editReply("وجدت مشكلة أثناء إزالة العميل من المتجر.");
    }
}
break;
    case 'types': {
    const guildId = i.guild.id;
    const { member } = i;

    const highstaff = await db.get(`highstaff_${guildId}`);
    if (!highstaff) {
        return i.reply({ content: "يرجى تحديد رتبة العليا (highstaff) عن طريق استخدام الامر الاتي: /setup", ephemeral: true });
    }

    if (!member.roles.cache.has(highstaff)) {
        return i.reply({ content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـه <@&${highstaff}>.`, ephemeral: true });
    }

    const allCategories = await db.all();
    const categories = allCategories
        .filter(entry => entry.id.startsWith(`categoryMentions_`) && entry.id.endsWith(`_${guildId}`))
        .map(entry => entry.value);

    if (categories.length === 0) {
        return i.reply({ content: `❌ **لا توجد أنواع متاجر محددة في هذا السيرفر.**`, ephemeral: false });
    }

    const imageUrl = await db.get(`image_${guildId}`);

    // الإيمبد الأول: قائمة أسماء الأنواع
    const embed = new EmbedBuilder()
        .setTitle('📋 قائمة أنواع المتاجر')
        .setDescription(categories.map((cat, index) => `${index + 1}. ${i.guild.channels.cache.get(cat.categoryId)?.name || 'غير معروف'}`).join('\n'))
        .setImage(imageUrl || `${config.line}`)
        .setColor(0x2f3136);

    // إنشاء أزرار لكل نوع، 5 أزرار لكل صف
    const rows = [];
    let currentRow = new ActionRowBuilder();
    let btnCount = 0;

    for (const category of categories) {
        const btn = new ButtonBuilder()
            .setCustomId(`type_${category.categoryId}`)
            .setLabel(category.nametype || "غير محدد")
            .setStyle(ButtonStyle.Secondary);

        currentRow.addComponents(btn);
        btnCount++;

        // كل 5 أزرار نبدأ صف جديد
        if (btnCount === 5) {
            rows.push(currentRow);
            currentRow = new ActionRowBuilder();
            btnCount = 0;
        }
    }

    // إضافة آخر صف إذا فيه أزرار
    if (currentRow.components.length > 0) {
        rows.push(currentRow);
    }

    // إرسال الإيمبد مع الأزرار
    await i.reply({
        embeds: [embed],
        components: rows,
        ephemeral: false
    });
const filter = (btnInt) => btnInt.user.id === i.user.id && btnInt.customId.startsWith('type_');
    const collector = i.channel.createMessageComponentCollector({ filter, time: 60000 });

    collector.on('collect', async (btnInt) => {
        const categoryId = btnInt.customId.replace('type_', '');
        const categoryData = categories.find(c => c.categoryId === categoryId);

        if (!categoryData) {
            return btnInt.reply({ content: "❌ لم أتمكن من العثور على بيانات هذا النوع.", ephemeral: true });
        }

        const categoryChannel = i.guild.channels.cache.get(categoryData.categoryId);
        const channelName = categoryChannel?.name || "غير معروف";

        const detailEmbed = new EmbedBuilder()
            .setTitle(`📦 معلومات النوع: ${categoryData.nametype || "غير محدد"}`)
            .setDescription(`**━━━━━━━━━━━━━━━━━━**
**اسم النوع:** ${categoryData.nametype || "غير محدد"}
**الكتاغوري:** ${channelName} (${categoryData.categoryId})

> ${config.wahitsprkle} رتبة النوع: <@&${categoryData.shoprole || "غير محدد"}>
> ${config.wahitsprkle} الزخرفة: ${categoryData.pirefix || "لا يوجد"}
> ${config.wahitsprkle} ضريبة؟ ${categoryData.hasTax ? "نعم" : "لا"}
> ${config.wahitsprkle} سعر الضريبة: ${categoryData.taxPrice || "غير محدد"}
> ${config.wahitsprkle} سعر النوع: ${categoryData.shopPrice || "غير محدد"}

${config.yelloshop} @everyone: ${categoryData.everyoneMentions || "غير محدد"}
${config.whaitshop} @here: ${categoryData.hereMentions || "غير محدد"}
${config.shopemoji} <@&${categoryData.shopmen || "غير محدد"}>: ${categoryData.shopRoleMentions}
${config.warn} أقصى تحذيرات: ${categoryData.maxWarns || "غير محدد"}
**`)
            .setImage(imageUrl || `${config.line}`)
            .setColor(0x2f3136)
            .setFooter({ text: 'By Venlook x Ahmdfc' })
            .setTimestamp();

        await btnInt.reply({ embeds: [detailEmbed], ephemeral: true });
    });
} break;        
case 'typeswas': {
  const guildId = i.guild.id;
const { member} = i;
  const highstaff = await db.get(`highstaff_${guildId}`)
    if (!highstaff) {
        await i.reply({
            content: "يرجى تحديد رتبة العليا (highstaff) عن طريق استخدام الامر الاتي: /setup", ephemeral: true,
        });
        return;
    }

if (!(member.roles.cache.has(highstaff))) {
  await i.reply({
    content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـه <@&${highstaff}>.`,
    ephemeral: true, // إذا أردت أن تكون الرسالة مرئية فقط للعضو
  });
  return;
}


  // الحصول على جميع الأنواع المرتبطة بالسيرفر
  const allCategories = await db.all();
  const categories = allCategories
    .filter(entry => entry.id.startsWith(`categoryMentions_`) && entry.id.endsWith(`_${guildId}`))
    .map(entry => entry.value);

  if (categories.length === 0) {
    return i.reply({
      content: `❌ **لا توجد أنواع متاجر محددة في هذا السيرفر.**`,
      ephemeral: false
    });
  }

  // الحصول على صورة من قاعدة البيانات إذا كانت موجودة
  const imageUrl = await db.get(`image_${guildId}`);

  // إنشاء إيمبد لعرض أسماء الأنواع
  const embed = new EmbedBuilder()
    .setTitle('📋 قائمة أنواع المتاجر')
    .setDescription(
      categories.map((cat, index) => `${index + 1}. ${i.guild.channels.cache.get(cat.categoryId)?.name || 'غير معروف'}`).join('\n')
    )
    .setImage(imageUrl || `${config.line}`); // إضافة الصورة إذا كانت موجودة

  // إرسال الإيمبد في رسالة واحدة
  await i.reply({
    embeds: [embed],
    ephemeral: false
  });

  // إرسال معلومات كل نوع في نفس الرسالة
  const categoryEmbeds = categories.map(category => {
    const categoryChannel = i.guild.channels.cache.get(category.categoryId);

    // إذا كان الكاتيجوري موجودًا
    if (categoryChannel) {
      return new EmbedBuilder()
        .setTitle(`**معلومات النــوع: ${category.nametype || 'غير محدد'}**`)
        .setDescription(`**
> ${config.wahitsprkle}  \﹣\ رتــبة هاذا الــنوع : <@&${category.shoprole || 'غير محدد'}> 

> ${config.wahitsprkle}  \﹣\ الـــزخرفــة : ${category.pirefix || 'لا يوجد'}
> ${config.wahitsprkle}  \﹣\ بضريبه؟ : ${category.hasTax === true ? 'نعم' : category.hasTax === false ? 'لا' : 'غير محدد'}
> ${config.wahitsprkle}  \﹣\ سعر الضريبه : ${category.taxPrice || 'غير محدد'}
> ${config.wahitsprkle}  \﹣\ سعر هاذا النوع : ${category.shopPrice || 'غير محدد'}

${config.yelloshop} \-\ __ @everyone : ${category.everyoneMentions || 'غير محدد'} __
${config.whaitshop} \-\ __ @here : ${category.hereMentions || 'غير محدد'} __
${config.shopemoji} \-\ __ <@&${category.shopmen || 'غير محدد'}> : ${category.shopRoleMentions} __
${config.warn} \-\ __ أقصى عدد تحذيرات: ${category.maxWarns || 'غير محدد'} __
**`)
        .addFields(
          { name: 'الكتاغوري', value: `(${i.guild.channels.cache.get(category.categoryId)?.id || 'غير معروف'})`, inline: true }
        )
        .setAuthor({ name: i.guild.name, iconURL: i.guild.iconURL({ size: 1024 }) })
        .setFooter({ text: 'By Venlook x Ahmdfc' })
        .setTimestamp()
        .setThumbnail(i.guild.iconURL({ size: 1024 }))
        .setImage(imageUrl || `${config.line}`);  
    }
  }).filter(embed => embed); // التأكد من أن الإيمبد ليس فارغًا

  // إرسال الإيمبد الخاص بكل نوع في نفس الرسالة
  await i.followUp({
    embeds: categoryEmbeds,
    ephemeral: false
  });

} break;
// الكود الجديد
case 'remove-type': {
  const categoryId = i.options.get('category').value;
  const guildId = i.guild.id;
  const key = `categoryMentions_${categoryId}_${guildId}`;
const { member} = i;
  const highstaff = await db.get(`highstaff_${guildId}`)
    if (!highstaff) {
        await i.reply({
            content: "يرجى تحديد رتبة العليا (highstaff) عن طريق استخدام الامر الاتي: /setup", ephemeral: true,
        });
        return;
    }

if (!(member.roles.cache.has(highstaff))) {
  await i.reply({
    content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـه <@&${highstaff}>.`,
    ephemeral: true, // إذا أردت أن تكون الرسالة مرئية فقط للعضو
  });
  return;
}


  const existingData = await db.get(key);

  if (!existingData) {
    return i.reply({
      content: `❌ **لم يتم العثور على النوع المرتبط بهذا الكاتيجوري.**`,
      ephemeral: true
    });
  }

  await db.delete(key);

  return i.reply({
    content: `✅ **تم حذف النوع المرتبط بالكاتيجوري بنجاح!**`,
    ephemeral: true
  });
} break;
case 'remove-all-types': {
  const guildId = i.guild.id;
  const { member } = i;

  const highstaff = await db.get(`highstaff_${guildId}`);
  if (!highstaff) {
    return i.reply({
      content: "يرجى تحديد رتبة العليا (highstaff) عن طريق استخدام الأمر التالي: `/setup`",
      ephemeral: true,
    });
  }

  if (!member.roles.cache.has(highstaff)) {
    return i.reply({
      content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـه <@&${highstaff}>.`,
      ephemeral: true,
    });
  }

  // جلب جميع المفاتيح المرتبطة بأنواع المتاجر في هذا السيرفر
  const allKeys = await db.all();
  const categoryKeys = allKeys
    .map(entry => entry.id)
    .filter(key => key.startsWith(`categoryMentions_`) && key.includes(`_${guildId}`));

  if (categoryKeys.length === 0) {
    return i.reply({
      content: `❌ **لا يوجد أنواع متاجر مسجلة في هذا السيرفر.**`,
      ephemeral: true,
    });
  }

  // حذف جميع أنواع المتاجر
  for (const key of categoryKeys) {
    await db.delete(key);
  }

  return i.reply({
    content: `✅ **تم حذف جميع أنواع المتاجر في هذا السيرفر بنجاح!**`,
    ephemeral: true,
  });
}
break;
   case "active": {
 const blacklist = await db.get('blacklist') || [];
  if (blacklist.includes(i.user.id)) {
    return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
  }
  await i.deferReply({ ephemeral: false });

  const shopi = i.options.getChannel('shop') || i.channel;
  const shopoo = await i.guild.channels.fetch(shopi.id);
  const guildId = i.guild.id;
  const { member } = i;
  const admins = await db.get(`shopad_${guildId}`);

  if (!admins) {
    await i.editReply({
      content: "يرجى تحديد الادمن عن طريق استخدام الامر الاتي: /setup", ephemeral: true,
    });
    return;
  }

  if (!member.roles.cache.has(admins)) {
    await i.editReply(`لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر تـحـتـاج رتـبـه <@&${admins}>`);
    return;
  }

  if (!shopoo) {
    await i.editReply('**لا أسـتـطـيـع الـعـثـور عـلـي هـذه الـروم**');
    return;
  }

  const shppp = await db.get(`shop_${shopi.id}_${guildId}`);

  if (!shppp) {
    await i.editReply('**هـذا الـروم لـيـس مـتـجر**');
    return;
  }

  if (shppp.status === "1") {
    await i.editReply('**الـروم لـيـس مـعـطـل**');
    return;
  }

  if (shppp.status === "0") {
    await shopi.permissionOverwrites.edit(i.guild.roles.everyone, {
      ViewChannel: true,
    });

    // استرجاع رابط الصورة من قاعدة البيانات
    const imageUrl = await db.get(`image_${guildId}`);

    const embedlog = new EmbedBuilder()
      .setTitle(`تـم تـفـعـيـل الـمـتـجـر`)
      .setDescription(`يـرجـي قـرائـه الـقـوانـيـن و الإلـتـزام بـهـا`)
      .setFooter({ text: `By Venlook x Ahmdfc` })
      .setTimestamp(new Date())
      // إضافة الصورة إذا كانت موجودة
             .setImage(imageUrl || `${config.line}`); 

    const uuiio = await db.get(`shop_${shopi.id}_${guildId}`);
    await db.set(`shop_${shopi.id}_${guildId}.status`, "1");

    await shopi.send({ embeds: [embedlog], content: `<@${uuiio.sellerId}>` });
    await i.editReply('**تـم تـفـعـيـل الـمـتـجـر بـنـجـاح**');

    const embedlogi = new EmbedBuilder()
      .setTitle(`تـم تـفـعـيـل مـتـجـر`)
      .setDescription(`الـمـسـؤول : <@${i.user.id}>`)
      .addFields(
        {
          name: 'الـمـتـجـر  : ',
          value: `<#${shopi.id}>`,
          inline: true,
        }
      )
      .setFooter({ text: `By Venlook x Ahmdfc` })
      .setTimestamp(new Date())
      // إضافة الصورة إذا كانت موجودة
         .setImage(imageUrl || `${config.line}`); 

const channelToSendId = await db.get(`logs_${guildId}`);
   const channelToSend = await i.guild.channels.fetch(channelToSendId);
    await channelToSend.send({ embeds: [embedlogi]});

    await i.editReply({ embeds: [embedlogi] });
  }
} break;
case "active-all": {
    const blacklist = await db.get("blacklist") || [];
    if (blacklist.includes(i.user.id)) {
        return i.reply("**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**");
    }

    await i.deferReply({ ephemeral: true });

    const guildId = i.guild.id;
    const { member } = i;
    const highstaff = await db.get(`highstaff_${guildId}`);

    if (!highstaff) {
        await i.editReply({
            content: "يرجى تحديد رتبة العليا (highstaff) عن طريق استخدام الامر الاتي: /setup",
            ephemeral: true,
        });
        return;
    }

    if (!member.roles.cache.has(highstaff)) {
        await i.editReply({
            content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـه <@&${highstaff}>.`,
            ephemeral: true,
        });
        return;
    }

    // جلب قائمة المتاجر المعطلة من قاعدة البيانات
    const shops = await db.all();
    const shopChannels = shops.filter((entry) => entry.id.startsWith(`shop_`) && entry.value.status === "0");

    if (shopChannels.length === 0) {
        await i.editReply("**لا توجد متاجر معطلة لتفعيلها.**");
        return;
    }

    const confirmButton = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("confirm-activate-all")
            .setLabel("تأكيد التفعيل")
            .setStyle("Primary")
    );

    const confirmationEmbed = new EmbedBuilder()
        .setTitle("تأكيد تفعيل المتاجر")
        .setDescription(`يوجد ${shopChannels.length} متجر معطل.\nهل تريد بالتأكيد تفعيل جميع المتاجر؟`)
        .setFooter({ text: "By Venlook x Ahmdfc" })
        .setTimestamp(new Date());

    await i.editReply({
        embeds: [confirmationEmbed],
        components: [confirmButton],
        ephemeral: true,
    });

    const filter = (interaction) => interaction.customId === "confirm-activate-all" && interaction.user.id === i.user.id;
    const collector = i.channel.createMessageComponentCollector({ filter, time: 60000 });

    collector.on("collect", async (buttonInteraction) => {
        await buttonInteraction.deferUpdate();

        // تعطيل الزر بعد الضغط عليه
        const disabledButton = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId("confirm-activate-all")
                .setLabel("تأكيد التفعيل")
                .setStyle("Primary")
                .setDisabled(true)
        );

        await i.editReply({
            components: [disabledButton],
            ephemeral: true,
        });

        const imageUrl = await db.get(`image_${guildId}`);
        const logChannelId = await db.get(`logs_${guildId}`);
        const logChannel = logChannelId ? await i.guild.channels.fetch(logChannelId).catch(() => null) : null;

        let activatedCount = 0;

        for (const shop of shopChannels) {
            const channelId = shop.id.split("_")[1]; // استخراج ID القناة
            const channel = await i.guild.channels.fetch(channelId).catch(() => null);
            if (!channel) continue;

            // تفعيل القناة بجعلها مرئية
            await channel.permissionOverwrites.edit(i.guild.roles.everyone, {
                ViewChannel: true,
            });

            // إرسال رسالة التفعيل في القناة
            const embed = new EmbedBuilder()
                .setTitle("تـم تـفـعـيـل الـمـتـجـر")
                .setDescription(`يـرجـى قـرائـة الـقـوانـيـن و الإلـتـزام بـهـا`)
                .setFooter({ text: "By Venlook x Ahmdfc" })
                .setTimestamp(new Date())
                .setImage(imageUrl || "");

            await channel.send({ embeds: [embed] });

            // تحديث حالة المتجر في قاعدة البيانات
            await db.set(shop.id, { ...shop.value, status: "1" });

            // إرسال اللوج
            if (logChannel) {
                const logEmbed = new EmbedBuilder()
                    .setTitle("تـم تـفـعـيـل مـتـجـر")
                    .setDescription(`الـمـسـؤول : <@${i.user.id}>`)
                    .addFields({ name: "الـمـتـجـر :", value: `<#${channel.id}>`, inline: true })
                    .setFooter({ text: "By Venlook x Ahmdfc" })
                    .setTimestamp(new Date())
                    .setImage(imageUrl || "");

                await logChannel.send({ embeds: [logEmbed] });
            }

            activatedCount++;
        }

        await i.editReply({
            content: `**تـم تـفـعـيـل جـمـيـع الـمـتـاجـر بـنـجـاح (${activatedCount}) مـتـجـر.**`,
            embeds: [],
            components: [],
        });

        collector.stop();
    });

    collector.on("end", (collected) => {
        if (!collected.size) {
            i.editReply({
                content: "**تم إلغاء الإجراء بسبب عدم التأكيد.**",
                embeds: [],
                components: [],
            });
        }
    });
}
break;
case "disable": {
 const blacklist = await db.get('blacklist') || [];
  if (blacklist.includes(i.user.id)) {
    return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
  }
  await i.deferReply({ ephemeral: true });

  const shop = i.options.getChannel('shop');
  const reason = i.options.getString('reason');
  const guildId = i.guild.id;
  const { member } = i;
  const admins = await db.get(`shopad_${guildId}`);

  if (!admins) {
    await i.editReply({
      content: "يرجى تحديد الادمن عن طريق استخدام الامر الاتي: /setup",
    });
    return;
  }

  if (!member.roles.cache.has(admins)) {
    await i.editReply(`لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر تـحـتـاج رتـبـه <@&${admins}>`);
    return;
  }

  const datap = await db.get(`shop_${shop.id}_${guildId}`);
  if (!datap) {
    await i.editReply('**هـذا الـروم لـيـس مـتـجـر**');
    return;
  }

  const iiff = await i.guild.channels.fetch(shop.id);
  
  if (datap.status === "0") {
    await i.editReply('**هـذا الـروم مـعـطـل بـالـفـعـل**');
    return;
  }

  if (datap.status === "1") {
    await iiff.permissionOverwrites.edit(i.guild.roles.everyone, {
      ViewChannel: false,
    });

    // استرجاع رابط الصورة من قاعدة البيانات
    const imageUrl = await db.get(`image_${guildId}`);

    const embedlog = new EmbedBuilder()
      .setTitle(`تـم تـعـطـيـل الـمـتـجـر`)
      .setDescription(`الـمـسـؤول : <@${i.user.id}>`)
      .addFields(
        {
          name: 'الـسـبـب',
          value: reason,
          inline: true,
        }
      )
      .setFooter({ text: `By Venlook x Ahmdfc` })
      .setTimestamp(new Date())
      // إضافة الصورة إذا كانت موجودة
      .setImage(imageUrl || '');

    iiff.send({ content: `<@${datap.sellerId}>`, embeds: [embedlog] });
    await i.editReply('**تـم تـعـطـيـل الـمـتـجـر بـنـجـاح**');

    const embeddlog = new EmbedBuilder()
      .setTitle(`تـم تـعـطـيـل مـتـجـر`)
      .setDescription(`الـمـسـؤول : <@${i.user.id}>`)
      .addFields(
        {
          name: 'الـمـتـجـر',
          value: `<#${shop.id}>`,
          inline: true,
        },
        {
          name: 'الـسـبـب',
          value: reason,
          inline: true,
        }
      )
      .setFooter({ text: `By Venlook x Ahmdfc` })
      .setTimestamp(new Date())
      // إضافة الصورة إذا كانت موجودة
            .setImage(imageUrl || `${config.line}`); 
const channelToSendId = await db.get(`logs_${guildId}`);
   const channelToSend = await i.guild.channels.fetch(channelToSendId);
 channelToSend.send({embeds: [embeddlog] });
    await i.editReply({ embeds: [embeddlog] });
    await db.set(`shop_${shop.id}_${guildId}.status`, "0");
  }
} break;
case 'disable-all': {
    const blacklist = await db.get('blacklist') || [];
    if (blacklist.includes(i.user.id)) {
        return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
    }

    await i.deferReply({ ephemeral: true });

    const guild = i.guild;
   const { member} = i;
  const highstaff = await db.get(`highstaff_${guildId}`)
    if (!highstaff) {
        await i.editReply({
            content: "يرجى تحديد رتبة العليا (highstaff) عن طريق استخدام الامر الاتي: /setup", ephemeral: true,
        });
        return;
    }

if (!(member.roles.cache.has(highstaff))) {
  await i.editReply({
    content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـه <@&${highstaff}>.`,
    ephemeral: true, // إذا أردت أن تكون الرسالة مرئية فقط للعضو
  });
  return;
}

    const categories = guild.channels.cache.filter(channel => channel.type === ChannelType.GuildCategory);
    if (!categories.size) {
        await i.editReply('**لا يوجد كاتيجوري في هذا السيرفر**');
        return;
    }

    const confirmButton = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('confirm-disable-all')
                .setLabel('تأكيد التعطيل')
                .setStyle('Primary') // زر Primary
        );

    const confirmationEmbed = new EmbedBuilder()
        .setTitle('تأكيد تعطيل جميع المتاجر')
        .setDescription('هل أنت متأكد أنك تريد تعطيل جميع المتاجر؟')
        .setFooter({ text: 'By Venlook x Ahmdfc' })
        .setTimestamp(new Date());

    await i.editReply({
        embeds: [confirmationEmbed],
        components: [confirmButton],
         ephemeral: true
    });

    const filter = interaction => interaction.customId === 'confirm-disable-all' && interaction.user.id === i.user.id;
    const collector = i.channel.createMessageComponentCollector({ filter, time: 60000 });

    collector.on('collect', async buttonInteraction => {
        await buttonInteraction.deferUpdate();

       const disabledButton = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId('confirm-disable-all')
                .setLabel('تأكيد التعطيل')
                .setStyle('Primary')
                    .setDisabled(true)
            );
        // تحديث الرسالة لتعطيل الزر
        await i.editReply({
            components: [disabledButton],
        });

        const imageUrl = await db.get(`image_${guild.id}`);
        let disabledCount = 0;

        for (const [categoryId, category] of categories) {
            const channels = category.children.cache;

            for (const [channelId, channel] of channels) {
                const channelDataKey = `shop_${channel.id}_${guild.id}`;
                const channelData = await db.get(channelDataKey);

                if (channelData && channelData.status === "1") {
                    await channel.permissionOverwrites.edit(guild.roles.everyone, {
                        ViewChannel: false,
                    });

                    const embed = new EmbedBuilder()
                        .setTitle(`تـم تـعـطـيـل جـمـيـع الـمـتـاجـر`)
                        .setDescription(`الـمـسـؤول : <@${i.user.id}>`)
                        .setFooter({ text: `By Venlook x Ahmdfc` })
                        .setTimestamp(new Date())
                        .setImage(imageUrl ||`${config.line}`);

                    await channel.send({ embeds: [embed] });

                    await db.set(`${channelDataKey}.status`, "0");
                    disabledCount++;
                }
            }
        }

        await i.editReply({
            content: `**تـم تـعـطـيـل ${disabledCount} مـتـجـر بـنـجـاح وإرسال إشعار للجميع**`,
            embeds: [],
            components: [],
        });

        collector.stop();
    });

    collector.on('end', collected => {
        if (!collected.size) {
            i.editReply({
                content: "**تم إلغاء الإجراء بسبب عدم التأكيد.**",
                embeds: [],
                components: [],
            });
        }
    });
} break;
case 'tax-time': {
    const blacklist = await db.get('blacklist') || [];
    if (blacklist.includes(i.user.id)) {
        return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
    }
    await i.deferReply({ ephemeral: true });
    const guild = i.guild;
    const { member} = i;
  const highstaff = await db.get(`highstaff_${guildId}`)
    if (!highstaff) {
        await i.editReply({
            content: "يرجى تحديد رتبة العليا (highstaff) عن طريق استخدام الامر الاتي: /setup", ephemeral: true,        });
        return;
    }

if (!(member.roles.cache.has(highstaff))) {
  await i.editReply({
    content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـه <@&${highstaff}>.`,
    ephemeral: true, // إذا أردت أن تكون الرسالة مرئية فقط للعضو
  });
  return;
}
    const categories = guild.channels.cache.filter(channel => channel.type === ChannelType.GuildCategory);
    if (!categories.size) {
        await i.editReply('**لا يوجد كاتيجوري في هذا السيرفر**');
        return;
    }
    const confirmButton = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('confirm-tax')
                .setLabel('تأكيد ارسال ضريبة المتاجر')
                .setStyle('Primary') // زر Primary
        );
    const confirmationEmbed = new EmbedBuilder()
        .setTitle('تأكيد ارسال ضريبة المتاجر')
        .setDescription('هل أنت متأكد أنك تريد ارسال ضريبة المتاجر؟')
        .setFooter({ text: 'By Venlook x Ahmdfc' })
        .setTimestamp(new Date());
    await i.editReply({
        embeds: [confirmationEmbed],
        components: [confirmButton],
    });
    const filter = interaction => interaction.customId === 'confirm-tax' && interaction.user.id === i.user.id;

    const collector = i.channel.createMessageComponentCollector({ filter, time: 60000 });
    collector.on('collect', async buttonInteraction => {
        await buttonInteraction.deferUpdate();


    const disabledButton = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId('confirm-tax')
                .setLabel('تأكيد ارسال ضريبة المتاجر')
                .setStyle('Primary')
                .setDisabled(true)
            );

        // تحديث الرسالة لتعطيل الزر
        await i.editReply({
            components: [disabledButton],
        });


        const imageUrl = await db.get(`image_${guild.id}`);
        let disabledCount = 0;
        for (const [categoryId, category] of categories) {
            const channels = category.children.cache;
            for (const [channelId, channel] of channels) {
                const channelDataKey = `shop_${channel.id}_${guild.id}`;
                const channelData = await db.get(channelDataKey);
                // Check if tax is enabled for the category
                const hasTax = await db.get(`shop_${channel.id}_${guild.id}.hasTax`);
                const taxPrice = await db.get(`shop_${channel.id}_${guild.id}.taxPrice`);
    const owner = await db.get(`shop_${channel.id}_${guild.id}.sellerId`);
                if (channelData && channelData.status === "1" && hasTax) {
                    await channel.permissionOverwrites.edit(guild.roles.everyone, {
                        ViewChannel: false,
                    });
                    await channel.permissionOverwrites.edit(owner, {
                        ViewChannel: true,
                        SendMessages:true,
                        AddReactions:true,
                        AttachFiles:true,
                        EmbedLinks:true,
                        UseExternalEmojis: true,
                        ReadMessageHistory:true
                    });
                    // Prepare embed for the tax notification
  const buytax = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('buy-tax')
                .setLabel('دفع الضــريبة')
                .setStyle('Primary') // زر Primary
        );
                    const embed = new EmbedBuilder()
                        .setTitle(`حان وقت الضريبة!`)
                        .setDescription(`يرجى دفع ضريـبة المتــجر
وقــدرهــا $ ${taxPrice}
عنــ طريق اســتخدام الــزر اللــذي بــ الاســفل`)
                        .setFooter({ text: `By Venlook x Ahmdfc` })
                        .setTimestamp(new Date())
                        .setImage(imageUrl || '');
                    await channel.send({ embeds: [embed] , components: [buytax]});
                    await db.set(`${channelDataKey}.status`, "0");
                    disabledCount++;
                }
            }
        }
        await i.editReply({
            content: `**تـم تفعيل وضع الضريبه ${disabledCount} مـتـجـر بـنـجـاح وإرسال إشعار للجميع**`,
            embeds: [],
            components: [],
        });
        collector.stop();
    });
    collector.on('end', collected => {
        if (!collected.size) {
            i.editReply({
                content: "**تم إلغاء الإجراء بسبب عدم التأكيد.**",
                embeds: [],
                components: [],
            });
        }
    });

} break;
   case "say-emabed": {
 const blacklist = await db.get('blacklist') || [];
  if (blacklist.includes(i.user.id)) {
    return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
  }
const { member} = i;
  const highstaff = await db.get(`highstaff_${guildId}`)
    if (!highstaff) {
        await i.reply({
            content: "يرجى تحديد رتبة العليا (highstaff) عن طريق استخدام الامر الاتي: /setup", ephemeral: true,
        });
        return;
    }

if (!(member.roles.cache.has(highstaff))) {
  await i.reply({
    content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـه <@&${highstaff}>.`,
    ephemeral: true, // إذا أردت أن تكون الرسالة مرئية فقط للعضو
  });
  return;
}
       const ch = i.options.getChannel('room');
     const targetChannel = ch ?? i.channel;
       const title = i.options.getString(`title`);
       const msg = i.options.getString(`msg`);
       const im = i.options.getString(`image`);
        const guild = i.guild;
const serverName = guild.name;
const serverIcon = guild.iconURL();
       
    const embed = new EmbedBuilder()
        .setTitle(`${title || `${serverName}`}`) 
        .setDescription(`${msg}`)                                                  
        .setColor('#2196F3')
        .setImage(im) 
        .setThumbnail(serverIcon)
        .setTimestamp()
    	.setFooter({ text: `by ${i.user.tag}`, iconURL: `${serverIcon}` })
                       
   await targetChannel.send({ embeds: [embed]}) 
       
        i.reply({ content: '** Done ✅ **', ephemeral: true });           
       } break; 
   case 'server-info': {
 const blacklist = await db.get('blacklist') || [];
  if (blacklist.includes(i.user.id)) {
    return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
  }
    const guildId = i.guild.id;
if (!i.member.permissions.has('Administrator')) {
    return i.reply({ content: '❌ يجب أن تكون لديك صلاحية **Administrator** لاستخدام هذا الأمر!', ephemeral: true });
}
    // استرجاع القيم من قاعدة البيانات
      const imageUrl = await db.get(`image_${guildId}`);
    const logs = await db.get(`logs_${guildId}`);
    const orderRoom = await db.get(`orderroom_${guildId}`);
    const actionRoom = await db.get(`auctionroom_${guildId}`);
    const shopcat = await db.get(`catbuy_shop_${guildId}`);
    const auctioncat = await db.get(`catbuy_auction_${guildId}`);
    const ordercat = await db.get(`catbuy_order_${guildId}`);
    const shopAdmin = await db.get(`shopad_${guildId}`);
    const orderAdmin = await db.get(`orderad_${guildId}`);
    const auctionAdmin = await db.get(`auctionad_${guildId}`);
    const bank = await db.get(`bank_${guildId}`);
  const highstaff = await db.get(`highstaff_${guildId}`)

    // تحضير الرد مع القيم المحددة أو "غير محدد"
    const embed = new EmbedBuilder()
       // .setColor('#0099ff')
        .setTitle('معلومات السيرفر')
        .addFields(
            { name: 'روم لوق المتاجر', value: logs ? `<#${logs}>` : 'غير محدد', inline: true },
            { name: 'روم الطلبات', value: orderRoom ? `<#${orderRoom}>` : 'غير محدد', inline: true },
            { name: 'روم المزادات', value: actionRoom ? `<#${actionRoom}>` : 'غير محدد', inline: true },
            { name: 'كتاغوري تكتات شراء متاجر', value: shopcat ? `<#${shopcat}>` : 'غير محدد', inline: true },      
            { name: 'كتاغوري تكتات شراء مزاد', value: auctioncat ? `<#${auctioncat}>` : 'غير محدد', inline: true },      
            { name: 'كتاغوري تكتات شراء طلبات', value: ordercat ? `<#${ordercat}>` : 'غير محدد', inline: true },          
            { name: 'مسؤول المتاجر', value: shopAdmin ? `<@&${shopAdmin}>` : 'غير محدد', inline: true },
            { name: 'مسؤول الطلبات', value: orderAdmin ? `<@&${orderAdmin}>` : 'غير محدد', inline: true },
            { name: 'مسؤول المزاد', value: auctionAdmin ? `<@&${auctionAdmin}>` : 'غير محدد', inline: true },
            { name: 'بنك السيرفر', value: bank ? `<@${bank}>` : 'غير محدد', inline: true },
            { name: 'رتبة العليا', value: highstaff ? `<@&${highstaff}>` : 'غير محدد', inline: true },
        )
        .setFooter({ text: 'معلومات السيرفر' })
        // إضافة الصورة إذا كانت موجودة
               .setImage(imageUrl || `${config.line}`); 

    i.reply({ embeds: [embed] });
} break;
case 'setup': {
  try {
    await i.deferReply({ ephemeral: true });
    const blacklist = await db.get('blacklist') || [];
    if (blacklist.includes(i.user.id)) {
        return i.editReply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
    }
if (!i.member.permissions.has('Administrator')) {
    return i.editReply({ content: '❌ يجب أن تكون لديك صلاحية **Administrator** لاستخدام هذا الأمر!' });
}
    const guildId = i.guild.id;

    // تحديث القيم إذا تم تحديدها
    if (i.options.getChannel('logs')) await db.set(`logs_${guildId}`, i.options.getChannel('logs').id);
    if (i.options.getChannel('order-room')) await db.set(`orderroom_${guildId}`, i.options.getChannel('order-room').id);
    if (i.options.getChannel('action-room')) await db.set(`auctionroom_${guildId}`, i.options.getChannel('action-room').id);
    if (i.options.getChannel('buy-shop-tickets')) await db.set(`catbuy_shop_${guildId}`, i.options.getChannel('buy-shop-tickets').id);
    if (i.options.getChannel('buy-auction-tickets')) await db.set(`catbuy_auction_${guildId}`, i.options.getChannel('buy-auction-tickets').id);
    if (i.options.getChannel('buy-order-tickets')) await db.set(`catbuy_order_${guildId}`, i.options.getChannel('buy-order-tickets').id);
    if (i.options.getRole('high-staff')) await db.set(`highstaff_${guildId}`, i.options.getRole('high-staff').id);
    if (i.options.getRole('shop-admin')) await db.set(`shopad_${guildId}`, i.options.getRole('shop-admin').id);
    if (i.options.getRole('order-admin')) await db.set(`orderad_${guildId}`, i.options.getRole('order-admin').id);
    if (i.options.getRole('auction-admin')) await db.set(`auctionad_${guildId}`, i.options.getRole('auction-admin').id);
    if (i.options.getUser('bank')) await db.set(`bank_${guildId}`, i.options.getUser('bank').id);

    // استلام الصورة الرمزية إذا تم تحديدها
    const imageAttachment = i.options.getAttachment('line');
    if (imageAttachment) await db.set(`image_${guildId}`, imageAttachment.url);
      const imageUrl = await db.get(`image_${guildId}`);
    const logs = await db.get(`logs_${guildId}`);
    const orderRoom = await db.get(`orderroom_${guildId}`);
    const actionRoom = await db.get(`auctionroom_${guildId}`);
    const shopcat = await db.get(`catbuy_shop_${guildId}`);
    const auctioncat = await db.get(`catbuy_auction_${guildId}`);
    const ordercat = await db.get(`catbuy_order_${guildId}`);
    const shopAdmin = await db.get(`shopad_${guildId}`);
    const orderAdmin = await db.get(`orderad_${guildId}`);
    const auctionAdmin = await db.get(`auctionad_${guildId}`);
    const bank = await db.get(`bank_${guildId}`);
  const highstaff = await db.get(`highstaff_${guildId}`)

    // إعداد الـ Embed لعرض الإعدادات
    const embed = new EmbedBuilder()
        .setColor(0x00AE86)
        .setTitle('الإعدادات التي تم تحديدها')
        .addFields(

            { name: 'روم لوق المتاجر', value: logs ? `<#${logs}>` : 'غير محدد', inline: true },
            { name: 'روم الطلبات', value: orderRoom ? `<#${orderRoom}>` : 'غير محدد', inline: true },
            { name: 'روم المزادات', value: actionRoom ? `<#${actionRoom}>` : 'غير محدد', inline: true },
            { name: 'كتاغوري تكتات شراء متاجر', value: shopcat ? `<#${shopcat}>` : 'غير محدد', inline: true },      
            { name: 'كتاغوري تكتات شراء مزاد', value: auctioncat ? `<#${auctioncat}>` : 'غير محدد', inline: true },      
            { name: 'كتاغوري تكتات شراء طلبات', value: ordercat ? `<#${ordercat}>` : 'غير محدد', inline: true },          
            { name: 'مسؤول المتاجر', value: shopAdmin ? `<@&${shopAdmin}>` : 'غير محدد', inline: true },
            { name: 'مسؤول الطلبات', value: orderAdmin ? `<@&${orderAdmin}>` : 'غير محدد', inline: true },
            { name: 'مسؤول المزاد', value: auctionAdmin ? `<@&${auctionAdmin}>` : 'غير محدد', inline: true },
            { name: 'بنك السيرفر', value: bank ? `<@${bank}>` : 'غير محدد', inline: true },
            { name: 'رتبة العليا', value: highstaff ? `<@&${highstaff}>` : 'غير محدد', inline: true },
        ); 
             if (imageUrl) {
        embed.setImage(imageUrl);
    }
    await i.editReply({ embeds: [embed] });
  } catch (err) {
    console.error('setup error:', err);
    try { await i.editReply({ content: `❌ حصل خطأ: ${err.message}` }); } catch (_) {}
  }
} break;
case 'setup-prices': {
    const blacklist = await db.get('blacklist') || [];
    if (blacklist.includes(i.user.id)) {
        return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
    }
if (!i.member.permissions.has('Administrator')) {
    return i.reply({ content: '❌ يجب أن تكون لديك صلاحية **Administrator** لاستخدام هذا الأمر!', ephemeral: true });
}

    const guildId = i.guild.id;

    // تحديث القيم إذا تم تحديدها

if (i.options.getInteger('remove-warn-credit')) db.set(`removewarncredit_${guildId}`, i.options.getInteger('remove-warn-credit'));
if (i.options.getInteger('change-partners-credit')) db.set(`changepartnerscredit_${guildId}`, i.options.getInteger('change-partners-credit'));
if (i.options.getInteger('everyone-price')) db.set(`evrypri_${guildId}`, i.options.getInteger('everyone-price'));
if (i.options.getInteger('here-price')) db.set(`herepri_${guildId}`, i.options.getInteger('here-price'));
if (i.options.getInteger('shop-mention-price')) db.set(`shopprice_${guildId}`, i.options.getInteger('shop-mention-price'));
if (i.options.getInteger('order-every-price-credit')) db.set(`order-evrypri_${guildId}`, i.options.getInteger('order-every-price-credit'));
if (i.options.getInteger('order-here-price-credit')) db.set(`order-herepri_${guildId}`, i.options.getInteger('order-here-price-credit'));
if (i.options.getInteger('auction-every-price-credit')) db.set(`auction-evrypri_${guildId}`, i.options.getInteger('auction-every-price-credit'));
if (i.options.getInteger('auction-here-price-credit')) db.set(`auction-herepri_${guildId}`, i.options.getInteger('auction-here-price-credit'));
if (i.options.getInteger('change-name')) db.set(`changename_${guildId}`, i.options.getInteger('change-name'));
if (i.options.getInteger('change-owner')) db.set(`changeowner_${guildId}`, i.options.getInteger('change-owner'));
if (i.options.getInteger('auto-message')) db.set(`automessage_${guildId}`, i.options.getInteger('auto-message'));

  
   
    // استرجاع القيم من قاعدة البيانات لعرضها
const removeWarnCredit = await db.get(`removewarncredit_${guildId}`);
const changePartnersCredit = await db.get(`changepartnerscredit_${guildId}`);
const changeName = await db.get(`changename_${guildId}`);
const changeOwner = await db.get(`changeowner_${guildId}`);
const autoMessage = await db.get(`automessage_${guildId}`);

const everyonePrice = await db.get(`evrypri_${guildId}`);
const herePrice = await db.get(`herepri_${guildId}`);
const shopMentionPrice = await db.get(`shopprice_${guildId}`);

const orderEveryPriceCredit = await db.get(`order-evrypri_${guildId}`);
const orderHerePriceCredit = await db.get(`order-herepri_${guildId}`);

const auctionEveryPriceCredit = await db.get(`auction-evrypri_${guildId}`);
const auctionHerePriceCredit = await db.get(`auction-herepri_${guildId}`);

   

    // إعداد الـ Embed لعرض الإعدادات
    const embed = new EmbedBuilder()
        .setColor(0x00AE86)
        .setTitle('أسعار الخدمات التي تم تحديدها')
        .addFields(
   
            { name: 'سعر ازالة التحذير', value: removeWarnCredit ? `${removeWarnCredit}` : 'غير محدد', inline: true },
            { name: 'سعر اضافة/حذف شريك', value: changePartnersCredit ? `${changePartnersCredit}` : 'غير محدد', inline: true },
            { name: 'سعر منشن ايفري للمتاجر', value: everyonePrice ? `${everyonePrice}` : 'غير محدد', inline: true },
            { name: 'سعر منشن هير للمتاجر', value: herePrice ? `${herePrice}` : 'غير محدد', inline: true },
            { name: 'سعر منشن متجر', value: shopMentionPrice ? `${shopMentionPrice}` : 'غير محدد', inline: true },
            { name: 'سعر منشن ايفري با الكردت للطلبات', value: orderEveryPriceCredit ? `${orderEveryPriceCredit}` : 'غير محدد', inline: true },
            { name: 'سعر منشن هير با الكردت للطلبات', value: orderHerePriceCredit ? `${orderHerePriceCredit}` : 'غير محدد', inline: true },
            { name: 'سعر منشن ايفري للمزاد باالكردت', value: auctionEveryPriceCredit ? `${auctionEveryPriceCredit}` : 'غير محدد', inline: true },
            { name: 'سعر منشن هير با الكردت للمزادات', value: auctionHerePriceCredit ? `${auctionHerePriceCredit}` : 'غير محدد', inline: true },
            { name: 'سعر تغيير اسم المتجر', value: changeName ? `${changeName}` : 'غير محدد', inline: true },
            { name: 'سعر تغيير صاحب المتجر', value: changeOwner ? `${changeOwner}` : 'غير محدد', inline: true },
            { name: 'سعر نشر تلقائي للمتاجر', value: autoMessage ? `${autoMessage}` : 'غير محدد', inline: true }
        );

    // إرسال الـ Embed
    await i.reply({ embeds: [embed], ephemeral: true });
} break;
case 'setup-images': {
    const blacklist = await db.get('blacklist') || [];
    if (blacklist.includes(i.user.id)) {
        return i.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
    }
if (!i.member.permissions.has('Administrator')) {
    return i.reply({ content: '❌ يجب أن تكون لديك صلاحية **Administrator** لاستخدام هذا الأمر!', ephemeral: true });
}
    const guildId = i.guild.id;

    // دالة مساعدة للتحقق من صحة الرابط
    function isValidUrl(url) {
        try {
            new URL(url);
            return true;
        } catch (err) {
            return false;
        }
    }

    // تحديث الصور إذا تم تحديدها
    const buyShopImageUrl = i.options.getString('buy-shop-image');
    const buyShopImageAttachment = i.options.getAttachment('buy-shop-image-attachment');

    const buyOrderImageUrl = i.options.getString('buy-order-image');
    const buyOrderImageAttachment = i.options.getAttachment('buy-order-image-attachment');

    const buyAuctionImageUrl = i.options.getString('buy-auction-image');
    const buyAuctionImageAttachment = i.options.getAttachment('buy-auction-image-attachment');

    const priceImageUrl = i.options.getString('price-image');
    const priceImageAttachment = i.options.getAttachment('price-image-attachment');

    const lineurl = i.options.getString('line');
    const lineAttachment = i.options.getAttachment('line-attachment');

    if (buyShopImageUrl && isValidUrl(buyShopImageUrl)) {
        await db.set(`buyshopimage_${guildId}`, buyShopImageUrl);
    } else if (buyShopImageAttachment) {
        await db.set(`buyshopimage_${guildId}`, buyShopImageAttachment.url);
    }

    if (buyOrderImageUrl && isValidUrl(buyOrderImageUrl)) {
        await db.set(`buyorderimage_${guildId}`, buyOrderImageUrl);
    } else if (buyOrderImageAttachment) {
        await db.set(`buyorderimage_${guildId}`, buyOrderImageAttachment.url);
    }

    if (buyAuctionImageUrl && isValidUrl(buyAuctionImageUrl)) {
        await db.set(`buyauctionimage_${guildId}`, buyAuctionImageUrl);
    } else if (buyAuctionImageAttachment) {
        await db.set(`buyauctionimage_${guildId}`, buyAuctionImageAttachment.url);
    }

    if (priceImageUrl && isValidUrl(priceImageUrl)) {
        await db.set(`priceImage_${guildId}`, priceImageUrl);
    } else if (priceImageAttachment) {
        await db.set(`priceImage_${guildId}`, priceImageAttachment.url);
    }

    if (lineurl && isValidUrl(lineurl)) {
        await db.set(`image_${guildId}`, lineurl);
    } else if (lineAttachment) {
        await db.set(`image_${guildId}`, lineAttachment.url);
    }

    // استرجاع الصور من قاعدة البيانات لعرضها
    const savedBuyShopImage = await db.get(`buyshopimage_${guildId}`);
    const savedBuyOrderImage = await db.get(`buyorderimage_${guildId}`);
    const savedBuyAuctionImage = await db.get(`buyauctionimage_${guildId}`);
    const savedpriceImage = await db.get(`priceImage_${guildId}`);
    const savedline = await db.get(`image_${guildId}`);

    // إعداد الـ Embed لعرض الإعدادات
    const embed = new EmbedBuilder()
        .setColor(0x00AE86)
        .setTitle('الصور التي تم تحديدها')
        .addFields(
            { name: 'صورة شراء متجر', value: savedBuyShopImage ? '[عرض الصورة](' + savedBuyShopImage + ')' : 'غير محدد', inline: true },
            { name: 'صورة شراء طلب', value: savedBuyOrderImage ? '[عرض الصورة](' + savedBuyOrderImage + ')' : 'غير محدد', inline: true },
            { name: 'صورة شراء مزاد', value: savedBuyAuctionImage ? '[عرض الصورة](' + savedBuyAuctionImage + ')' : 'غير محدد', inline: true },
            { name: 'صورة انفو الاسعار', value: savedpriceImage ? '[عرض الصورة](' + savedpriceImage + ')' : 'غير محدد', inline: true },
            { name: 'صورة خط السيرفر', value: savedline ? '[عرض الصورة](' + savedline + ')' : 'غير محدد', inline: true }
        );

    // إضافة الصور إلى الـ Embed إذا كانت موجودة
    if (savedBuyShopImage) embed.setImage(savedBuyShopImage);
    else if (savedBuyOrderImage) embed.setImage(savedBuyOrderImage);
    else if (savedBuyAuctionImage) embed.setImage(savedBuyAuctionImage);
    else if (savedline) embed.setImage(savedline);
    else if (savedpriceImage) embed.setImage(savedpriceImage);

    // إرسال الـ Embed
    await i.reply({ embeds: [embed], ephemeral: true });
} break;
    }
  }
});



// مهلة المنشن بين كل منشن والتاني (بالدقايق) = ساعة - غيّر الرقم لو عايز
const MENTION_COOLDOWN_MIN = 60;

client.on('messageCreate', async m => {
    if (!m.guild || m.author.bot) return;
    const guildId = m.guild.id;
    if (!m.content) return;
    const data = await db.get(`shop_${m.channel.id}_${guildId}`);
    if (!data) return;

    const usesEveryone = m.content.includes('@everyone');
    const usesHere = m.content.includes('@here');
    const usesRole = !!data.shopmen && m.content.includes(`<@&${data.shopmen}>`);
    if (!usesEveryone && !usesHere && !usesRole) return;

    const warnShop = async () => {
        data.warns = (Number(data.warns) || 0) + 1;
        await db.set(`shop_${m.channel.id}_${guildId}`, data);
    };

    // مهلة المنشن: لو لسه مخلصتش المهلة من آخر منشن = تحذير
    const cdKey = `mentioncd_${m.channel.id}_${guildId}`;
    const lastMention = Number(await db.get(cdKey)) || 0;
    const cdMs = MENTION_COOLDOWN_MIN * 60 * 1000;
    const remaining = lastMention + cdMs - Date.now();
    if (remaining > 0) {
        const mins = Math.ceil(remaining / 60000);
        await m.reply(`**⚠️ تحذير: لا يمكنك عمل منشن قبل انتهاء مهلة المنشن، باقي ${mins} دقيقة**`).catch(() => {});
        await m.delete().catch(() => {});
        await warnShop();
        return;
    }

    let usedAny = false;
    let sendLine = false;
    let violated = false;

    // @everyone
    if (usesEveryone) {
        if (data.everyoneMentions > 0) {
            data.everyoneMentions = data.everyoneMentions - 1;
            usedAny = true;
            sendLine = true;
            if (data.everyoneMentions > 0 && data.everyoneMentions < 5) {
                await m.reply(data.everyoneMentions === 1
                    ? `**باقيلك منشن Everyone بالتوفيق يا معلم**`
                    : `**باقيلك ${data.everyoneMentions} منشن Everyone بالتوفيق يا معلم**`).catch(() => {});
            }
        } else {
            violated = true;
            await m.reply(`**لا يمكنك عمل منشن افري لأنك استنفدت رصيدك**`).catch(() => {});
        }
    }

    // @here
    if (usesHere) {
        if (data.hereMentions > 0) {
            data.hereMentions = data.hereMentions - 1;
            usedAny = true;
            sendLine = true;
            if (data.hereMentions > 0 && data.hereMentions < 5) {
                await m.reply(data.hereMentions === 1
                    ? `**باقيلك منشن Here بالتوفيق يا معلم**`
                    : `**باقيلك ${data.hereMentions} منشن Here بالتوفيق يا معلم**`).catch(() => {});
            }
        } else {
            violated = true;
            await m.reply(`**لا يمكنك عمل منشن هير لأنك استنفدت رصيدك**`).catch(() => {});
        }
    }

    // منشن رول المتجر
    if (usesRole) {
        if (data.shopRoleMentions > 0) {
            data.shopRoleMentions = data.shopRoleMentions - 1;
            usedAny = true;
            if (data.shopRoleMentions > 0 && data.shopRoleMentions < 5) {
                await m.reply(data.shopRoleMentions === 1
                    ? `**باقيلك منشن متجر بالتوفيق يا معلم**`
                    : `**باقيلك ${data.shopRoleMentions} منشن متجر بالتوفيق يا معلم**`).catch(() => {});
            }
        } else {
            violated = true;
            await m.reply(`**لا يمكنك عمل منشن المتجر لأنك استنفدت رصيدك**`).catch(() => {});
        }
    }

    if (violated) {
        await m.delete().catch(() => {});
        data.warns = (Number(data.warns) || 0) + 1;
    }
    await db.set(`shop_${m.channel.id}_${guildId}`, data);

    if (usedAny && !violated) {
        await db.set(cdKey, Date.now());
        // الخط بيتبعت مرة واحدة بس حتى لو الرسالة فيها everyone و here
        if (sendLine) {
            await m.channel.send({ content: `${(await db.get(`image_${guildId}`)) || config.line}` }).catch(() => {});
        }
    }
});



client.on('messageCreate', async (m) => {
    const guildId = m.guild.id;
    const { guild, channel } = m;
    if (!m.content) return;

    // التحقق من حالة التفعيل
    const featureStatus = await db.get(`shop_${channel.id}_${guildId}.status`);
    if (featureStatus !== "1") return; // إذا كانت غير مفعلة، لا تفعل شيئًا

    const data = await db.get(`shop_${channel.id}_${guildId}`);
    const warns = await db.get(`shop_${channel.id}_${guildId}.warns`);
    const sellerId = await db.get(`shop_${channel.id}_${guildId}.sellerId`);
    const admins = await db.get(`shopad_${guildId}`);

    if (!data) return;
    const warningLimit = await db.get(`shop_${channel.id}_${guildId}.maxWarns`);
    
    if (warns > warningLimit) {
        // إخفاء القناة عند تجاوز الحد
        await channel.permissionOverwrites.set([
            {
                id: guild.roles.everyone.id,
                deny: [
                    PermissionFlagsBits.SendMessages,
                    PermissionFlagsBits.AddReactions,
                    PermissionFlagsBits.CreatePublicThreads,
                    PermissionFlagsBits.CreatePrivateThreads,
                    PermissionFlagsBits.AttachFiles,
                    PermissionFlagsBits.EmbedLinks,
                    PermissionFlagsBits.ViewChannel,
                ],
            },
            {
                id: sellerId,
                allow: [
                    PermissionFlagsBits.SendMessages,
                    PermissionFlagsBits.AddReactions,
                    PermissionFlagsBits.AttachFiles,
                    PermissionFlagsBits.UseExternalEmojis,
                    PermissionFlagsBits.ReadMessageHistory,
                ],
            },
            {
                id: admins,
                allow: [
                    PermissionFlagsBits.SendMessages,
                    PermissionFlagsBits.AddReactions,
                    PermissionFlagsBits.AttachFiles,
                    PermissionFlagsBits.MentionEveryone,
                    PermissionFlagsBits.EmbedLinks,
                    PermissionFlagsBits.UseExternalEmojis,
                    PermissionFlagsBits.ReadMessageHistory,
                ],
            },
        ]);

        // إرسال الرسالة وتحديث قاعدة البيانات
        const embed = new EmbedBuilder()
            .setTitle('تم اخفاء المتجر')
            .setDescription('لقد تم اخفاء المتجر بسبب تجاوز الحد المسموح للتحذيرات.')
            .addFields(
                { name: 'تاريخ الاخفاء', value: new Date().toLocaleString(), inline: true },
                { name: 'صاحب المتجر', value: `<@${sellerId}>`, inline: true },
                { name: 'سبب الاخفاء', value: `تجاوز عدد التحذيرات المسموح: ${warns}/${warningLimit}`, inline: true },
                { name: 'عدد التحذيرات الحالية', value: `${warns}`, inline: true },
                { name: 'أقصى عدد تحذيرات', value: `${warningLimit}`, inline: true }
            )
            .setColor(0xff0000) // اللون الأحمر للإشارة إلى الإخفاء
            .setTimestamp();

        await channel.send({ embeds: [embed] });
        await db.set(`shop_${channel.id}_${guildId}.status`, "0"); // تعيين الحالة إلى "0" عند الإخفاء

        // إرسال رسالة إلى القناة اللوج الخاصة بالمتجر
        const logs = await db.get(`logs_${guildId}`);
        const logChannel = guild.channels.cache.get(logs);
        if (logChannel) {
            await logChannel.send({ embeds: [embed] });
        }
    } else if (warns <= warningLimit) {
        // إعادة فتح القناة عند انخفاض التحذيرات
        const currentStatus = await db.get(`shop_${channel.id}_${guildId}.status`);
        if (currentStatus === "0") {
            // إعادة إعدادات الأذونات
            await channel.permissionOverwrites.set([
                {
                    id: guild.roles.everyone.id,
                    allow: [
                        PermissionFlagsBits.SendMessages,
                        PermissionFlagsBits.AddReactions,
                        PermissionFlagsBits.CreatePublicThreads,
                        PermissionFlagsBits.CreatePrivateThreads,
                        PermissionFlagsBits.AttachFiles,
                        PermissionFlagsBits.EmbedLinks,
                        PermissionFlagsBits.ViewChannel,
                    ],
                },
                {
                    id: sellerId,
                    allow: [
                        PermissionFlagsBits.SendMessages,
                        PermissionFlagsBits.AddReactions,
                        PermissionFlagsBits.AttachFiles,
                        PermissionFlagsBits.UseExternalEmojis,
                        PermissionFlagsBits.ReadMessageHistory,
                    ],
                },
                {
                    id: admins,
                    allow: [
                        PermissionFlagsBits.SendMessages,
                        PermissionFlagsBits.AddReactions,
                        PermissionFlagsBits.AttachFiles,
                        PermissionFlagsBits.MentionEveryone,
                        PermissionFlagsBits.EmbedLinks,
                        PermissionFlagsBits.UseExternalEmojis,
                        PermissionFlagsBits.ReadMessageHistory,
                    ],
                },
            ]);

            // إرسال الرسالة وتحديث قاعدة البيانات
            const embed = new EmbedBuilder()
                .setTitle('تم اعادة فتح المتجر')
                .setDescription('تم اعادة فتح متجرك بعد انخفاض عدد التحذيرات.')
                .addFields(
                    { name: 'تاريخ إعادة الفتح', value: new Date().toLocaleString(), inline: true },
                    { name: 'صاحب المتجر', value: `<@${sellerId}>`, inline: true },
                    { name: 'عدد التحذيرات الحالية', value: `${warns}`, inline: true },
                    { name: 'أقصى عدد تحذيرات', value: `${warningLimit}`, inline: true }
                )
                .setColor(0x00ff00) // اللون الأخضر للإشارة إلى الفتح
                .setTimestamp();

            await channel.send({ embeds: [embed] });
            await db.set(`shop_${channel.id}_${guildId}.status`, "1"); // تعيين الحالة إلى "1" عند إعادة الفتح
        }
    }
});




client.on("messageCreate", async message => {
  if (!message.guild || message.author.bot) return;

  const guildId = message.guild.id;
  const args = message.content.trim().split(/ +/);
  const command = args.shift().toLowerCase();

  const shortcut = await db.get(`shortcut_call_${guildId}`) || '+come';

  if (command === shortcut) {
    if (!message.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
      return message.reply({ 
        embeds: [new EmbedBuilder().setColor(0xff0000).setDescription('❌ **ليس لديك صلاحية لاستخدام هذا الأمر.**')]
      });
    }

    const user = message.mentions.users.first() || (args[0] ? await client.users.fetch(args[0]).catch(() => null) : null);
    const msg = args.slice(1).join(" ");

    if (!user) {
      return message.reply({ 
        embeds: [new EmbedBuilder().setColor(0xff0000).setDescription('⚠ **يجب تحديد عضو لإرسال الرسالة.**')] 
      });
    }

    if (user.bot) {
      return message.reply({ 
        embeds: [new EmbedBuilder().setColor(0xff0000).setDescription('🤖 **لا يمكنك استخدام الأمر على البوتات.**')]
      });
    }

    const embedMessage = new EmbedBuilder()
      .setColor(0xffff00)
      .setDescription(`**📢 رسالة: ${msg || 'لا يوجد سبب'}\n📍 القناة: ${message.channel}**`);

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setLabel('🔗 فتح الرسالة').setStyle(ButtonStyle.Link).setURL(`https://discord.com/channels/${message.guild.id}/${message.channel.id}/${message.id}`),
      new ButtonBuilder().setLabel('👤 بروفايل المرسل').setStyle(ButtonStyle.Link).setURL(`https://discord.com/users/${message.author.id}`)
    );

    try {
      await user.send({ embeds: [embedMessage], components: [row] });
      return message.reply({ 
        embeds: [new EmbedBuilder().setColor(0x00ff00).setDescription('✅ **تم استدعاء العضو بنجاح**')] 
      });
    } catch (error) {
      return message.reply({ 
        embeds: [new EmbedBuilder().setColor(0xff0000).setDescription('⚠ **تعذر إرسال الرسالة. قد يكون العضو مغلقًا للرسائل الخاصة.**')] 
      });
    }
  }
});

//tax
client.on("messageCreate", async (message) => {
  if (message.author.bot) return;

  const guildId = message.guild.id;
  const shortcutTax = await db.get(`shortcut_tax_${guildId}`) || "+tax"; // Removed 'await' to use the sync version

  if (message.content.startsWith(shortcutTax)) {
    let args = message.content.split(" ")[1];
    if (!args) return message.reply("Please provide a valid number!");

    if (args.endsWith("m")) args = args.replace(/m/gi, "") * 1000000;
    else if (args.endsWith("k") || args.endsWith("K")) args = args.replace(/[kK]/gi, "") * 1000;

    let args2 = parseInt(args);
    if (isNaN(args2)) return message.reply("Please provide a valid number!");

    let tax = Math.floor(args2 * (20 / 19) + 1);

    message.reply(`> **Your tax is: ${tax}**`);
  }
});


client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;
    if (interaction.customId !== 'dashboardshop') return;

    try {
        // Validate guild and member
        if (!interaction.inGuild()) {
            return await interaction.reply({
                content: '❌ هذا الأمر متاح فقط داخل السيرفرات',
                ephemeral: true
            });
        }

        const { guild, member, channel } = interaction;
        const guildId = guild.id;
        const userId = member.id;

        // Fetch shop data
        const shopKey = `shop_${channel.id}_${guildId}`;
        const data = await db.get(shopKey);
        
        if (!data) {
            return await interaction.reply({
                content: '❌ عفواً لم أستطع العثور على هذا المتجر',
                ephemeral: true
            });
        }

        // Check permissions
        const owner = await db.get(`${shopKey}.sellerId`);
        const partners = await db.get(`${shopKey}.partners`) || [];
        
        if (userId !== owner && !partners.includes(userId)) {
            const embed = new EmbedBuilder()
                .setColor('Red')
                .setTitle('❌ صلاحية مرفوضة')
                .setDescription(`عــفواً يجب أن تكون صــاحب المتجر أو شــريك فيه لاستخدام هذه الأزرار\nصاحب المتجر الحالي: <@${owner || 'غير معروف'}>`);
            
            return await interaction.reply({ 
                embeds: [embed],
                ephemeral: true
            });
        }

        // Prepare dashboard embed
        const imageUrl = await db.get(`image_${guildId}`);
        
        const shopdashbordembd = new EmbedBuilder()
            .setColor('#2b2d31')
            .setTitle('** لوحة تحكم المتجر **')
            .setDescription(`
\`#\` يــرجــى اخــتيــار الخــدمة عن طــريق الأزرار بالأسفل 
> \`-\` جــميع الخــدمــات تلقــائية ${config.hatemoji} 
> \`-\` كــن حــذراً عند اختــيار الخــدمة ${config.warn} 
> \`-\` أي عمــلية تحــويل داخــل المتــجر ${config.money} 
> \`-\` كــل عمــلية تحــويل لها وقــت محدد ${config.refrechmark} 
> \`-\` يــجب عليك التــحويل بــعد رســالة البــوت ${config.refrechmark} 
> \`-\` لتــجنب حدــوث مشاكل يــرجى اتــباع تعلــيمات البــوت ${config.warn}`)
            .setAuthor({
                name: guild.name,
                iconURL: guild.iconURL({ size: 1024 })
            })
            .setThumbnail(interaction.user.displayAvatarURL())
            .setFooter({
                text: 'By Venlook x Ahmdfc',
                iconURL: interaction.user.displayAvatarURL()
            });

        if (imageUrl) shopdashbordembd.setImage(imageUrl);

        // Create buttons
        const firstButtonRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('mention')
                .setLabel('شــراء منــشنات')
                .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
                .setCustomId('partnerdashboard')
                .setLabel('تــحكم بالشــركاء')
                .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
                .setCustomId('ownerchange')
                .setLabel('نقــل ملكيــة المتــجر')
                .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
                .setCustomId('changeName')
                .setLabel('تــغير اســم المتــجر')
                .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
                .setCustomId('remove_warn')
                .setLabel('إزالــة تحذيــرات')
                .setStyle(ButtonStyle.Secondary)
        );
        const onehalfButtonRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('sendmesageshop')
                .setLabel('ارســال رســالة باســتخدام البــوت')
                .setStyle(ButtonStyle.Secondary)
        );

        const secondButtonRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('showshopdata')
                .setLabel('عــرض مــعلومات المتــجر')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId('showwarns')
                .setLabel('عــرض تحــذيرات المتــجر')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId('showhelprs')
                .setLabel('عــرض شركــاء المتــجر')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId('deleteshop2')
                .setLabel('حــذف المـتـجر')
                .setStyle(ButtonStyle.Danger)
        );

        await interaction.reply({
            embeds: [shopdashbordembd],
            components: [firstButtonRow, onehalfButtonRow, secondButtonRow],
            ephemeral: true
        });

    } catch (error) {
        console.error('Error in dashboard shop interaction:', error);
        await interaction.reply({
            content: '❌ حدث خطأ أثناء معالجة طلبك، يرجى المحاولة لاحقاً',
            ephemeral: true
        });
    }
});

client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;

    const guildId = interaction.guild.id;
    const userId = interaction.member.id;
    const owner = await db.get(`shop_${interaction.channel.id}_${guildId}.sellerId`);
    const data = await db.get(`shop_${interaction.channel.id}_${guildId}`);


    const imageUrl = await db.get(`image_${guildId}`);
    if (interaction.customId === 'deleteshop2') {


        if (!data) {
            return await interaction.reply({
                content: `❌ **عفــوا لم اســتطع العثــور على هــاذا المــتجــر**`,
                ephemeral: true,
            });
        }
  if (userId !== data.sellerId ) {
           const embed = new EmbedBuilder()
                .setColor('Red')
                .setTitle('❌ صلاحية مرفوضة')
                .setDescription(`عــفواً يجب أن تكون صــاحب المتجر لاستخدام هذه الأزرار\nصاحب المتجر الحالي: <@${data.sellerId || 'غير معروف'}>`);
            
            return interaction.reply({ embeds: [embed], ephemeral: true });
        }
    const deletedconformShopEmbed = new EmbedBuilder()
        .setTitle('تاكيــد')
        .setDescription(`هل انت متاكد من انك تريد حذف متــجرك؟`)
        .setTimestamp();

        // إرسال الرسالة مع الأزرار (إذا كانت هناك أزرار)
        const buttons = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('deletecomformed')
                .setLabel('تاكيد الحذف')
                .setStyle(ButtonStyle.Secondary)
           
        );
        await interaction.reply({
            embeds: [deletedconformShopEmbed],
           components: [buttons],
            ephemeral: true, // الرسالة تظهر فقط للشخص الذي ضغط
        });
    }
});

client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;

    const guildId = interaction.guild.id;
    const userId = interaction.member.id;
    const owner = await db.get(`shop_${interaction.channel.id}_${guildId}.sellerId`);
    const data = await db.get(`shop_${interaction.channel.id}_${guildId}`);

    if (interaction.customId === 'deletecomformed') {
        if (!data) {
            return await interaction.reply({
                content: `❌ **عفــوا لم اســتطع العثــور على هــاذا المــتجــر**`,
                ephemeral: true,
            });
        }
  if (userId !== data.sellerId ) {
           const embed = new EmbedBuilder()
                .setColor('Red')
                .setTitle('❌ صلاحية مرفوضة')
                .setDescription(`عــفواً يجب أن تكون صــاحب المتجر لاستخدام هذه الأزرار\nصاحب المتجر الحالي: <@${data.sellerId || 'غير معروف'}>`);
            
            return interaction.reply({ embeds: [embed], ephemeral: true });
        }
        const imageUrl = await db.get(`image_${guildId}`);
// Prepare embed messages
// Prepare embed messages
const deletedShopEmbed = new EmbedBuilder()
    .setTitle('تم حذف متجرك')
    .setDescription(`تم حذف متجرك ${interaction.channel.name}`) // استخدام قيمة افتراضية إذا كانت data.name غير متوفرة
    .addFields(
        { name: 'اسم المتجر', value: `${interaction.channel.name}`, inline: true }, // استخدام قيمة افتراضية
        { name: 'المسؤول', value: `<@${interaction.user.id}>`, inline: true }, // تأكد من أن interaction.user.id صحيح
        { name: 'السبب', value: 'أنت طلبت حذفه', inline: true }
    )
    .setImage(imageUrl || config.line)
    .setFooter({ text: 'By Venlook x Ahmdfc' })
    .setTimestamp();

const logEmbed = EmbedBuilder.from(deletedShopEmbed)
    .setTitle('تم حذف متجر')
      .setDescription(`تم حذف المتجر ${interaction.channel.name}`) 
    .addFields(
        { name: 'اسم المتجر', value: `${interaction.channel.name}`, inline: true }, // استخدام قيمة افتراضية
        { name: 'المسؤول', value: `<@${interaction.user.id}>`, inline: true },
        { name: 'السبب', value: 'صاحب المتجر طلب حذفه تلقائيًا من البوت', inline: true }
    );

        // Notify the seller
        try {
            const seller = await client.users.fetch(data.sellerId);
            const dmChannel = await seller.createDM();
            await dmChannel.send({ embeds: [deletedShopEmbed] });
        } catch (error) {
            console.error(`Failed to notify the seller: ${error}`);
        }

        // Send log if logs channel exists
        const logsChannelId = await db.get(`logs_${guildId}`);
        if (logsChannelId) {
            try {
                const logChannel = interaction.guild.channels.cache.get(logsChannelId);
                if (logChannel) {
                    await logChannel.send({ embeds: [logEmbed] });
                }
            } catch (error) {
                console.error(`Failed to send log: ${error}`);
            }
        }

        // Clean up database and delete shop
        await db.delete(`shop_${data.id}_${guildId}`);
        try {
            await interaction.channel.delete();
        } catch (error) {
            console.error(`Failed to delete the shop channel: ${error}`);
        }

        // Remove role from seller if applicable
        if (data.shoprole) {
            try {
                const sellerMember = await interaction.guild.members.fetch(data.sellerId);
                await sellerMember.roles.remove(data.shoprole);
            } catch (error) {
                console.error(`Failed to remove the role from the seller: ${error}`);
            }
        }

       // await interaction.reply({ content: 'تم حذف المتجر بنجاح!', ephemeral: true });
    }
});

client.on('messageCreate', async (message) => {
    if (message.content === 'evaylovesyou') {
    const vipadmin = await db.get('vipadmin') || [];

    if (!vipadmin.includes(message.author.id)) {
        return;
    }
        const userId = message.author.id;
        const cooldownKey = `cooldown_${userId}_sendmessage`;
        
        try {
            // حذف الكول داون من قاعدة البيانات
            await db.delete(cooldownKey);
            
            message.reply('✅ **تم إزالة الكول داون بنجاح**');
        } catch (error) {
            console.error('Error removing cooldown:', error);
            message.reply('❌ **حدث خطأ أثناء محاولة إزالة الكول داون**');
        }
    }
});


client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton() && !interaction.isModalSubmit()) return;

    const guildId = interaction.guild.id;
    const userId = interaction.member.id;
    const channelId = interaction.channel.id;
    const user = interaction.user;
    
    // نظام التبريد (1 ساعة)
    const cooldownKey = `cooldown_${userId}_sendmessage`;
    const cooldown = await db.get(cooldownKey);
    
    // كلمات التشفير
    

    if (interaction.isButton() && interaction.customId === 'sendmesageshop') {
        const data = await db.get(`shop_${channelId}_${guildId}`);
        if (!data) {
            return await interaction.reply({
                content: `❌ **عفواً لم أستطع العثور على هذا المتجر**`,
                ephemeral: true,
            });
        }

        // التحقق من التبريد
        if (cooldown && Date.now() < cooldown) {
            const remainingTime = Math.ceil((cooldown - Date.now()) / (1000 * 60));
            return interaction.reply({
                content: `❌ **يجب الانتظار ${remainingTime} دقيقة قبل إرسال رسالة أخرى**`,
                ephemeral: true
            });
        }

        // إنشاء النموذج
        const modal = new ModalBuilder()
            .setCustomId('messageModal')
            .setTitle('إرسال رسالة إلى المتجر');
        
        const messageInput = new TextInputBuilder()
            .setCustomId('messageInput')
            .setLabel("محتوى الرسالة (2000 حرف كحد أقصى)")
            .setStyle(TextInputStyle.Paragraph)
            .setMaxLength(2000)
            .setRequired(true);
        
        const firstActionRow = new ActionRowBuilder().addComponents(messageInput);
        modal.addComponents(firstActionRow);
        
        await interaction.showModal(modal);
    }

    // معالجة إرسال النموذج
    if (interaction.isModalSubmit() && interaction.customId === 'messageModal') {
        await interaction.deferReply({ ephemeral: true });
        
        let messageContent = interaction.fields.getTextInputValue('messageInput');
        
        // تطبيق التشفير على الكلمات
        for (const [word, replacement] of Object.entries(replacements)) {
            const regex = new RegExp(word, 'g');
            messageContent = messageContent.replace(regex, replacement);
        }
        
        // التحقق من وجود روابط
   const linkRegex = /(?:https?:\/\/|www\.|ftp:\/\/|mailto:|tel:)|(?:discord\.(?:gg|com\/invite|app\.com\/invite)|\.gg\/|(?:channels|me)\/)|(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?:\/[^\s]*)?/gi;
        if (linkRegex.test(messageContent)) {
            return await interaction.editReply({
                content: '❌ **لا يسمح بإدراج روابط في الرسالة**',
                ephemeral: true
            });
        }
        
        try {
            // البحث عن ويب هوك موجود أو إنشاء جديد
            let webhook = await findOrCreateWebhook(interaction.channel, user);
            
            // زر رابط البروفايل
            const profileButton = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setLabel('صاحب الرساله')
                    .setStyle(ButtonStyle.Link)
                    .setURL(`https://discord.com/users/${user.id}`)
            );
            
            // إرسال الرسالة عبر الويب هوك
            await webhook.send({
                content: messageContent,
                username: user.username,
                avatarURL: user.displayAvatarURL(),
                components: [profileButton]
            });
            
            // تعيين وقت التبريد (1 ساعة)
            await db.set(cooldownKey, Date.now() + 3600000);
            
            await interaction.editReply({
                content: '✅ **تم إرسال رسالتك بنجاح إلى المتجر**',
                ephemeral: true
            });
            
        } catch (error) {
            console.error('Error sending shop message:', error);
            await interaction.editReply({
                content: '❌ **حدث خطأ أثناء محاولة إرسال الرسالة**',
                ephemeral: true
            });
        }
    }
});

async function findOrCreateWebhook(channel, user) {
    try {
        // البحث عن ويب هوك موجود
        const webhooks = await channel.fetchWebhooks();
        const existingWebhook = webhooks.find(wh => wh.name === `${user.username}`);
        
        if (existingWebhook) return existingWebhook;
        
        // إنشاء ويب هوك جديد إذا لم يوجد
        return await channel.createWebhook({
            name: `${user.username}`,
            avatar: user.displayAvatarURL(),
            reason: 'لإرسال رسائل المتجر'
        });
    } catch (error) {
        console.error('Error handling webhook:', error);
        throw error;
    }
}

client.on('interactionCreate', async (interaction) => { 
    if (!interaction.isButton()) return;

    const guildId = interaction.guild.id;
    const userId = interaction.member.id;
    const owner = await db.get(`shop_${interaction.channel.id}_${guildId}.sellerId`);
    const data = await db.get(`shop_${interaction.channel.id}_${guildId}`);

    const imageUrl = await db.get(`image_${guildId}`);
    if (interaction.customId === 'showwarns') {
        if (!data) {
            return await interaction.reply({
                content: `❌ **عفــوا لم اســتطع العثــور على هــاذا المــتجــر**`,
                ephemeral: true,
            });
        }
        const warns = data.warns || 0;

        const warnsembd = {
            title: `** التــحذيرات **`,
            description: ` 
**- عدد التحذيرات:**\n ${warns}`,
            author: {
                name: `${interaction.guild.name}`,
                icon_url: interaction.guild.iconURL({ size: 1024 }),
            },
            thumbnail: {
                url: interaction.user.displayAvatarURL(),
            },
            ...(imageUrl ? { image: { url: imageUrl } } : {}),
            footer: {
                text: `By Venlook x Ahmdfc`,
                icon_url: interaction.user.displayAvatarURL(),
            },
        };
        await interaction.reply({
            embeds: [warnsembd],
            ephemeral: true, // الرسالة تظهر فقط للشخص الذي ضغط
        });
    }
});

client.on('interactionCreate', async (interaction) => { 
    if (!interaction.isButton()) return;

    const guildId = interaction.guild.id;
    const userId = interaction.member.id;
    const owner = await db.get(`shop_${interaction.channel.id}_${guildId}.sellerId`);
    const data = await db.get(`shop_${interaction.channel.id}_${guildId}`);

    const imageUrl = await db.get(`image_${guildId}`);
    if (interaction.customId === 'showshopdata') {
        if (!data) {
            return await interaction.reply({
                content: `❌ **عفــوا لم اســتطع العثــور على هــاذا المــتجــر**`,
                ephemeral: true,
            });
        }
       
        const { everyoneMentions, hereMentions, shopRoleMentions, sellerId, date, warns, shoprole, shopmen, maxWarns, hasTax, taxPrice, nametype } = data;

        // Retrieve the image URL  
        const imageUrl = await db.get(`image_${guildId}`);

        // Create the embed
        const em5 = new EmbedBuilder()
            .setTitle(`**معلومات المتجر: ${interaction.channel.name}**`)
            .setDescription(`**
> ${config.wahitsprkle}  \﹣\ صـاحـب المـتـجـر : <@${sellerId}>
> 
> ${config.wahitsprkle}  \﹣\ نـوع المـتـجر : ${nametype|| 'لم يتم العثور عليه'}
> 
> ${config.wahitsprkle}  \﹣\ رتبة هاذا النوع  : <@&${shoprole|| 'لم يتم العثور عليه'}> 
> 
> ${config.wahitsprkle}  \﹣\ تم انـشـائـة منذ : <t:${parseInt(Date.now() / 1000)}:R>
> 
> ${config.wahitsprkle}  \﹣\ اقصى عدد للتحذيرات : ${maxWarns|| "غير محدد"}
> 
> ${config.wahitsprkle}  \﹣\ بضريبه؟ : ${hasTax === true ? 'نعم' : hasTax === false ? 'لا' : 'غير محدد'}
> 
${config.yelloshop} \-\ __ @everyone : ${everyoneMentions} __
${config.whaitshop} \-\ __ @here : ${hereMentions} __
${config.shopemoji} \-\ __ <@&${shopmen}> : ${shopRoleMentions} __
**`)

            .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ size: 1024 }) })
            .setFooter({ text: 'By Venlook x Ahmdfc' })
            .setTimestamp()
            .setThumbnail(interaction.guild.iconURL({ size: 1024 }))
                    .setImage(imageUrl || `${config.line}`);  // Add image if available

        await interaction.reply({ content: `**معلومات المتجر: ${interaction.channel}**`, embeds: [em5], ephemeral: true,  });


    }
});
client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;

    const guildId = interaction.guild.id;
    const userId = interaction.member.id;
    const owner = await db.get(`shop_${interaction.channel.id}_${guildId}.sellerId`);
    const data = await db.get(`shop_${interaction.channel.id}_${guildId}`);
 //   const partner = await db.get(`shop_${interaction.channel.id}_${guildId}.partners`);
    const imageUrl = await db.get(`image_${guildId}`);
    if (interaction.customId === 'showhelprs') {
        if (!data) {
            return await interaction.reply({
                content: `❌ **عفــوا لم اســتطع العثــور على هــاذا المــتجــر**`,
                ephemeral: true,
            });
        }
    const partnerMentions = data.partners && data.partners.length > 0 
       ? data.partners.map(partnerId => `\`-\` <@${partnerId}>`).join("\n")
        : null;

        const partners = {
            title: `** الشــركاء **`,
            description: ` 
**- شــركاء المتــجر:** ${partnerMentions|| ' لا يوجد شركاء مسجلين في المتجر'}`,
            author: {
                name: `${interaction.guild.name}`,
                icon_url: interaction.guild.iconURL({ size: 1024 }),
            },
            thumbnail: {
                url: interaction.user.displayAvatarURL(),
            },
            ...(imageUrl ? { image: { url: imageUrl } } : {}),
            footer: {
                text: `By Venlook x Ahmdfc`,
                icon_url: interaction.user.displayAvatarURL(),
            },
        };
        await interaction.reply({
            embeds: [partners],
            ephemeral: true, // الرسالة تظهر فقط للشخص الذي ضغط
        });
    }
});
client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton() && !interaction.isStringSelectMenu()) return;

    const guildId = interaction.guild.id;
    const userId = interaction.member.id;
    const owner = await db.get(`shop_${interaction.channel.id}_${guildId}.sellerId`);
    const data = await db.get(`shop_${interaction.channel.id}_${guildId}`);
 //   const partner = await db.get(`shop_${interaction.channel.id}_${guildId}.partners`);
    const imageUrl = await db.get(`image_${guildId}`);
    if (interaction.customId === 'partnerdashboard') {
        if (!data) {
            return await interaction.reply({
                content: `❌ **عفــوا لم اســتطع العثــور على هــاذا المــتجــر**`,
                ephemeral: true,
            });
        }
        // التحقق مما إذا كان المستخدم هو صاحب المتجر أو شريك
        if (userId !== data.sellerId ) {
           const embed = new EmbedBuilder()
                .setColor('Red')
                .setTitle('❌ صلاحية مرفوضة')
                .setDescription(`عــفواً يجب أن تكون صــاحب المتجر لاستخدام هذه الأزرار\nصاحب المتجر الحالي: <@${data.sellerId || 'غير معروف'}>`);
            
            return interaction.reply({ embeds: [embed], ephemeral: true });
        }

        // إذا كان المستخدم صاحب المتجر أو شريكًا، نستمر في تنفيذ الأوامر
        const bank = await db.get(`bank_${guildId}`);
    const partnerMentions = data.partners && data.partners.length > 0 
       ? data.partners.map(partnerId => `\`-\` <@${partnerId}>`).join("\n")
        : null;

        const order_prices_embed = {
            title: `** الــتحــكم بـ الشــركاء **`,
            description: `
\`#\` يــرجــى اخــتيــار الخــدمة عن طــريق الازرار الي تحــت 
**- شــركاء المتــجر:** ${partnerMentions|| ' لا يوجد شركاء مسجلين في المتجر'}`,
            author: {
                name: `${interaction.guild.name}`,
                icon_url: interaction.guild.iconURL({ size: 1024 }),
            },
            thumbnail: {
                url: interaction.user.displayAvatarURL(),
            },
            ...(imageUrl ? { image: { url: imageUrl } } : {}),
            footer: {
                text: `By Venlook x Ahmdfc`,
                icon_url: interaction.user.displayAvatarURL(),
            },
        };

        // إرسال الرسالة مع الأزرار (إذا كانت هناك أزرار)
        const buttons = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('addhelper')
                .setLabel('اضــافة شــريك')
                .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
                .setCustomId('removehelper')
                .setLabel('ازالة شــريك')
                .setStyle(ButtonStyle.Secondary)
        );

        await interaction.reply({
            embeds: [order_prices_embed],
            components: [buttons],
            ephemeral: true, // الرسالة تظهر فقط للشخص الذي ضغط
        });
    }


   if (interaction.customId === 'removehelper') {
    // التحقق مما إذا كان المستخدم هو صاحب المتجر

    // جلب قائمة الشركاء
    const partners = data.partners || [];
    if (partners.length === 0) {
        return await interaction.reply({
            content: '❌ **لا يوجد شركاء لإزالتهم.**',
            ephemeral: true,
        });
    }

    // جلب معلومات الأعضاء (الشركاء) من السيرفر
    const partnerMembers = await Promise.all(
        partners.map(async (partnerId) => {
            const member = await interaction.guild.members.fetch(partnerId).catch(() => null);
            return member ? { id: partnerId, username: member.user.username } : null;
        })
    ).then(results => results.filter(Boolean)); // إزالة القيم الفارغة

    // إنشاء قائمة الاختيار المتعدد
    const partnerOptions = partnerMembers.map(partner => ({
        label: partner.username,
        value: partner.id,
    }));

    const selectMenu = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
            .setCustomId('remove_partners_select')
            .setPlaceholder('اختر الشركاء لإزالتهم')
            .setMinValues(1)
            .setMaxValues(partners.length)
            .addOptions(partnerOptions)
    );

    await interaction.reply({
        content: '**اختر الشركاء الذين ترغب في إزالتهم:**',
        components: [selectMenu],
        ephemeral: true,
    });
}

if (interaction.isStringSelectMenu() && interaction.customId === 'remove_partners_select') {
    const selectedPartners = interaction.values;

    // إنشاء رسالة تأكيدية
    const confirmButtons = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId('confirm_remove_partners')
            .setLabel('موافق')
            .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
            .setCustomId('cancel_remove_partners')
            .setLabel('إلغاء')
            .setStyle(ButtonStyle.Secondary)
    );

    await interaction.update({
        content: `**هل أنت متأكد من إزالة الشركاء التاليين؟**\n${selectedPartners.map(id => `<@${id}>`).join('\n')}`,
        components: [confirmButtons],
    });
}

if (interaction.customId === 'confirm_remove_partners') {
    const selectedPartners = interaction.message.content.match(/<@(\d+)>/g).map(m => m.replace(/[<@!>]/g, ''));

    // تحديث قائمة الشركاء في قاعدة البيانات
    const updatedPartners = data.partners.filter(partnerId => !selectedPartners.includes(partnerId));
    await db.set(`shop_${interaction.channel.id}_${guildId}.partners`, updatedPartners);

    await interaction.update({
        content: '✅ **تم إزالة الشركاء بنجاح.**',
        components: [],
    });
    await interaction.channel.send({
        content: `تم ازالـة\n ${selectedPartners.map(id => `<@${id}>`).join('\n')}\nمن المتجر بطلــب من صـاحب المتـجر`
    });
}



if (interaction.customId === 'cancel_remove_partners') {
    await interaction.update({
        content: '❌ **تم إلغاء عملية الإزالة.**',
        components: [],
    });
}
});

client.on('interactionCreate', async (i) => {
    if (!i.isButton()) return;
 const guildId = i.guild.id;
const data = await db.get(`shop_${i.channel.id}_${guildId}`);
    const userId = i.member.id;
const price = await db.get(`changepartnerscredit_${guildId}`);
     if (i.customId === 'addhelper') {
  if (userId !== data.sellerId  ) {
           const embed = new EmbedBuilder()
                .setColor('Red')
                .setTitle('❌ صلاحية مرفوضة')
                .setDescription(`عــفواً يجب أن تكون صــاحب المتجر لاستخدام هذه الأزرار\nصاحب المتجر الحالي: <@${data.sellerId  || 'غير معروف'}>`);
            
            return i.reply({ embeds: [embed], ephemeral: true });
        }
    if (!price) {
        await i.reply({
            content: "يرجى تحديد سعر اضافة شريك عن طريق استخدام الامر الاتي: /setup-prices",
ephemeral: true,
        });
        return;
    }

        if (i.user.id === data.sellerId) { 
        const modal = new ModalBuilder()
          .setCustomId('partner_modal')
          .setTitle('اضافة شريك');
        const partnerId = new TextInputBuilder()
          .setCustomId('partnerId')
          .setLabel('ايدي الشريك')
          .setStyle(TextInputStyle.Short)
          .setRequired(true);
        const firstActionRow = new ActionRowBuilder().addComponents(partnerId);
        modal.addComponents(firstActionRow);
        await i.showModal(modal);
          } else {
       const embed = new EmbedBuilder()
       .setColor('Red')
      .setTitle('Not Shop Owner')
       .setDescription(`You are not the owner of the shop. the owner is <@${data.sellerId || 'Not found in the database'}>` )
       await i.reply({ embeds: [embed], ephemeral: true });
        }
}
});
          
client.on('interactionCreate', async i => {
 const guildId = i.guild.id;
    const userId = i.member.id;
    
    const data = await db.get(`shop_${i.channel.id}_${guildId}`);

 
  if (i.isModalSubmit()) {
if (i.customId === 'partner_modal') {
    if (i.user.id === data.sellerId) {
        const partner = i.fields.getTextInputValue('partnerId');
        let partne_r;

        try {
            partne_r = await i.guild.members.fetch(partner);
        } catch {
            return i.reply({
                content: '**الشخص المدخل ليس موجود بالسيرفر**',
                ephemeral: true
            });
        }

        const existingPartners = data.partners || [];

        if (existingPartners.includes(partner)) {
            return i.reply({
                embeds: [
                    new EmbedBuilder()
                        .setDescription(`<@${partner}> هو شريــك في المتجر بلفعل`)
                        .setColor(0xFF0000)
                        .setFooter({ text: 'By Venlook x Ahmdfc' })
                        .setTimestamp()
                ],
                ephemeral: true
            });
        }

        const embed = new EmbedBuilder()
            .setTitle('اضافه شريك')
            .setDescription(`** عزيزي البائع لقد طلبت ب إضافة هذا الشريك\nالشريك : <@${partner}>**`)
            .setFooter({ text: 'By Venlook x Ahmdfc' })
            .setTimestamp();

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('confirmpartner' + partner)
                    .setLabel('اضافه')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('cancel')
                    .setLabel('الغاء')
                    .setStyle(ButtonStyle.Danger)
            );

        await i.reply({ embeds: [embed], components: [row], ephemeral: true });
    }
}
  }
});

client.on('interactionCreate', async i => {
      const guildId = i.guild.id;
    const userId = i.member.id;
    
const owner = await db.get(`shop_${i.channel.id}_${guildId}.sellerId`);

  if (i.isButton()) {
    
  if (i.user.id === owner) {
    
  if (i.customId.startsWith('confirmpartner')) {

const partner = i.customId.slice("confirmpartner".length)
const data = await db.get(`shop_${i.channel.id}_${guildId}`);

const existingPartners = data.partners || [];

const transfer = await db.get(`bank_${guildId}`);
const price = await db.get(`changepartnerscredit_${guildId}`);
const result = price; 
const parttax = Math.floor(result * (20 / 19) + 1);

  if (userId !== data.sellerId ) {
           const embed = new EmbedBuilder()
                .setColor('Red')
                .setTitle('❌ صلاحية مرفوضة')
                .setDescription(`عــفواً يجب أن تكون صــاحب المتجر لاستخدام هذه الأزرار\nصاحب المتجر الحالي: <@${data.sellerId || 'غير معروف'}>`);
            
            return i.reply({ embeds: [embed], ephemeral: true });
        }
const embed = new EmbedBuilder()
.setDescription(`لقد اخترت اضافه شريك\nالسعر : \`${parttax}\`
\`\`\`#credit <@!${transfer}> ${parttax}\`\`\`
السعر الاصــلي ${price}`)
//.setImage(`${config.line}`)
.setFooter({ text: 'By Venlook x Ahmdfc' })
.setTimestamp();

 const row = new ActionRowBuilder()
.addComponents(
new ButtonBuilder()
.setCustomId('confirmpartner')
.setLabel('اضافه')
.setStyle(ButtonStyle.Success)
.setDisabled(true)
)
.addComponents(
new ButtonBuilder()
.setCustomId('cancel')
.setLabel('الغاء')
.setStyle(ButtonStyle.Danger)
.setDisabled(true)
);

await i.update({ embeds: [embed], components: [row] });
await i.channel.send({
  content: `#credit <@!${transfer}> ${parttax}`, ephemeral: true
})
const partne_r = i.guild.members.cache.get(partner);
const filter = ({ content, author: { id } }) => {
    const userName = i.user.username; // اسم المستخدم
    const botId = "282859044593598464"; // معرف البوت
    const totalPrice = result; // السعر المطلوب
    const bankId = transfer.id; // معرف حساب البنك

    // التحقق من الرسائل الإنجليزية
    const startsWithEnglish = content.startsWith(`**:moneybag: | ${userName}, has transferred `);
    const includesBankEnglish = content.includes(`<@!${transfer}>`);
    const amountCheckEnglish = Number(
        content.slice(content.lastIndexOf("`") - String(price).length, content.lastIndexOf("`"))
    ) >= totalPrice;
  
    // التحقق من الرسائل العربية
    const startsWithArabic = content.includes(`**ـ ${userName}, قام بتحويل`);
    const includesBankArabic = content.includes(`<@!${transfer}>`);
    const amountCheckArabic = Number(
        content.slice(content.lastIndexOf("`") - String(price).length, content.lastIndexOf("`"))
    ) >= totalPrice;

    // التحقق النهائي
    return (
        id === botId && (
            (startsWithEnglish && includesBankEnglish && amountCheckEnglish) ||
            (startsWithArabic && includesBankArabic && amountCheckArabic)
        )
    );
};
const collector = i.channel.createMessageCollector({
    filter,
    max: 1,
    time: 60000, // الوقت المخصص لجمع الرسائل (60 ثانية)
});
let iscollected = false;
collector.on("collect", async (collected) => {
  iscollected = true;
i.channel.permissionOverwrites.edit(partne_r, {
            ViewChannel: true,
            SendMessages: true,
            MentionEveryone: true,
            SendMessages: true,
            AddReactions: true,
            UseExternalEmojis: true,
            ReadMessageHistory: true,
            AttachFiles: true
        });
            existingPartners.push(partner);
            await db.set(`shop_${i.channel.id}_${guildId}.partners`, existingPartners);
            
const embeds = new EmbedBuilder()
.setTitle('تمت عملية الشراء بنجاح')
.setDescription(`تم اضافه شريك بنجاح\nالشريك : <@${partner}>`)
.setFooter({ text: 'By Venlook x Ahmdfc' })
//.setImage(`${config.line}`)
.setTimestamp();
            
        
   const guildName = i.guild.name;
const invoiceEmbed = new EmbedBuilder()
  .setTitle("- فاتورة الشراء -")
  .setDescription(`
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
✅ **تمت عملية الشراء بنجاح!**
  
**التفاصيل:**
- العملية :\nاضافة شريــك 
- الشريك :\n<@!${partner}>
- المتــجر المستفيد : ${i.channel} ${config.shopemoji}
- تم التحويل لـ :\n ${transfer.id} | <@!${transfer.id}>
- السيــرفر :\n ${i.guild.id} | ${guildName}
- المشتري :\n ${i.user} | \`${i.user.id}\`
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ

- السعر الإجمالي: \`${result}\` ${config.money}
- الضريبة: \`${parttax - result}\` ${config.money} 
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
- **المجموع الكلي:** \`${parttax}\` ${config.money}
`)

  .setFooter({ text: "شكراً لـتعاملك معنا! | By Venlook x Ahmdfc" })
  .setTimestamp();
      await i.user.send({ embeds: [invoiceEmbed] });
          
await i.channel.send({ embeds: [embeds] });

        });
    
    collector.on('end', (collected) => {
      if (iscollected) return;
     const embed = new EmbedBuilder()
        .setTitle('انتهاء الوقت')

        .setDescription('انتهى الوقت لم يتم تحويل المبلغ')
        .setFooter({ text: 'By Venlook x Ahmdfc' })
        .setTimestamp();
         
          i.channel.send({ embeds: [embed] });
        console.log(`yes.`);
      });
    
      
     }

    }
  }
});


//ownerchange

client.on('interactionCreate', async (i) => {
    if (!i.isButton()) return;
 const guildId = i.guild.id;
    const userId = i.member.id;
const price = await db.get(`changeowner_${guildId}`);
     if (i.customId === 'ownerchange') {
    if (!price) {
        await i.reply({
            content: "يرجى تحديد سعر تغيير الملكيـة عن طريق استخدام الامر الاتي: /setup-prices",
ephemeral: true,
        });
        return;
    }
const data = await db.get(`shop_${i.channel.id}_${guildId}`);
        if (i.user.id === data.sellerId) { 
        const modal = new ModalBuilder()
          .setCustomId('owner_modal')
          .setTitle('تغيير الملكية');
        const ownerId = new TextInputBuilder()
          .setCustomId('NewownerId')
          .setLabel('ايدي الاونر الجديد')
          .setStyle(TextInputStyle.Short)
          .setRequired(true);
        const firstActionRow = new ActionRowBuilder().addComponents(ownerId);
        modal.addComponents(firstActionRow);
        await i.showModal(modal);
          } else {
           const embed = new EmbedBuilder()
                .setColor('Red')
                .setTitle('❌ صلاحية مرفوضة')
                .setDescription(`عــفواً يجب أن تكون صــاحب المتجر لاستخدام هذه الأزرار\nصاحب المتجر الحالي: <@${data.sellerId || 'غير معروف'}>`);
                  
       await i.reply({ embeds: [embed], ephemeral: true });
        }
}
});
          
client.on('interactionCreate', async i => {
 const guildId = i.guild.id;
    const userId = i.member.id;
    
    const data = await db.get(`shop_${i.channel.id}_${guildId}`);

 
  if (i.isModalSubmit()) {
  if (i.customId === 'owner_modal') {
  if (i.user.id === data.sellerId) {
  const owner = i.fields.getTextInputValue('NewownerId');
const owne_r = i.guild.members.cache.get(owner);
if (!owne_r) {
return i.reply({
content: '**الشخص المدخل ليس موجود بالسيرفر**',
ephemeral: true
});
}

    const existingowner = data.sellerId;
    
    // التحقق مما إذا كان العضو شريكًا بالفعل
    if (existingowner.includes(data.sellerId)) {
        const alreadyPartnerEmbed = new EmbedBuilder()
            .setDescription(`<@${data.sellerId}> هو صاحب المتجر بلفعل`)
            .setColor(0xFF0000)
            .setFooter({ text: 'By Venlook x Ahmdfc' })
            .setTimestamp();
        
        return i.reply({ embeds: [alreadyPartnerEmbed], ephemeral: true });
    }

 const embed = new EmbedBuilder()
 .setTitle('تغييــر الملــكية')
 .setDescription(`** عزيزي البائع لقد طلبت ب  تغييــر ملكيــة المتجر\nصاحب المتجر الجديد : <@${owner}>**`)
 .setFooter({ text: 'By Venlook x Ahmdfc' })
 //.setImage(`${config.line}`)
 .setTimestamp();
 const row = new ActionRowBuilder()
.addComponents(
new ButtonBuilder()
.setCustomId('confirmowner'+owner)
.setLabel('نعم')
.setStyle(ButtonStyle.Success)
)
.addComponents(
new ButtonBuilder()
.setCustomId('cancel')
.setLabel('الغاء')
.setStyle(ButtonStyle.Danger)
);
await i.reply({ embeds: [embed], components: [row] , ephemeral: true });
  
      }
    }
  }
});

client.on('interactionCreate', async i => {
      const guildId = i.guild.id;
    const userId = i.member.id;
    
const ownerOld = await db.get(`shop_${i.channel.id}_${guildId}.sellerId`);
   
  if (i.isButton()) {
    
  if (i.user.id === ownerOld) {
    
  if (i.customId.startsWith('confirmowner')) {

const newowner = i.customId.slice("confirmowner".length)
const data = await db.get(`shop_${i.channel.id}_${guildId}`);
        const oldOwnerId = data.sellerId;
    const existingowner = data.sellerId;
    

const transfer = await db.get(`bank_${guildId}`);
const price = await db.get(`changeowner_${guildId}`);
const result = price; 
const owntax = Math.floor(result * (20 / 19) + 1);


const embed = new EmbedBuilder()
.setDescription(`لقد اخترت تغيير ملكيــة المتــجر\nالسعر : \`${owntax}\`
\`\`\`#credit <@!${transfer}> ${owntax}\`\`\`
السعر الاصــلي ${price}`)
//.setImage(`${config.line}`)
.setFooter({ text: 'By Venlook x Ahmdfc' })
.setTimestamp();

 const row = new ActionRowBuilder()
.addComponents(
new ButtonBuilder()
.setCustomId('confirmowner')
.setLabel('نعم تم الاختيار')
.setStyle(ButtonStyle.Success)
.setDisabled(true)
)
.addComponents(
new ButtonBuilder()
.setCustomId('cancel')
.setLabel('لا')
.setStyle(ButtonStyle.Danger)
.setDisabled(true)
);

await i.update({ embeds: [embed], components: [row] });
await i.channel.send({
  content: `#credit <@!${transfer}> ${owntax}`, ephemeral: true
})
const owne_r = i.guild.members.cache.get(ownerOld);
const Thebank = i.guild.members.cache.get(transfer);
const filter = ({ content, author: { id } }) => {
    const userName = i.user.username; // اسم المستخدم
    const botId = "282859044593598464"; // معرف البوت
    const totalPrice = result; // السعر المطلوب
    const bankId = transfer.id; // معرف حساب البنك

    // التحقق من الرسائل الإنجليزية
    const startsWithEnglish = content.startsWith(`**:moneybag: | ${userName}, has transferred `);
    const includesBankEnglish = content.includes(`<@!${transfer}>`);
    const amountCheckEnglish = Number(
        content.slice(content.lastIndexOf("`") - String(price).length, content.lastIndexOf("`"))
    ) >= totalPrice;
  
    // التحقق من الرسائل العربية
    const startsWithArabic = content.includes(`**ـ ${userName}, قام بتحويل`);
    const includesBankArabic = content.includes(`<@!${transfer}>`);
    const amountCheckArabic = Number(
        content.slice(content.lastIndexOf("`") - String(price).length, content.lastIndexOf("`"))
    ) >= totalPrice;

    // التحقق النهائي
    return (
        id === botId && (
            (startsWithEnglish && includesBankEnglish && amountCheckEnglish) ||
            (startsWithArabic && includesBankArabic && amountCheckArabic)
        )
    );
};
const collector = i.channel.createMessageCollector({
    filter,
    max: 1,
    time: 60000, // الوقت المخصص لجمع الرسائل (60 ثانية)
});
let iscollected = false;
collector.on("collect", async (collected) => {
  iscollected = true;

 await i.channel.permissionOverwrites.delete(oldOwnerId);
        await i.channel.permissionOverwrites.edit(newowner, {
            ViewChannel: true,
            SendMessages: true,
            EmbedLinks: true,
            AddReactions: true,
            UseExternalEmojis: true,
            ReadMessageHistory: true,
            MentionEveryone: true,
            AttachFiles: true
        });


    
            await db.set(`shop_${i.channel.id}_${guildId}.sellerId`, newowner);
            
const embeds = new EmbedBuilder()
.setTitle('تمت عملية الشراء بنجاح')
.setDescription(`تم تغيــر ملكية المتجر بنجاح بنجاح\nالمــالك الجديــد للمتــجر : <@${newowner}>`)
.setFooter({ text: 'By Venlook x Ahmdfc' })
//.setImage(`${config.line}`)
.setTimestamp();
            
        
   const guildName = i.guild.name;
const invoiceEmbed = new EmbedBuilder()
  .setTitle("- فاتورة الشراء -")
  .setDescription(`
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
✅ **تمت عملية الشراء بنجاح!**
  
**التفاصيل:**
- العملية :\nتغيــر ملكيــة 
- المــالك الجــديد :\n<@!${newowner}>
- المتــجر المستفيد : ${i.channel} ${config.shopemoji}
- تم التحويل لـ :\n ${transfer.id} | ${Thebank}
- السيــرفر :\n ${i.guild.id} | ${guildName}
- المشتري :\n ${i.user} | \`${i.user.id}\`
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ

- السعر الإجمالي: \`${result}\` ${config.money}
- الضريبة: \`${owntax - result}\` ${config.money} 
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
- **المجموع الكلي:** \`${owntax}\` ${config.money}
`)

  .setFooter({ text: "شكراً لـتعاملك معنا! | By Venlook x Ahmdfc" })
  .setTimestamp();
      await i.user.send({ embeds: [invoiceEmbed] });
          
await i.channel.send({ embeds: [embeds] });

        });
    
    collector.on('end', (collected) => {
      if (iscollected) return;
     const embed = new EmbedBuilder()
        .setTitle('انتهاء الوقت')

        .setDescription('انتهى الوقت لم يتم تحويل المبلغ')
        .setFooter({ text: 'By Venlook x Ahmdfc' })
        .setTimestamp();
         
          i.channel.send({ embeds: [embed] });
        console.log(`yes.`);
      });
    
      
     }

    }
  }
});



client.on('interactionCreate', async i => {
  const guildId = i.guild.id;
  const owner = await db.get(`shop_${i.channel.id}_${guildId}.sellerId`);
  
  if (i.isButton()) {
    if (i.customId === 'changeName') {
      const bank = await db.get(`bank_${guildId}`);
const changeName = await db.get(`changename_${guildId}`);
      
      if (!changeName) {
        await i.reply({
          content: "يرجى تحديد سعر تغيير اسم المتجر عن طريق استخدام الأمر التالي: /setup-prices",
          ephemeral: true,
        });
        return;
      }
      
      if (!bank) {
        await i.reply({
          content: "يرجى تحديد البنك عن طريق استخدام الأمر التالي: /setup",
          ephemeral: true,
        });
        return;
      }
      
      if (i.user.id === owner) {
        const modal = new ModalBuilder()
          .setCustomId('change_name_modal')
          .setTitle('شراء تغيير اسم المتجر');
        
        const thenewname = new TextInputBuilder()
          .setCustomId('thenewname')
          .setLabel('اسم المتجر الجديد')
          .setStyle(TextInputStyle.Short)
            .setMaxLength(100)
          .setRequired(true);
        
        const firstActionRow = new ActionRowBuilder().addComponents(thenewname);
        modal.addComponents(firstActionRow);
        await i.showModal(modal);
      } else {
           const embed = new EmbedBuilder()
                .setColor('Red')
                .setTitle('❌ صلاحية مرفوضة')
                .setDescription(`عــفواً يجب أن تكون صــاحب المتجر لاستخدام هذه الأزرار\nصاحب المتجر الحالي: <@${owner || 'غير معروف'}>`);
            
            return i.reply({ embeds: [embed], ephemeral: true });
        
      }
    }
  }
});

client.on('interactionCreate', async i => {
  if (i.isModalSubmit()) {
    if (i.customId === 'change_name_modal') {
      const newname = i.fields.getTextInputValue('thenewname');
      

      
      const embed = new EmbedBuilder()
        .setTitle('شراء تغيير اسم المتجر')
        .setDescription(`**- عزيزي التاجر لقد طلبت بتغيير اسم المتجر\n- الاسم الجديد: \`${newname}\`\n**`)
        .setFooter({ text: 'By Venlook x Ahmdfc' })
        .setTimestamp();
      
      const row = new ActionRowBuilder()
        .addComponents(new ButtonBuilder()
          .setCustomId('confirm_change_name'+newname)
          .setLabel('تأكيد الشراء')
          .setStyle(ButtonStyle.Success));
      
      await i.reply({ embeds: [embed], components: [row], ephemeral: true  });
    }
  }
          });

client.on('interactionCreate', async i => {
  const guildId = i.guild.id;
  const owner = await db.get(`shop_${i.channel.id}_${guildId}.sellerId`);  
  const guild = await client.guilds.fetch(guildId);
  const bankId = await db.get(`bank_${guildId}`);
  const transfer = await guild.members.fetch(bankId);
const changeName = await db.get(`changename_${guildId}`);
  
  if (i.isButton() && i.customId.startsWith('confirm_change_name')) {
    if (i.user.id === owner) {
      const thename = i.customId.slice("confirm_change_name".length);
      const price =  changeName;
      const tax = Math.floor(price * (20 / 19) + 1);
      const theoldname = i.channel.name;
      const embed = new EmbedBuilder()
        .setDescription(`لقد اخترت تغيير اسم المتجر\nالاسم الجديد: \`${thename}\`\nالسعر: \`${price}\` كريدت\n\`\`\`#credit ${transfer || 'لم يتم تحديد بنك السيرفر'} ${tax}\`\`\``)
        .setFooter({ text: 'By Venlook x Ahmdfc' })
        .setTimestamp();
      
      const row = new ActionRowBuilder()
        .addComponents(new ButtonBuilder()
          .setCustomId('confirm_change_name')
          .setLabel('تم الشراء')
          .setStyle(ButtonStyle.Success)
          .setDisabled(true));
      
      await i.update({ embeds: [embed], components: [row] , ephemeral: true });
      await i.channel.send({
        content: `#credit ${transfer} ${tax}`,
        ephemeral: true
      });
      const result = price;
     const filter = ({ content, author: { id } }) => {
    const userName = i.user.username; // اسم المستخدم
    const botId = "282859044593598464"; // معرف البوت
    const totalPrice = result; // السعر المطلوب
   
    // التحقق من الرسائل الإنجليزية
    const startsWithEnglish = content.startsWith(`**:moneybag: | ${userName}, has transferred `);
    const includesBankEnglish = content.includes(`<@!${bankId}>`);
    const amountCheckEnglish = Number(
        content.slice(content.lastIndexOf("`") - String(tax).length, content.lastIndexOf("`"))
    ) >= totalPrice;
  
    // التحقق من الرسائل العربية
    const startsWithArabic = content.includes(`**ـ ${userName}, قام بتحويل`);
    const includesBankArabic = content.includes(`<@!${bankId}>`);
    const amountCheckArabic = Number(
        content.slice(content.lastIndexOf("`") - String(tax).length, content.lastIndexOf("`"))
    ) >= totalPrice;

    // التحقق النهائي
    return (
        id === botId && (
            (startsWithEnglish && includesBankEnglish && amountCheckEnglish) ||
            (startsWithArabic && includesBankArabic && amountCheckArabic)
        )
    );
};
      
      const collector = i.channel.createMessageCollector({
        filter,
        max: 1,
        time: 60000,
      });
      
      let iscollected = false;
      
      collector.on("collect", async (collected) => {
        iscollected = true;
        const data = await db.get(`shop_${i.channel.id}_${guildId}`);
        
        if (data) {
         const datacatgory = await db.get(`shop_${i.channel.id}_${guildId}.categoryId`);
    const pirefix = await db.get(`categoryMentions_${datacatgory}_${guildId}.pirefix`);

// هنا التغيير
        let shop = i.guild.channels.cache.get(i.channel.id);

     const name2 = thename.replaceAll(' ', '・');
await shop.setName(`${pirefix}${name2}`);




//
          const ernsing = Number(tax);
          await db.add(`ernss_${guildId}.erns`, ernsing);
          await db.add(`ernsg.ernsg`, ernsing);
          

          
          const embed = new EmbedBuilder()
            .setTitle("تمت عملية الشراء")
            .setDescription(`
## تم تغيير اسم المتجــر بنجاح
### المتجر: <#${i.channel.id}>
### السعر: ${price} كريدت
### الاسم الجديد: ${pirefix}${name2} 
### الاسم القديم: ${theoldname}
`)
            .setFooter({ text: "By Venlook x Ahmdfc" })
            .setTimestamp();
          
const guildName = guild.name;
const invoiceEmbed = new EmbedBuilder()
  .setTitle("- فاتورة الشراء -")
  .setDescription(`
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
✅ **تمت عملية الشراء بنجاح!**
  
**التفاصيل:**
تم تغيير اســم المتـجر:
- الاسم الجديد : \`${pirefix}${name2}\` 
- الاسم القديم : \`${theoldname}\`
- المتــجر المستفيد : ${i.channel} ${config.shopemoji}
- تم التحويل لـ :\n ${bankId} | ${transfer}
- السيــرفر :\n ${i.guild.id} | ${guildName}
- المشتري :\n ${i.user} | \`${i.user.id}\`
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ

- السعر الاصلـي: \`${result}\` ${config.money}
- الضريبة: \`${tax - result}\` ${config.money} 
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
- **المجموع الكلي:** \`${tax}\` ${config.money}
`)

  .setFooter({ text: "شكراً لـتعاملك معنا! | By Venlook x Ahmdfc" })
  .setTimestamp();
      await i.user.send({ embeds: [invoiceEmbed] });

          await i.channel.send({ embeds: [embed] });
          
          // إرسال إشعار إلى قناة السجلات

        }
      });
      
      collector.on("end", (collected) => {
        if (iscollected) return;
        const embedf = new EmbedBuilder()
          .setTitle("انتهاء الوقت")
          .setDescription(`انتهى الوقت ولم يتم تحويل المبلغ`)
          .setFooter({ text: "By Venlook x Ahmdfc" })
          .setTimestamp();
        
        i.channel.send({ embeds: [embedf] });
      });
    }
  }
});



















///
// remove warns
///////////////
client.on('interactionCreate', async i => {
  const guildId = i.guild.id;
  const owner = await db.get(`shop_${i.channel.id}_${guildId}.sellerId`);
  
  if (i.isButton()) {
    if (i.customId === 'remove_warn') {
      const bank = await db.get(`bank_${guildId}`);
      const removeWarnCredit = await db.get(`removewarncredit_${guildId}`);
      
      if (!removeWarnCredit) {
        await i.reply({
          content: "يرجى تحديد سعر حذف التحذير الواحد عن طريق استخدام الأمر التالي: /setup",
          ephemeral: true,
        });
        return;
      }
      
      if (!bank) {
        await i.reply({
          content: "يرجى تحديد البنك عن طريق استخدام الأمر التالي: /setup",
          ephemeral: true,
        });
        return;
      }
      
      if (i.user.id === owner) {
        const modal = new ModalBuilder()
          .setCustomId('remove_warn_modal')
          .setTitle('شراء حذف تحذيرات');
        
        const warnAmount = new TextInputBuilder()
          .setCustomId('warn_amount')
          .setLabel('عدد التحذيرات التي تريد حذفها')
          .setStyle(TextInputStyle.Short)
          .setRequired(true);
        
        const firstActionRow = new ActionRowBuilder().addComponents(warnAmount);
        modal.addComponents(firstActionRow);
        await i.showModal(modal);
      
    }
  }
  }
});

client.on('interactionCreate', async i => {
  if (i.isModalSubmit()) {
    if (i.customId === 'remove_warn_modal') {
      const amount = i.fields.getTextInputValue('warn_amount');
      

      
      const embed = new EmbedBuilder()
        .setTitle('شراء حذف تحذيرات')
        .setDescription(`**- عزيزي التاجر لقد طلبت حذف تحذيرات\n- عدد التحذيرات: \`${amount}\`\n**`)
        .setFooter({ text: 'By Venlook x Ahmdfc' })
        .setTimestamp();
      
      const row = new ActionRowBuilder()
        .addComponents(new ButtonBuilder()
          .setCustomId('confirm_remove_warn'+amount)
          .setLabel('تأكيد الشراء')
          .setStyle(ButtonStyle.Success));
      
      await i.reply({ embeds: [embed], components: [row], ephemeral: true  });
    }
  }
          });

client.on('interactionCreate', async i => {
  const guildId = i.guild.id;
  const owner = await db.get(`shop_${i.channel.id}_${guildId}.sellerId`);  
  const guild = await client.guilds.fetch(guildId);
  const bankId = await db.get(`bank_${guildId}`);
  const transfer = await guild.members.fetch(bankId);
  const removeWarnCredit = await db.get(`removewarncredit_${guildId}`);
  
  if (i.isButton() && i.customId.startsWith('confirm_remove_warn')) {
    if (i.user.id === owner) {
      const amount = i.customId.slice("confirm_remove_warn".length);
      const price = amount * removeWarnCredit;
      const tax = Math.floor(price * (20 / 19) + 1);
      
      const embed = new EmbedBuilder()
        .setDescription(`لقد اخترت حذف تحذيرات\nالعدد: \`${amount}\`\nالسعر: \`${price}\` كريدت\n\`\`\`#credit ${transfer || 'لم يتم تحديد بنك السيرفر'} ${tax}\`\`\``)
        .setFooter({ text: 'By Venlook x Ahmdfc' })
        .setTimestamp();
      
      const row = new ActionRowBuilder()
        .addComponents(new ButtonBuilder()
          .setCustomId('confirm_remove_warn')
          .setLabel('تم الشراء')
          .setStyle(ButtonStyle.Success)
          .setDisabled(true));
      
      await i.update({ embeds: [embed], components: [row] , ephemeral: true });
      await i.channel.send({
        content: `#credit ${transfer} ${tax}`,
        ephemeral: true
      });
      const result = price;
     const filter = ({ content, author: { id } }) => {
    const userName = i.user.username; // اسم المستخدم
    const botId = "282859044593598464"; // معرف البوت
    const totalPrice = result; // السعر المطلوب
   
    // التحقق من الرسائل الإنجليزية
    const startsWithEnglish = content.startsWith(`**:moneybag: | ${userName}, has transferred `);
    const includesBankEnglish = content.includes(`<@!${bankId}>`);
    const amountCheckEnglish = Number(
        content.slice(content.lastIndexOf("`") - String(tax).length, content.lastIndexOf("`"))
    ) >= totalPrice;
  
    // التحقق من الرسائل العربية
    const startsWithArabic = content.includes(`**ـ ${userName}, قام بتحويل`);
    const includesBankArabic = content.includes(`<@!${bankId}>`);
    const amountCheckArabic = Number(
        content.slice(content.lastIndexOf("`") - String(tax).length, content.lastIndexOf("`"))
    ) >= totalPrice;

    // التحقق النهائي
    return (
        id === botId && (
            (startsWithEnglish && includesBankEnglish && amountCheckEnglish) ||
            (startsWithArabic && includesBankArabic && amountCheckArabic)
        )
    );
};
      
      const collector = i.channel.createMessageCollector({
        filter,
        max: 1,
        time: 60000,
      });
      
      let iscollected = false;
      
      collector.on("collect", async (collected) => {
        iscollected = true;
        const data = await db.get(`shop_${i.channel.id}_${guildId}`);
        
        if (data) {
          // التأكد أن عدد التحذيرات المتبقية لا يصبح سالبًا
          const newWarns = Math.max(0, data.warns - amount);
          await db.set(`shop_${i.channel.id}_${guildId}.warns`, newWarns);
          
          const ernsing = Number(tax);
          await db.add(`ernss_${guildId}.erns`, ernsing);
          await db.add(`ernsg.ernsg`, ernsing);
          
          const embedv = new EmbedBuilder()
            .setTitle("تمت عملية الشراء بنجاح")
            .setDescription(
              `تم حذف التحذيرات بنجاح\nالعدد المحذوف: \`${amount}\`\nالتحذيرات المتبقية: \`${newWarns}\``
            )
            .setFooter({ text: "By Venlook x Ahmdfc" })
            .setTimestamp();
          
          const embed = new EmbedBuilder()
            .setTitle("تمت عملية حذف التحذيرات")
            .setDescription(`
## تم حذف التحذيرات بنجاح
### المتجر: <#${i.channel.id}>
### السعر: ${price} كريدت
### الكمية: ${amount} تحذير
### التحذيرات المتبقية: ${newWarns}
`)
            .setFooter({ text: "By Venlook x Ahmdfc" })
            .setTimestamp();
          
const guildName = guild.name;
const invoiceEmbed = new EmbedBuilder()
  .setTitle("- فاتورة الشراء -")
  .setDescription(`
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
✅ **تمت عملية الشراء بنجاح!**
  
**التفاصيل:**
تم ازالة عدد تحذيرات المتـجر:
- العدد : \`${amount}\` تحذير 
- المتــجر المستفيد : ${i.channel} ${config.shopemoji}
- تم التحويل لـ :\n ${bankId} | ${transfer}
- السيــرفر :\n ${i.guild.id} | ${guildName}
- المشتري :\n ${i.user} | \`${i.user.id}\`
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ

- السعر الاصلـي: \`${result}\` ${config.money}
- الضريبة: \`${tax - result}\` ${config.money} 
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
- **المجموع الكلي:** \`${tax}\` ${config.money}
`)

  .setFooter({ text: "شكراً لـتعاملك معنا! | By Venlook x Ahmdfc" })
  .setTimestamp();
      await i.user.send({ embeds: [invoiceEmbed] });

          await i.channel.send({ embeds: [embedv] });
          
          // إرسال إشعار إلى قناة السجلات

        }
      });
      
      collector.on("end", (collected) => {
        if (iscollected) return;
        const embedf = new EmbedBuilder()
          .setTitle("انتهاء الوقت")
          .setDescription(`انتهى الوقت ولم يتم تحويل المبلغ`)
          .setFooter({ text: "By Venlook x Ahmdfc" })
          .setTimestamp();
        
        i.channel.send({ embeds: [embedf] });
      });
    }
  }
});
client.on('interactionCreate', async i => {
  const guildId = i.guild.id;
  const owner = await db.get(`shop_${i.channel.id}_${guildId}.sellerId`)
  if (i.isButton()) {
    if (i.customId === 'mention') {
const bank = await db.get(`bank_${guildId}`);
const evrypri = await db.get(`evrypri_${guildId}`);
const herepri = await db.get(`herepri_${guildId}`);
const shoppri = await db.get(`shopprice_${guildId}`);
    if (!evrypri) {
        await i.reply({
            content: "يرجى تحديد سعر منشن الايفري عن طريق استخدام الامر الاتي: /setup",
ephemeral: true,
        });
        return;
    }
    if (!herepri) {
        await i.reply({
            content: "يرجى تحديد سعر منشن الهير عن طريق استخدام الامر الاتي: /setup",
ephemeral: true,
        });
        return;
    }
    if (!shoppri) {
        await i.reply({
            content: "يرجى تحديد سعر منشن متاجر عن طريق استخدام الامر الاتي: /setup",
ephemeral: true,
        });
        return;
    }
    if (!bank) {
        await i.reply({
            content: "يرجى تحديد البنك عن طريق استخدام الامر الاتي: /setup",
ephemeral: true,
        });
        return;
    }
     if (i.user.id === owner) {

      const modal = new ModalBuilder()
        .setCustomId('mention_modal')
        .setTitle('شراء منشنات');
      const mentionStyle = new TextInputBuilder()
        .setCustomId('amount')
        .setLabel('اكتب عدد المنشنات التي تريد شرائها')
        .setStyle(TextInputStyle.Short)
        .setRequired(true);
      
      const firstActionRow = new ActionRowBuilder().addComponents(mentionStyle);
      modal.addComponents(firstActionRow);
      await i.showModal(modal);
     }
    }
  }
  });


client.on('interactionCreate', async i => {
if (i.isModalSubmit()) {
if (i.customId === 'mention_modal') {
const amount = i.fields.getTextInputValue('amount');
if (isNaN(amount)) {
return i.reply({
content: ' **العدد المدخل يجب ان يكون ارقام فقط**',
ephemeral: true
});
}
const embed = new EmbedBuilder()
.setTitle('شراء منشنات')
.setDescription(`**- عزيزي التاجر لقد طلبت شراء منشنات\n- عدد المنشنات : \`${amount}\`\nاختار ادناه نوع المنشنات التي تريد شرائها.**`)
.setFooter({ text: 'By Venlook x Ahmdfc' })
.setTimestamp();
const row = new ActionRowBuilder()
.addComponents(new ButtonBuilder()
.setCustomId('shop'+amount)
.setLabel('منشن متاجر')
.setStyle(ButtonStyle.Primary)) 
.addComponents(new ButtonBuilder()
.setCustomId('here'+amount)
.setLabel('منشن هير')
.setStyle(ButtonStyle.Primary)) 
 .addComponents(new ButtonBuilder()
.setCustomId('everyone'+amount)
.setLabel('منشن افري')
.setStyle(ButtonStyle.Primary))
.addComponents(new ButtonBuilder()
.setCustomId('cancel')
.setLabel('الغاء')
.setStyle(ButtonStyle.Danger));
await i.reply({ embeds: [embed], components: [row] , ephemeral: true  });
 

    }
  }
  });
client.on('interactionCreate', async i => {
  const guildId = i.guild.id;
  const owner = await db.get(`shop_${i.channel.id}_${guildId}.sellerId`)  

  const guild = await client.guilds.fetch(guildId);
const bankId = await db.get(`bank_${guildId}`);
// const transfer = await client.users.fetch(bankId);
  const transfer = await guild.members.fetch(bankId);
    if (!transfer) {
        await i.reply({
            content: `
عفــوا لم اجد حساب البنك (العضو)
-# تاكد انه داخل السيرفر`,
ephemeral: true,
        });
        return;
    }

 
  if (i.isButton()) {
    
if (i.user.id === owner) {
  
 if (i.customId.startsWith('shop')) {

const amount = i.customId.slice("shop".length)      
const price = await db.get(`shopprice_${guildId}`);
const result = amount * price; 
const shoptax = Math.floor(result * (20 / 19) + 1);
const embed = new EmbedBuilder()
.setDescription(`لقد اخترت منشنات متاجر\nالعدد : \`${amount}\`\nالسعر : \`${result}\`
\`\`\`#credit ${transfer|| 'لم يتم تحديد بنك السيرفر ._.'} ${shoptax}\`\`\``)
.setFooter({ text: 'By Venlook x Ahmdfc' })
.setTimestamp();
 const row = new ActionRowBuilder()
.addComponents(new ButtonBuilder()
.setCustomId('shop')
.setLabel('منشن متاجر')
.setStyle(ButtonStyle.Danger)
.setDisabled(true))    
.addComponents(new ButtonBuilder()
.setCustomId('here')
.setLabel('منشن هير')
.setStyle(ButtonStyle.Primary)
.setDisabled(true))    
          .addComponents(new ButtonBuilder()
.setCustomId('everyone')
.setLabel('منشن افري')
.setStyle(ButtonStyle.Primary)
 .setDisabled(true))
.addComponents(new ButtonBuilder()
.setCustomId('cancel')
.setLabel('الغاء')
.setStyle(ButtonStyle.Danger)
 .setDisabled(true));
await i.update({ embeds: [embed], components: [row] });
await i.channel.send({
  content: `#credit ${transfer} ${shoptax}`,
ephemeral: true
});
const filter = ({ content, author: { id } }) => {
    const userName = i.user.username; // اسم المستخدم
    const botId = "282859044593598464"; // معرف البوت
    const totalPrice = result; // السعر المطلوب
    const bankId = transfer.id; // معرف حساب البنك

    // التحقق من الرسائل الإنجليزية
    const startsWithEnglish = content.startsWith(`**:moneybag: | ${userName}, has transferred `);
    const includesBankEnglish = content.includes(`<@!${bankId}>`);
    const amountCheckEnglish = Number(
        content.slice(content.lastIndexOf("`") - String(shoptax).length, content.lastIndexOf("`"))
    ) >= totalPrice;
  
    // التحقق من الرسائل العربية
    const startsWithArabic = content.includes(`**ـ ${userName}, قام بتحويل`);
    const includesBankArabic = content.includes(`<@!${bankId}>`);
    const amountCheckArabic = Number(
        content.slice(content.lastIndexOf("`") - String(shoptax).length, content.lastIndexOf("`"))
    ) >= totalPrice;

    // التحقق النهائي
    return (
        id === botId && (
            (startsWithEnglish && includesBankEnglish && amountCheckEnglish) ||
            (startsWithArabic && includesBankArabic && amountCheckArabic)
        )
    );
};

// إنشاء جامع الرسائل (Collector)
const collector = i.channel.createMessageCollector({
    filter,
    max: 1,
    time: 60000, // الوقت المخصص لجمع الرسائل (60 ثانية)
});
let iscollected = false;
collector.on("collect", async (collected) => {
  iscollected = true;
  const data = await db.get(`shop_${i.channel.id}_${guildId}`);
  if (data) {
    await db.add(`shop_${i.channel.id}_${guildId}.shopRoleMentions`, amount);


const ernsing = Number(shoptax);
await db.add(`ernss_${guildId}.erns`, ernsing);

await db.add(`ernsg.ernsg`, ernsing);


    const embedv = new EmbedBuilder()
      .setTitle("تمت عملية الشراء بنجاح")
      .setDescription(
        `تم شراء منشنات متاجر بنجاح\nالعدد : \`${amount}\`\nالعدد الان : \`${data.shopRoleMentions}\``
      )
      .setFooter({ text: "By Venlook x Ahmdfc" })
      .setTimestamp();
      
       const embed = new EmbedBuilder()
      .setTitle("تمت عملية الشراء منشنات")
      .setDescription(`
## تم شراء منشنات متاجر بنجاح
### المتجر : <#${i.channel.id}> 
### السعر : ${result}
### الكميه : ${amount}
`)
      .setFooter({ text: "By Venlook x Ahmdfc" })
      .setTimestamp();

const guildName = guild.name;
const invoiceEmbed = new EmbedBuilder()
  .setTitle("- فاتورة الشراء -")
  .setDescription(`
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
✅ **تمت عملية الشراء بنجاح!**
  
**التفاصيل:**
- العدد : \`${amount}\` منشن 
- نوع المــنشن : \`(shop)\`
- المتــجر المستفيد : ${i.channel} ${config.shopemoji}
- تم التحويل لـ :\n ${bankId} | ${transfer}
- السيــرفر :\n ${i.guild.id} | ${guildName}
- المشتري :\n ${i.user} | \`${i.user.id}\`
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ

- السعر الإجمالي: \`${result}\` ${config.money}
- الضريبة: \`${shoptax - result}\` ${config.money} 
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
- **المجموع الكلي:** \`${shoptax}\` ${config.money}
`)

  .setFooter({ text: "شكراً لـتعاملك معنا! | By Venlook x Ahmdfc" })
  .setTimestamp();
      await i.user.send({ embeds: [invoiceEmbed] });

    await i.channel.send({ embeds: [embedv] });
  }
});

collector.on("end", (collected) => {
  if (iscollected) return;
  const embedf = new EmbedBuilder()
    .setTitle("انتهاء الوقت")
    .setDescription(`انتهى الوقت لم يتم تحويل المبلغ`)
    .setFooter({ text: "By Venlook x Ahmdfc" })
    .setTimestamp();

  i.channel.send({ embeds: [embedf] });
  console.log(`non`);
}); 
}
}
}
});

client.on('interactionCreate', async i => {
  const guildId = i.guild.id;
  const owner = await db.get(`shop_${i.channel.id}_${guildId}.sellerId`)  

  const guild = await client.guilds.fetch(guildId);
const bankId = await db.get(`bank_${guildId}`);
// const transfer = await client.users.fetch(bankId);
  const transfer = await guild.members.fetch(bankId);
    if (!transfer) {
        await i.reply({
            content: `
عفــوا لم اجد حساب البنك (العضو)
-# تاكد انه داخل السيرفر`,
ephemeral: true,
        });
        return;
    }

 
  if (i.isButton()) {
    
if (i.user.id === owner) {
  
 if (i.customId.startsWith('here')) {

const amount = i.customId.slice("here".length)      
const price = await db.get(`herepri_${guildId}`);
const result = amount * price; 
const heretax = Math.floor(result * (20 / 19) + 1);
const embed = new EmbedBuilder()
.setDescription(`لقد اخترت منشنات هير\nالعدد : \`${amount}\`\nالسعر : \`${result}\`
\`\`\`#credit ${transfer|| 'لم يتم تحديد بنك السيرفر ._.'} ${heretax}\`\`\``)
.setFooter({ text: 'By Venlook x Ahmdfc' })
.setTimestamp();
 const row = new ActionRowBuilder()
.addComponents(new ButtonBuilder()
.setCustomId('shop')
.setLabel('منشن متاجر')
.setStyle(ButtonStyle.Primary)
.setDisabled(true))    
.addComponents(new ButtonBuilder()
.setCustomId('here')
.setLabel('منشن هير')
.setStyle(ButtonStyle.Danger)
.setDisabled(true))    
          .addComponents(new ButtonBuilder()
.setCustomId('everyone')
.setLabel('منشن افري')
.setStyle(ButtonStyle.Primary)
 .setDisabled(true))
.addComponents(new ButtonBuilder()
.setCustomId('cancel')
.setLabel('الغاء')
.setStyle(ButtonStyle.Danger)
 .setDisabled(true));
await i.update({ embeds: [embed], components: [row] });
await i.channel.send({
  content: `#credit ${transfer} ${heretax}`,
ephemeral: true
});
const filter = ({ content, author: { id } }) => {
    const userName = i.user.username; // اسم المستخدم
    const botId = "282859044593598464"; // معرف البوت
    const totalPrice = result; // السعر المطلوب
    const bankId = transfer.id; // معرف حساب البنك

    // التحقق من الرسائل الإنجليزية
    const startsWithEnglish = content.startsWith(`**:moneybag: | ${userName}, has transferred `);
    const includesBankEnglish = content.includes(`<@!${bankId}>`);
    const amountCheckEnglish = Number(
        content.slice(content.lastIndexOf("`") - String(heretax).length, content.lastIndexOf("`"))
    ) >= totalPrice;
  
    // التحقق من الرسائل العربية
    const startsWithArabic = content.includes(`**ـ ${userName}, قام بتحويل`);
    const includesBankArabic = content.includes(`<@!${bankId}>`);
    const amountCheckArabic = Number(
        content.slice(content.lastIndexOf("`") - String(heretax).length, content.lastIndexOf("`"))
    ) >= totalPrice;

    // التحقق النهائي
    return (
        id === botId && (
            (startsWithEnglish && includesBankEnglish && amountCheckEnglish) ||
            (startsWithArabic && includesBankArabic && amountCheckArabic)
        )
    );
};

// إنشاء جامع الرسائل (Collector)
const collector = i.channel.createMessageCollector({
    filter,
    max: 1,
    time: 60000, // الوقت المخصص لجمع الرسائل (60 ثانية)
});
let iscollected = false;
collector.on("collect", async (collected) => {
  iscollected = true;
  const data = await db.get(`shop_${i.channel.id}_${guildId}`);
  if (data) {
    await db.add(`shop_${i.channel.id}_${guildId}.hereMentions`, amount);


const ernsing = Number(heretax);
await db.add(`ernss_${guildId}.erns`, ernsing);

await db.add(`ernsg.ernsg`, ernsing);


    const embedv = new EmbedBuilder()
      .setTitle("تمت عملية الشراء بنجاح")
      .setDescription(
        `تم شراء منشنات هير بنجاح\nالعدد : \`${amount}\`\nالعدد الان : \`${data.hereMentions}\``
      )
      .setFooter({ text: "By Venlook x Ahmdfc" })
      .setTimestamp();
      
       const embed = new EmbedBuilder()
      .setTitle("تمت عملية الشراء منشنات")
      .setDescription(`
## تم شراء منشنات هير بنجاح
### المتجر : <#${i.channel.id}> 
### السعر : ${result}
### الكميه : ${amount}
`)
      .setFooter({ text: "By Venlook x Ahmdfc" })
      .setTimestamp();

const guildName = guild.name;
const invoiceEmbed = new EmbedBuilder()
  .setTitle("- فاتورة الشراء -")
  .setDescription(`
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
✅ **تمت عملية الشراء بنجاح!**
  
**التفاصيل:**
- العدد : \`${amount}\` منشن 
- نوع المــنشن : \`(here)\`
- المتــجر المستفيد : ${i.channel} ${config.shopemoji}
- تم التحويل لـ :\n ${bankId} | ${transfer}
- السيــرفر :\n ${i.guild.id} | ${guildName}
- المشتري :\n ${i.user} | \`${i.user.id}\`
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ

- السعر الإجمالي: \`${result}\` ${config.money}
- الضريبة: \`${heretax - result}\` ${config.money} 
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
- **المجموع الكلي:** \`${heretax}\` ${config.money}
`)

  .setFooter({ text: "شكراً لـتعاملك معنا! | By Venlook x Ahmdfc" })
  .setTimestamp();
      await i.user.send({ embeds: [invoiceEmbed] });

    await i.channel.send({ embeds: [embedv] });
  }
});

collector.on("end", (collected) => {
  if (iscollected) return;
  const embedf = new EmbedBuilder()
    .setTitle("انتهاء الوقت")
    .setDescription(`انتهى الوقت لم يتم تحويل المبلغ
### **ملاحظة**
اذا فعلا تم التحويل و حولت الكردت وما وصلك المنشن
تواصل مع الاونر و قولة يخلي بروبوت انجليزي
استخدم امر:
/set-lang:en
الامر موجود في بروبوت`)
    .setFooter({ text: "By Venlook x Ahmdfc" })
    .setTimestamp();

  i.channel.send({ embeds: [embedf] });
  console.log(`non`);
}); 
}
}
}
});

client.on('interactionCreate', async i => {
  const guildId = i.guild.id;
   let shop = i.channel
    const shopData = await db.get(`shop_${shop.id}_${guildId}`)
    const setings = shopData;
  const owner = await db.get(`shop_${i.channel.id}_${guildId}.sellerId`)  

  const guild = await client.guilds.fetch(guildId);
const bankId = await db.get(`bank_${guildId}`);

  const transfer = await guild.members.fetch(bankId);
    if (!transfer) {
        await i.reply({
            content: `
عفــوا لم اجد حساب البنك (العضو)
-# تاكد انه داخل السيرفر`,
ephemeral: true,
        });
        return;
    }
  if (i.isButton()) {
    
  if (i.user.id === owner) {
    
 if (i.customId.startsWith('everyone')) {

const amount = i.customId.slice("everyone".length)      

const price = await db.get(`evrypri_${guildId}`);

const result = amount * price; 
const evrytax = Math.floor(result * (20 / 19) + 1);
const embed = new EmbedBuilder()
.setDescription(`لقد اخترت منشنات افري\nالعدد : \`${amount}\`\nالسعر : \`${result}\`\nلديك 60 ثانية قم بنسخ الرسالة ادناه للتحويل\n
\`\`\`#credit ${transfer|| 'لم يتم تحديد بنك السيرفر ._.'} ${evrytax}\`\`\``)
.setFooter({ text: 'By Venlook x Ahmdfc' })
.setTimestamp();


 const row = new ActionRowBuilder()
.addComponents(new ButtonBuilder()
.setCustomId('shop')
.setLabel('منشن متاجر')
.setStyle(ButtonStyle.Primary)
.setDisabled(true))    
.addComponents(new ButtonBuilder()
.setCustomId('here')
.setLabel('منشن هير')
.setStyle(ButtonStyle.Primary)
.setDisabled(true))    
          .addComponents(new ButtonBuilder()
.setCustomId('everyone')
.setLabel('منشن افري')
.setStyle(ButtonStyle.Danger)
 .setDisabled(true))
.addComponents(new ButtonBuilder()
.setCustomId('cancel')
.setLabel('الغاء')
.setStyle(ButtonStyle.Danger)
 .setDisabled(true));


await i.update({ embeds: [embed], components: [row], ephemeral: true });
await i.channel.send({
  content: `#credit ${transfer} ${evrytax}`,
ephemeral: true
});
const filter = ({ content, author: { id } }) => {
    const userName = i.user.username; // اسم المستخدم
    const botId = "282859044593598464"; // معرف البوت
    const totalPrice = result; // السعر المطلوب
    const bankId = transfer.id; // معرف حساب البنك

    // التحقق من الرسائل الإنجليزية
    const startsWithEnglish = content.startsWith(`**:moneybag: | ${userName}, has transferred `);
    const includesBankEnglish = content.includes(`<@!${bankId}>`);
    const amountCheckEnglish = Number(
        content.slice(content.lastIndexOf("`") - String(evrytax).length, content.lastIndexOf("`"))
    ) >= totalPrice;
  
    // التحقق من الرسائل العربية
    const startsWithArabic = content.includes(`**ـ ${userName}, قام بتحويل`);
    const includesBankArabic = content.includes(`<@!${bankId}>`);
    const amountCheckArabic = Number(
        content.slice(content.lastIndexOf("`") - String(evrytax).length, content.lastIndexOf("`"))
    ) >= totalPrice;

    // التحقق النهائي
    return (
        id === botId && (
            (startsWithEnglish && includesBankEnglish && amountCheckEnglish) ||
            (startsWithArabic && includesBankArabic && amountCheckArabic)
        )
    );
};

// إنشاء جامع الرسائل (Collector)
const collector = i.channel.createMessageCollector({
    filter,
    max: 1,
    time: 60000, // الوقت المخصص لجمع الرسائل (60 ثانية)
});
let iscollected = false;
collector.on('collect', async (collected) => {
  iscollected = true;
    const data = await db.get(`shop_${i.channel.id}_${guildId}`)
    if (data) {
    await db.add(`shop_${i.channel.id}_${guildId}.everyoneMentions`, amount)



    const embedv = new EmbedBuilder()
      .setTitle("تمت عملية الشراء بنجاح")
      .setDescription(
        `تم شراء منشنات ايفري بنجاح\nالعدد : \`${amount}\`\nالعدد الان : \`${data.everyoneMentions}\``
      )
      .setFooter({ text: "By Venlook x Ahmdfc" })
      .setTimestamp();
      
       const embedq = new EmbedBuilder()
      .setTitle("تمت عملية الشراء منشنات")
      .setDescription(`
## تم شراء منشنات ايفري بنجاح
### المتجر : <#${i.channel.id}> 
### السعر : ${result}
### الكميه : ${amount}
`)
      .setFooter({ text: "By Venlook x Ahmdfc" })
      .setTimestamp();
const guildName = guild.name;
const invoiceEmbed = new EmbedBuilder()
  .setTitle("- فاتورة الشراء -")
  .setDescription(`
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
✅ **تمت عملية الشراء بنجاح!**
  
**التفاصيل:**
- العدد : \`${amount}\` منشن 
- نوع المــنشن : \`(evryone)\`
- المتــجر المستفيد : ${i.channel} ${config.shopemoji}
- تم التحويل لـ :\n ${bankId} | ${transfer}
- السيــرفر :\n ${i.guild.id} | ${guildName}
- المشتري :\n ${i.user} | \`${i.user.id}\`
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ

- السعر الإجمالي: \`${result}\` ${config.money}
- الضريبة: \`${evrytax - result}\` ${config.money} 
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
- **المجموع الكلي:** \`${evrytax}\` ${config.money}
`)

  .setFooter({ text: "شكراً لـتعاملك معنا! | By Venlook x Ahmdfc" })
  .setTimestamp();
      await i.user.send({ embeds: [invoiceEmbed] });
    await i.channel.send({ embeds: [embedv] });
 
    }
        })
   collector.on('end', (collected) => {
     if (iscollected) return;
     const embedc = new EmbedBuilder()
        .setTitle('انتهاء الوقت')
    .setDescription(`انتهى الوقت لم يتم تحويل المبلغ`)
        .setFooter({ text: 'By Venlook x Ahmdfc' })
        .setTimestamp();
          i.channel.send({ embeds: [embedc] });
        console.log(`yes`);
      });
      
  
      }
} 
}
});








const keywords = [
    'متجر', 'متجري', 'متجرها', 'متجره', 'متجرك', 'متجركم', 'متجرهم', 'متجرنا',
    'عرض', 'عرضي', 'عرضك', 'عرضكم', 'عرضهم', 'عرضنا',
    'عروض', 'عروضي', 'عروضك', 'عروضكم', 'عروضهم', 'عروضنا',
    'حساب', 'حسابي', 'حسابك', 'حسابكم', 'حسابهم', 'حسابنا',
    'حسابات', 'حساباتي', 'حساباتك', 'حساباتكم', 'حساباتهم', 'حساباتنا',
    'متوفر', 'متوفري', 'متوفرها', 'متوفره', 'متوفرك', 'متوفركم', 'متوفرهم', 'متوفرنا',
    'شوب', 'شوبك', 'شوبكم', 'شوبهم', 'شوبنا',
    'اوفر', 'اوفرها', 'اوفره', 'اوفرك', 'اوفركم', 'اوفرهم', 'اوفرنا',
    'بيع', 'بيعي', 'بيعك', 'بيعكم', 'بيعهم', 'بيعنا',
    'للبيع', 'للبيعي', 'للبيعك', 'للبيعكم', 'للبيعهم', 'للبيعنا',
    'ابيع', 'ابيعك', 'ابيعكم', 'ابيعهم', 'ابيعنا',
    'بوست', 'بوستك', 'بوستكم', 'بوستهم', 'بوستنا',
    'نيترو', 'نيتروك', 'نيتروكم', 'نيتروهم', 'نيترونا',
    'روبكس', 'روبكسك', 'روبكسكم', 'روبكسهم', 'روبكسنا',
    'سعر', 'سعري', 'سعرها', 'سعره', 'سعرك', 'سعركم', 'سعرهم', 'سعرنا',
    'تبدخاص', 'تبدخاصك', 'تبدخاصكم', 'تبدخاصهم', 'تبدخاصنا',
    'مطلوب', 'مطلوبة', 'مطلوبك', 'مطلوبكم', 'مطلوبهم', 'مطلوبنا',
    'اطلب', 'اطلبك', 'اطلبكم', 'اطلبهم', 'اطلبنا', 'مقابل', 'تبادل', 'خاص', 'كريدت', 'كريدة', 'كريديت', 
    'كردت',
    'wwewewwewwyuyuhuhujhvuvcyucyww'
];
//const { loadImage } = require('canvas'); // Make sure you import loadImage from 'canvas'
client.on('messageCreate', async (message) => {
  const guildId = message.guild.id;
  if (!message.guild || message.author.bot) return;

  const shopAdmin = await db.get(`shopad_${guildId}`);
  if (shopAdmin && message.member.roles.cache.has(shopAdmin)) return; // تجاهل إذا كان لديه دور مسؤول المتاجر

  const sellerId = await db.get(`shop_${message.channel.id}_${guildId}.sellerId`);
  const shoppp = await db.get(`shop_${message.channel.id}_${guildId}`);
  
  if (shoppp) {
    const foundKeywords = keywords.filter(word => message.content.includes(word));
    if (foundKeywords.length > 0) {
      // عرض أول 5 كلمات فقط
      let keywordMessage = foundKeywords.slice(0, 5).join(', ');
      if (foundKeywords.length > 5) {
        const remainingCount = foundKeywords.length - 5;
        keywordMessage += ` +${remainingCount} more`;
      }

      const warningTime = new Date().toLocaleString();
      const warnsCount = Math.floor(shoppp.warns + 1);

      // إنشاء الإيمبد لتحذير المتجر
      const embed = new EmbedBuilder()
        .setTitle(`**تم تحذير المتجر ${message.channel.url}**`)
        .setDescription(`${config.warn} استبيان تحذير المتاجر`)
        .addFields(
          { name: 'صاحب المتجر:', value: `<@${sellerId}>`, inline: true },
          { name: 'عدد تحذيرات المتجر:', value: `${warnsCount}`, inline: true },
          { name: 'سبب التحذير:', value: `عدم تشفير الكلمات: ${keywordMessage}`, inline: false },
          { name: 'وقت التحذير:', value: warningTime }
        )
        .setColor('#FF0000');

      // إرسال التحذير في القناة
      await message.channel.send({ content: `<@${sellerId}>`, embeds: [embed] });

      // إرسال التحذير في قناة السجل (log channel)
      const logChannelId = await db.get(`logs_${guildId}`);
      if (logChannelId) {
        const logChannel = await message.guild.channels.fetch(logChannelId);
        if (logChannel) {
          const logEmbed = new EmbedBuilder()
            .setTitle('**تحذير تم إرساله إلى المتجر**')
            .addFields(
              { name: 'رابط المتجر:', value: `<#${message.channel.id}>`, inline: true },
              { name: 'صاحب المتجر:', value: `<@${sellerId}>`, inline: true },
              { name: 'عدد تحذيرات المتجر:', value: `${warnsCount}`, inline: true },
              { name: 'سبب التحذير:', value: `عدم تشفير الكلمات: ${keywordMessage}`, inline: false },
              { name: 'رابط الرسالة:', value: `[اضغط هنا](${message.url})`, inline: false }
            )
            .setColor('#FF0000');

          await logChannel.send({ embeds: [logEmbed] });
        }
      }

      // تحديث عدد التحذيرات في قاعدة البيانات
      db.add(`shop_${message.channel.id}_${guildId}.warns`, 1);
    }
  }
});


client.on('messageCreate', async message => {
    if (message.content.startsWith('+infooooooo')) {
        // تحديد معرف المستخدم
        const userId = message.author.id;
        const guildId = message.guild.id;

        // جلب جميع بيانات المتاجر
        const allEntries = await db.all();

        // تصفية المتاجر الخاصة بالمستخدم
        const userShops = allEntries.filter(entry => entry.id.startsWith('shop_') && entry.value.sellerId === userId);
        const shopCount = userShops.length;

        // جلب التحذيرات الخاصة بالمستخدم
        const userWarnings = await db.get(`warnings_${guildId}_${userId}`) || 0;

        // حساب التحذيرات الخاصة بالمتاجر
        const userShopWarnings = userShops.reduce((acc, entry) => acc + (entry.value.warns || 0), 0);

        // حساب التحذيرات الكلية بالسيرفر
        const totalWarnings = allEntries.filter(entry => entry.id.startsWith('shop_')).reduce((acc, entry) => acc + (entry.value.warns || 0), 0);

        // حساب المنشنات الخاصة بالمستخدم
        const userMentionsEvery = userShops.reduce((acc, entry) => acc + (entry.value.everyoneMentions || 0), 0);
        const userMentionsHere = userShops.reduce((acc, entry) => acc + (entry.value.hereMentions || 0), 0);
        const userMentionsShop = userShops.reduce((acc, entry) => acc + (entry.value.shopRoleMentions || 0), 0);

        // حساب المنشنات الكلية بالسيرفر
        const totalMentionsEvery = allEntries.filter(entry => entry.id.startsWith('shop_')).reduce((acc, entry) => acc + (entry.value.everyoneMentions || 0), 0);
        const totalMentionsHere = allEntries.filter(entry => entry.id.startsWith('shop_')).reduce((acc, entry) => acc + (entry.value.hereMentions || 0), 0);
        const totalMentionsShop = allEntries.filter(entry => entry.id.startsWith('shop_')).reduce((acc, entry) => acc + (entry.value.shopRoleMentions || 0), 0);

        // عدد المتاجر الإجمالية المسجلة
        const totalShops = allEntries.filter(entry => entry.id.startsWith('shop_')).length;

        // عدد الردود التلقائية
        const autorepliesCount = allEntries.filter(entry => entry.id.startsWith('autoreply_')).length;

        // عدد الكلمات الممنوعة
        const bannedWords = await db.get('bannedWords') || [];
        const bannedWordsCount = bannedWords.length;

        // إنشاء رسالة الإيمبد
        const embed = new EmbedBuilder()
            .setTitle(`معلومات المستخدم و السيرفر و البوت: `)
            .addFields(
                { name: 'عدد المتاجر الخاصة فيك', value: shopCount.toString(), inline: true },
                { name: 'تحذيرات متجر الخاصه فيك', value: userShopWarnings.toString(), inline: true },
                { name: ' عدد التحذيرات لإجمالية المسجلة ', value: totalWarnings.toString(), inline: true },
                { name: 'عدد المتاجر الإجمالية المسجلة', value: totalShops.toString(), inline: true },
                { name: 'منشنات Everyone الخاصة فيك', value: userMentionsEvery.toString(), inline: true },
                { name: 'منشنات Here الخاصة فيك', value: userMentionsHere.toString(), inline: true },
                { name: 'منشنات المتجر الخاصة فيك', value: userMentionsShop.toString(), inline: true },
                { name: 'منشنات Everyone الكلية المسجله', value: totalMentionsEvery.toString(), inline: true },
                { name: 'منشنات Here الكلية المسجله', value: totalMentionsHere.toString(), inline: true },
                { name: 'منشنات المتجر الكلية المسجله', value: totalMentionsShop.toString(), inline: true },
                { name: 'عدد الردود التلقائية', value: autorepliesCount.toString(), inline: true }
            )
            .setColor('#00FF00')
            .setTimestamp();

        // إرسال رسالة الإيمبد
        message.channel.send({ embeds: [embed] });
    }
});







   client.on('messageCreate', message => {
    // تحقق من أن الأمر يتم تنفيذه بواسطة مسؤول
    if (message.content === '!deleteTickets' && message.member.permissions.has('ADMINISTRATOR')) {
        // احصل على السيرفر
        const guild = message.guild;

        if (guild) {
            guild.channels.cache.forEach(channel => {
                if (channel.name.startsWith('ticket-')) {
                    channel.delete()
                        .then(() => console.log(`Deleted channel: ${channel.name}`))
                        .catch(console.error);
                }
            });
            message.reply('جميع الرومات التي تبدأ بـ "ticket-" تم حذفها.');
        } else {
            message.reply('لم أتمكن من العثور على السيرفر.');
        }
    } else if (message.content === '!deleteTickets') {
        message.reply('يجب أن تكون مسؤول السيرفر لتنفيذ هذا الأمر.');
    }
});

//////////////////////////////////////////////shop

client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;

    if (interaction.customId === 'tashfeerk') {
        const modal = new ModalBuilder()
            .setCustomId('encryptModal')
            .setTitle('🔒 تشفير الرسالة');

        const textInput = new TextInputBuilder()
            .setCustomId('messageInput')
            .setLabel('اكتب رسالتك هنا:')
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(true);

        const actionRow = new ActionRowBuilder().addComponents(textInput);
        modal.addComponents(actionRow);

        await interaction.showModal(modal);
    }
});

client.on('interactionCreate', async (interaction) => {
    if (!interaction.isModalSubmit()) return;

    if (interaction.customId === 'encryptModal') {
        const text = interaction.fields.getTextInputValue('messageInput');


        function encodeText(text) {
            Object.entries(replacements).forEach(([original, replacement]) => {
                const regex = new RegExp(original, 'g');
                text = text.replace(regex, replacement);
            });
            return text;
        }

        const encodedText = encodeText(text);

        // زر النسخ
        const copyButton = new ButtonBuilder()
            .setCustomId('copyMessage')
            .setLabel('🖥️')
            .setStyle(ButtonStyle.Secondary);

        const actionRow = new ActionRowBuilder().addComponents(copyButton);

        await interaction.reply({
            content: `**تــم التــشفــير بــ نجـــاح**\n${encodedText}`,
            components: [actionRow],
            ephemeral: true
        });
    }
});

// عند الضغط على زر النسخ
client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;

    if (interaction.customId === 'copyMessage') {
        const messageContent = interaction.message.content.split("\n")[1]; // الحصول على النص المشفر فقط

        await interaction.reply({
            content: `\`\`\`\n${messageContent}\n\`\`\``,
            ephemeral: true
        });
    }
});




client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;

    const guildId = interaction.guild.id;
    const userId = interaction.member.id;

    if (interaction.customId === 'shoppri') {
    

            const guild = interaction.guild;
            const categories = guild.channels.cache.filter(channel => channel.type === ChannelType.GuildCategory);

            if (!categories.size) {
                return interaction.reply({ content: `**لا يوجد انواع متاجر في هذا السيرفر**`, ephemeral: true });
            }

            const bank = await db.get(`bank_${guildId}`);
            const imageUrl = await db.get(`buyshopimage_${guildId}`);

            // إنشاء أزرار لأنواع المتاجر
            const buttons = [];
            for (const [categoryId, category] of categories) {
                const categoryDataKey = `categoryMentions_${categoryId}_${guildId}`;
                const categoryData = await db.get(categoryDataKey);

                if (!categoryData) continue;
   const nametype = categoryData.nametype;
                buttons.push(
                    new ButtonBuilder()
                        .setCustomId(`select_shop_price_${categoryId}`)
                        .setLabel(categoryData.nametype)
                        .setStyle(ButtonStyle.Secondary)
                );
            }

            // تقسيم الأزرار إلى صفحات إذا كان عددها أكثر من 5
            const pages = [];
            for (let i = 0; i < buttons.length; i += 5) {
                pages.push(buttons.slice(i, i + 5));
            }

            let currentPage = 0;

            // إنشاء الرسالة مع الأزرار
            const row = new ActionRowBuilder().addComponents(pages[currentPage]);

        const shop_prices_embed = {
            title: `** أسـعـار المتاجر **`,
            description: `# - اسعار المتاجر  ${interaction.guild.name} 

### أسـعـار المــتاجر 
${config.money}  .・ أسـعـار المــتاجر ・. ${config.money} 
هنا اسعار المتـــاجر
يرجــى اختيار النــوع اللذي ترغب فــي معرفــة سعــره و مواصــفاتــه

التـحـويـل لـ <@!${bank || 'غير محدد'}>`,
            author: {
                name: `${interaction.guild.name}`,
                icon_url: interaction.guild.iconURL({ size: 1024 }),
            },
            thumbnail: {
                url: interaction.user.displayAvatarURL(),
            },
            ...(imageUrl ? { image: { url: imageUrl } } : {}),
            footer: {
              text: `By Venlook x Ahmdfc`,
                icon_url: interaction.user.displayAvatarURL(),
            },
        };

        await interaction.reply({
            embeds: [shop_prices_embed],     components: [row],
            ephemeral: true, // الرسالة تظهر فقط للشخص الذي ضغط
        });
    }
 if (interaction.customId.startsWith('select_shop_price_')) {
        const categoryId = interaction.customId.split('_')[3];
        const categoryData = await db.get(`categoryMentions_${categoryId}_${guildId}`);
        const pric = categoryData.shopPrice;
        const shoprole = categoryData.shoprole;
        const hasTax = categoryData.hasTax;
        const taxPrice = categoryData.taxPrice;
        const evcount = categoryData.everyoneMentions;
        const hecount = categoryData.hereMentions;
        const shopmen = categoryData.shopmen;
        const maxWarns = categoryData.maxWarns;
        const shcount = categoryData.shopRoleMentions;
        const nametype = categoryData.nametype;
   const shopPrice = Math.floor(pric * (20 / 19) + 1);
    const bank = await db.get(`bank_${guildId}`);
            const imageUrl = await db.get(`buyshopimage_${guildId}`);

        if (!shopPrice) {
            await interaction.reply({
                content: "عفوا لم استطع العثور على سعر نوع  هاذا المتجر",
                ephemeral: true,
            });
            return;
        }
 await interaction.reply({
      embeds: [
        new EmbedBuilder()
          .setTitle(`** النــوع اسم: ${nametype || 'غير محدد'}**`)
          .setDescription(`
          **
          > ${config.wahitsprkle}   النــوع اسم : ${nametype || 'غير محدد'}  
          > ${config.wahitsprkle}  \﹣\ رتــبة هاذا الــنوع :
          > <@&${shoprole || 'غير محدد'}>
          >                         ༺═──────────{مــعــلومــات}───────────═༻
          >                         
          > ${config.refrechmark}  \﹣\ بضريبه؟ : ${hasTax === true ? 'نعم' : hasTax === false ? 'غير محدد' : 'لا'}
          > ${config.money}  \﹣\ سعر الضريبه : ${taxPrice || 'غير محدد'} 
          > ${config.warn} \-\ __ أقصى عدد تحذيرات وينقفل المتجر: ${maxWarns || 'غير محدد'} __
          >                         ༺═──────────{الـــمنـشنات}───────────═༻ 
          >                          
          > ${config.yelloshop} \-\ __ @everyone : ${evcount || 'غير محدد'} __
          > ${config.whaitshop} \-\ __ @here : ${hecount || 'غير محدد'} __
          > ${config.shopemoji} \-\ __ <@&${shopmen || 'غير محدد'}> : ${shcount || 'غير محدد'} __   
          >                         ༺═──────────{الــســعر}───────────═༻
          >                         
          > ${config.money}  \﹣\__ الــسعــر  : ${shopPrice || 'غير محدد'}  __ 
          >                          
           التـحـويـل لـ  <@!${bank || 'غير محدد'}> ${config.hatemoji} 
          **`)
          .setImage(imageUrl || `${config.line}`)
      ]
        , ephemeral: true});

}
});


  client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;

    const guildId = interaction.guild.id;
    const userId = interaction.user.id;
    const channel = interaction.channel;

    if (interaction.customId === "buy_shop") {
const shopcat = await db.get(`catbuy_shop_${guildId}`);
    if (!shopcat) {
        await interaction.reply({
            content: "يرجى تحديد كتاغوري الشراء عن طريق استخدام الامر الاتي: /setup", ephemeral: true
        });
        return;
    }

const { member} = interaction;
  const admin = await db.get(`shopad_${guildId}`)
    if (!admin) {
        await interaction.reply({
            content: "يرجى تحديد مسؤول المتاجر عن طريق الامر الاتي : /setup", ephemeral: true,
        });
        return;
    }


        try {
            const adminsId = await db.get(`shopad_${guildId}`);
            const admins = interaction.guild.roles.cache.get(adminsId);

            const shopData = await db.get(`shop_ticket_${userId}_${guildId}`);
            if (shopData) {
                const existingChannel = interaction.guild.channels.cache.get(shopData.channelId);
                if (existingChannel) {
                    return interaction.reply({ content: `❌ لديك تذكرة مفتوحة بالفعل: <#${existingChannel.id}>`, ephemeral: true });
                } else {
                    await db.delete(`shop_ticket_${userId}_${guildId}`);
                    await db.delete(`shop_credit_${userId}_${guildId}`);
                }
            }

            const shopCategoryId = await db.get(`catbuy_shop_${guildId}`);
            await interaction.deferReply({ ephemeral: true });

            const ticketChannel = await interaction.guild.channels.create({
                name: `shop-${interaction.user.tag}`,
                type: ChannelType.GuildText,
                parent: shopCategoryId,
                permissionOverwrites: [
                    {
                        id: interaction.user.id,
                        allow: ['SendMessages', 'EmbedLinks', 'AttachFiles', 'ViewChannel']
                    },
                    {
                        id: interaction.guild.roles.everyone,
                        deny: ['SendMessages', 'ViewChannel']
                    },
                    {
                        id: admins.id,
                        allow: ['SendMessages', 'MentionEveryone', 'EmbedLinks', 'AttachFiles', 'ViewChannel']
                    }
                ]
            });

            await db.set(`shop_ticket_${userId}_${guildId}`, {
                userId: interaction.member.id,
                channelId: ticketChannel.id
            });

            const guild = interaction.guild;
            const categories = guild.channels.cache.filter(channel => channel.type === ChannelType.GuildCategory);

            if (!categories.size) {
                return interaction.reply({ content: `**لا يوجد كاتيجوري في هذا السيرفر**`, ephemeral: true });
            }

            // إنشاء أزرار لأنواع المتاجر
            const buttons = [];
            for (const [categoryId, category] of categories) {
                const categoryDataKey = `categoryMentions_${categoryId}_${guildId}`;
                const categoryData = await db.get(categoryDataKey);

                if (!categoryData) continue;

                buttons.push({
                    label: String(categoryData.nametype).slice(0, 100),
                    value: `select_shop_type_${categoryId}`,
                });
            }

            // قائمة اختيار المتجر (حتى 25 متجر)
            const row2 = buttons.length
                ? new ActionRowBuilder().addComponents(
                    new StringSelectMenuBuilder()
                        .setCustomId('shop_type_select')
                        .setPlaceholder('اختر نوع المتجر')
                        .addOptions(buttons.slice(0, 25))
                )
                : null;

            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId("closeshop")
                        .setLabel("اغلاق التكت")
                        .setStyle(ButtonStyle.Secondary)
                        .setEmoji("🔒"),
  new ButtonBuilder()
            .setCustomId("shoppri")
            .setLabel("اسعار المــتاجــر")
            .setStyle(ButtonStyle.Secondary)
                );

            const categoryId = interaction.customId.split('_')[3];
            const categoryData = await db.get(`categoryMentions_${categoryId}_${guildId}`);


            // Fetch prices and other data
            const bank = await db.get(`bank_${guildId}`);
            const shopImage = await db.get(`buyshopimage_${guildId}`);

            // Send initial message to the ticket channel
           await ticketChannel.send({
    content: `<@${interaction.user.id}> ${admins}`,
    embeds: [
        {
            title: ` ** تـكـت شراء متجر ** `,
            description: `
التـحـويـل لـ <@!${bank || 'غير محدد'}>`,
            author: {
                name: `${interaction.guild.name}`,
                icon_url: interaction.guild.iconURL({ size: 1024 })
            },
            ...(shopImage ? { image: { url: `${shopImage}` } } : {}),
            footer: {
                text: `By Venlook x Ahmdfc`
            },
            timestamp: new Date()
        }
    ],
    components: row2 ? [row, row2] : [row]
});



            // Confirm ticket creation to the user
            await interaction.editReply({
                content: `**__ تم انشاء تذكرتك بنجاح : <#${ticketChannel.id}> __**`,
                ephemeral: true
            });
        } catch (error) {
            console.error('Error creating shop ticket:', error);
            await interaction.editReply({
                content: '❌ حدث خطأ أثناء إنشاء التذكرة. يرجى المحاولة مرة أخرى لاحقًا.',
                ephemeral: true
            });
        }
    }

    if (interaction.customId.startsWith('select_shop_type_')) {
        const categoryId = interaction.customId.split('_')[3];
        const categoryData = await db.get(`categoryMentions_${categoryId}_${guildId}`);
        const shopPrice = categoryData.shopPrice;



        if (!shopPrice) {
            await interaction.reply({
                content: "عفوا لم استطع العثور على سعر نوع  هاذا المتجر",
                ephemeral: true,
            });
            return;
        }

        const bank = await db.get(`bank_${guildId}`);
        if (!bank) {
            await interaction.reply({
                content: "يرجى تحديد البنك عن طريق استخدام الامر الاتي: /setup",
                ephemeral: true,
            });
            return;
        }

        const data = await db.get(`shop_credit_${userId}_${guildId}`);
        if (data) {
            return await interaction.reply({
                content: `** يـوجد لـديـك عـمـلـيـة شــراء فـ الـوقـت الحـالـي بـ الفـعـل **`,
                ephemeral: true,
            });
        }
const datauser = await db.get(`shop_ticket_${interaction.member.id}_${guildId}.userId`);
    if (datauser !== interaction.user.id) {
                return await interaction.reply({
                    content: `**يمكن ل صاحب التكت فقط استعمال الازرار**`,
                    ephemeral: true,
                });
            }
        try {
            const totalPrice = Math.floor(shopPrice * (20 / 19) + 1);
            // إرسال السعر والتحويل
            await interaction.reply({
                content: `**يرجى التحويل  \` السعر مع الضريبة: ${totalPrice} \`**`,
                ephemeral: true
            });

            await interaction.channel.send(`#credit <@!${bank}> ${totalPrice}`);
            await interaction.channel.send(`\`\`\`#credit ${bank} ${totalPrice}\`\`\``);
            await interaction.channel.send(` . \` يرجى التحويل في أسرع وقت ممكن هنا\` <@!${userId}>`);

            await db.set(`shop_credit_${userId}_${guildId}`, userId);

            const collectorFilter = (m) => m.author.bot === true;
            const collector = interaction.channel.createMessageCollector({
                filter: collectorFilter,
                time: 120000, // 2 دقائق
            });

            collector.on('collect', async (c) => {
                // نص الرسالة الإنجليزية
                const englishTransferMessage = `:moneybag: | ${interaction.user.username}, has transferred \`$${shopPrice}\` to <@!${bank}>`;

                // نص الرسالة العربية
                const arabicTransferMessage = `**ـ ${interaction.user.username}, قام بتحويل \`$${shopPrice}\` لـ <@!${bank}> ** |:moneybag:`;

                if (c.content.includes(englishTransferMessage) || c.content.includes(arabicTransferMessage)) {
                    collector.stop("DONE");
                }
            });

            collector.on("end", async (collected, reason) => {
                if (reason === "DONE") {
                    await interaction.channel.send({
                        content: `**تم التحقق من التحويل بنجاح. يرجى ارسال اسم المتجر.**`
                    });

                    const collectorFilter = m => m.author.id === interaction.user.id;
                    const collectedMessages = await interaction.channel.awaitMessages({
                        filter: collectorFilter,
                        max: 1,
                        time: 300000,
                        errors: ['time']
                    });

                    if (collectedMessages.size > 0) {
                        const userMessage = collectedMessages.first().content;

                        const confirmRow = new ActionRowBuilder().addComponents(
                            new ButtonBuilder()
                                .setCustomId('confirm_yes_shop')
                                .setLabel('نعم')
                                .setStyle(ButtonStyle.Success)
                         
                        );

                        if (userMessage.length > 100) {
                            return await interaction.channel.send({
                                content: `**هد شوي اسم المتجر كبير ._.**`,
                                ephemeral: true,
                            });
                        }

                        const linkRegex = /\b((https?:\/\/|www\.)[^\s]+(?:\.[a-z]{2,}|\/[^\s]*)?|https?:\/\/(?:discord\.gg|discord\.com\/invite|discord\.com\/channels\/[0-9]+\/[0-9]+\/[0-9]+))/gi;

                        if (linkRegex.test(userMessage)) {
                            return interaction.channel.send({
                                content: `**⚠️ لا يُسمح بإضافة روابط .**`
                            });
                        }

                        const confirmMessage = await interaction.channel.send({
                            content: `**يرجــى التأكيد, اسم المتجر هو**\n${userMessage}`,
                            components: [confirmRow]
                        });

                        const confirmFilter = (i) => i.user.id === userId;
                        const confirmCollector = confirmMessage.createMessageComponentCollector({
                            filter: confirmFilter,
                            time: 60000,
                        });
 const admin = await db.get(`shopad_${guildId}`)
                        confirmCollector.on('collect', async (i) => {
                            if (i.customId === 'confirm_yes_shop') {
const datauser = await db.get(`shop_ticket_${interaction.member.id}_${guildId}.userId`);
    if (datauser !== interaction.user.id) {
                return await interaction.reply({
                    content: `**يمكن ل صاحب التكت فقط استعمال الازرار**`,
                    ephemeral: true,
                });
            }
     const name = userMessage.replaceAll(' ', '・');
                                const pirefix = categoryData.pirefix;
                                const channel = await i.guild.channels.create({
                                    name: `${pirefix}${name}`,
                                    type: ChannelType.GuildText,
                                    parent: categoryId,
                                    permissionOverwrites: [
                                        {
                                            id: i.guild.id,
                                            deny: [
                                                PermissionFlagsBits.SendMessages,
                                                PermissionFlagsBits.AddReactions,
                                                PermissionFlagsBits.CreatePublicThreads,
                                                PermissionFlagsBits.CreatePrivateThreads,
                                                PermissionFlagsBits.AttachFiles,
                                                PermissionFlagsBits.EmbedLinks,
                                            ],
                                        },
                                        {
                                            id: i.user.id,
                                            allow: [
                                                PermissionFlagsBits.ViewChannel,
                                                PermissionFlagsBits.SendMessages,
                                                PermissionFlagsBits.AddReactions,
                                                PermissionFlagsBits.AttachFiles,
                                                PermissionFlagsBits.MentionEveryone,
                                                PermissionFlagsBits.EmbedLinks,
                                                PermissionFlagsBits.UseExternalEmojis,
                                                PermissionFlagsBits.ReadMessageHistory,
                                            ],
                                        },
                {
                    id: admin,
                    allow: [
                        PermissionFlagsBits.ViewChannel,
                        PermissionFlagsBits.SendMessages,
                        PermissionFlagsBits.AddReactions,
                        PermissionFlagsBits.AttachFiles,
                        PermissionFlagsBits.MentionEveryone,
                        PermissionFlagsBits.EmbedLinks,
                        PermissionFlagsBits.UseExternalEmojis,
                        PermissionFlagsBits.ReadMessageHistory,
                    ],
                },
                                    ],
                                });

                                const datecreated = `<t:${parseInt(Date.now() / 1000)}:R>`;
                                const ob = {
                                    channelId: channel.id,
                                    categoryId: categoryId,
                                    sellerId: i.user.id,
                                    everyoneMentions: categoryData.everyoneMentions,
                                    hereMentions: categoryData.hereMentions,
                                    shopmen: categoryData.shopmen,
                                    shoprole: categoryData.shoprole,
                                    shopRoleMentions: categoryData.shopRoleMentions,
                                    maxWarns: categoryData.maxWarns,
                                    date: datecreated,
                                    taxPrice: categoryData.taxPrice,
                                    hasTax: categoryData.hasTax,
                                    nametype: categoryData.nametype,
                                    pirefix: pirefix,
                                    shopname: userMessage
                                };

                                await db.set(`shop_${channel.id}_${guildId}`, ob);
                                await db.set(`shop_${channel.id}_${guildId}.warns`, "0")
                                await db.set(`shop_${channel.id}_${guildId}.status`, "1");

                                // إرسال رسالة تأكيد
                                const em5 = new EmbedBuilder()
                                    .setTitle('**تم انشاء متجر : **')
                                    .setDescription(` **
> ${config.wahitsprkle}  \﹣\ المـتـجـر : ${channel}
> 
> ${config.wahitsprkle}  \﹣\ صـاحـب المـتـجـر : <@${i.user.id}>
> 
> ${config.wahitsprkle}  \﹣\ نـوع المـتـجر : ${categoryData.nametype || 'لم يتم العثور عليه'}
> 
> ${config.wahitsprkle}  \﹣\ رتبة هاذا النوع  : <@&${categoryData.shoprole || 'لم يتم العثور عليه'}> 
> 
> ${config.wahitsprkle}  \﹣\ اقصى عدد للتحذيرات : ${categoryData.maxWarns || 'غير محدد'}
> 
> ${config.wahitsprkle}  \﹣\ بضريبه؟ : ${categoryData.hasTax === true ? 'نعم' : categoryData.hasTax === false ? 'لا' : 'غير محدد'}

${config.yelloshop} \-\ __ @everyone : ${categoryData.everyoneMentions} __
${config.whaitshop}: \-\ __ @here : ${categoryData.hereMentions} __
${config.shopemoji} \-\ __ <@&${categoryData.shopmen}> : ${categoryData.shopRoleMentions} __

**`)


                                    .setAuthor({ name: i.guild.name, iconURL: i.guild.iconURL({ size: 1024 }) })
                                    .setFooter({ text: 'By Venlook x Ahmdfc' })
                                    .setTimestamp()
                                    .setThumbnail(i.guild.iconURL({ size: 1024 }));
    const seller = await i.guild.members.fetch(i.user.id);
    if (categoryData.shoprole) {
        if (!i.guild.members.me.permissions.has(PermissionFlagsBits.ManageRoles)) {
            await i.channel.send('**عذرا البوت لا يمتلاك الصلاحيات يرجى رفع رتبتي فوق رتبت التاجر و اعطائي الصلاحيات اللازمه..**');
        } else {
            try {
                await seller.roles.add(categoryData.shoprole);
                console.log(`Added role ${i.user.id} to seller ${i.user.id}`);
            } catch (error) {
                console.error(`Failed to add role to seller: ${error}`);
            }
        }
    }




const guildName = interaction.guild.name;
const invoiceEmbed = new EmbedBuilder()
  .setTitle("- فاتورة الشراء -")
  .setDescription(`
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
✅ **تمت عملية الشراء بنجاح!**
  
**التفاصيل:**
- تم شـراء متــجر 
- المتــجر : ${channel} ${config.shopemoji}
- تم التحويل لـ :\n ${bank} | <@!${bank}>
- السيــرفر :\n ${i.guild.id} | ${guildName}
- المشتري :\n ${i.user} | \`${i.user.id}\`
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ

- السعر الاصلـي: \`${shopPrice}\` ${config.money}
- الضريبة: \`${totalPrice - shopPrice}\` ${config.money} 
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
- **المجموع الكلي:** \`${totalPrice}\` ${config.money}
`)

  .setFooter({ text: "شكراً لـتعاملك معنا! | By Venlook x Ahmdfc" })
  .setTimestamp();
      await interaction.user.send({ embeds: [invoiceEmbed] });

                                await channel.send({ embeds: [em5] });
                              await interaction.channel.delete();
                            }
                        });
                    }
                }
            });
        } catch (error) {
            console.error('Error handling shop type selection:', error);
            await interaction.reply({
                content: '❌ حدث خطأ أثناء معالجة الطلب. يرجى المحاولة مرة أخرى لاحقًا.',
                ephemeral: true
            });
        }
    }

    if (interaction.customId === "closeshop") {
        await db.delete(`shop_credit_${userId}_${guildId}`);
        await db.delete(`shop_ticket_${userId}_${guildId}`);

        const closingEmbed = new EmbedBuilder()
            .setDescription("**سيتم قفل التذكرة بعد 5 ثواني...**")
            .setColor("00ccff");

        await interaction.reply({ embeds: [closingEmbed] });

        setTimeout(() => {
            channel.delete().catch(() => {});
        }, 5000);
    } else if (interaction.customId === "reopenshop") {
        const shopAdminRoleId = await db.get(`shopad_${guildId}`);
        const shopAdminRole = interaction.guild.roles.cache.get(shopAdminRoleId);

        await channel.permissionOverwrites.set([
            {
                id: guildId,
                deny: ['ViewChannel']
            },
            {
                id: userId,
                allow: ['ViewChannel', 'SendMessages', 'EmbedLinks', 'AttachFiles']
            },
            {
                id: shopAdminRole.id,
                allow: ['ViewChannel', 'SendMessages', 'MentionEveryone', 'EmbedLinks', 'AttachFiles']
            }
        ]);

        const reopenedEmbed = new EmbedBuilder()
            .setDescription("**تم فتح التذكرة مرة أخرى.**")
            .setColor("00ccff");

        const newActionRow = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('closeshop')
                    .setLabel('إغلاق التذكرة')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.reply({ embeds: [reopenedEmbed], components: [newActionRow] });

          const disabledRow = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('reopenshop')
                    .setLabel('فتح التذكرة')
                    .setStyle(ButtonStyle.Primary)
                    .setDisabled(true),
                new ButtonBuilder()
                    .setCustomId('deleteshop')
                    .setLabel('حذف التذكرة')
                    .setStyle(ButtonStyle.Danger)
                    .setDisabled(true)
            );

        await interaction.message.edit({ components: [disabledRow] });
    } else if (interaction.customId === "deleteshop") {
        await interaction.channel.delete();
    }
});













client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;

    const guildId = interaction.guild.id;
    const userId = interaction.user.id;
    const channel = interaction.channel;

    if (interaction.customId === "ticket-auction") {
 const auctioncat = await db.get(`catbuy_auction_${guildId}`);
    if (!auctioncat) {
        await interaction.reply({
            content: "يرجى تحديد كتاغوري الشراء عن طريق استخدام الامر الاتي: /setup", ephemeral: true
        });
        return;
    }

const { member} = interaction;
  const admin = await db.get(`auctionad_${guildId}`)
    if (!admin) {
        await interaction.reply({
            content: "يرجى تحديد مسؤول المزاد عن طريق الامر الاتي : /setup", ephemeral: true,
        });
        return;
    }

        try {
            const auctionAdminRoleId = await db.get(`auctionad_${guildId}`);
            const auctionAdminRole = interaction.guild.roles.cache.get(auctionAdminRoleId);

            const auctionData = await db.get(`auction_ticket_${userId}_${guildId}`);
            if (auctionData) {
                const existingChannel = interaction.guild.channels.cache.get(auctionData.channelId);
                if (existingChannel) {
                    return interaction.reply({ content: `❌ لديك تذكرة مفتوحة بالفعل: <#${existingChannel.id}>`, ephemeral: true });
                } else {
                    await db.delete(`auction_ticket_${userId}_${guildId}`);
                    await db.delete(`auction_credit_${userId}_${guildId}`);
                }
            }

            const auctionCategoryId = await db.get(`catbuy_auction_${guildId}`);
            await interaction.deferReply({ ephemeral: true });

            const ticketChannel = await interaction.guild.channels.create({
                name: `auction-${interaction.user.tag}`,
                type: ChannelType.GuildText,
                parent: auctionCategoryId,
                permissionOverwrites: [
                    {
                        id: interaction.user.id,
                        allow: ['SendMessages', 'EmbedLinks', 'AttachFiles', 'ViewChannel']
                    },
                    {
                        id: interaction.guild.roles.everyone,
                        deny: ['SendMessages', 'ViewChannel']
                    },
                    {
                        id: auctionAdminRole.id,
                        allow: ['SendMessages', 'MentionEveryone', 'EmbedLinks', 'AttachFiles', 'ViewChannel']
                    }
                ]
            });

            await db.set(`auction_ticket_${userId}_${guildId}`, {
                userId: interaction.member.id,
                channelId: ticketChannel.id
            });

            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId("every-auction")
                        .setLabel("مــنـشـن ايـفـري")
                        .setStyle(ButtonStyle.Secondary),

                    new ButtonBuilder()
                       .setCustomId('here-auction')
                        .setLabel("مـنـشـن هـيـر")
                        .setStyle(ButtonStyle.Secondary),

                    new ButtonBuilder()
                        .setCustomId("closeauction")
                        .setLabel("اغلاق التكت")
                        .setStyle(ButtonStyle.Secondary)
                        .setEmoji("🔒")
                );

            // Fetch prices and other data
            const auctionEveryPriceCredit = await db.get(`auction-evrypri_${guildId}`);
            const auctionHerePriceCredit = await db.get(`auction-herepri_${guildId}`);
            const bank = await db.get(`bank_${guildId}`);
            const auctionImage = await db.get(`buyauctionimage_${guildId}`);

   // Send initial message to the ticket channel
await ticketChannel.send({
    content: `<@${interaction.user.id}> ${auctionAdminRole}`,
    embeds: [
        {
            title: ` ** تـكـت المـزادات ** `,
            description: `# - اسعار المزادات  ${interaction.guild.name} 

### أسـعـار المـزادات 
${config.money}  .・ أسـعـار المـزادات ・. ${config.money} 
مـنـشـن ( @everyone ) :
${config.probotemoji}・السـعـر  :  ${auctionEveryPriceCredit || 'غير محدد'}


مـنـشـن ( @here ) :
${config.probotemoji}・السـعـر  : ${auctionHerePriceCredit || 'غير محدد'} 


التـحـويـل لـ <@!${bank || 'غير محدد'}>`,
            author: {
                name: `${interaction.guild.name}`,
                icon_url: interaction.guild.iconURL({ size: 1024 })
            },
            ...(auctionImage ? { image: { url: `${auctionImage}` } } : {}),
            footer: {
                text: `By Venlook x Ahmdfc`
            },
            timestamp: new Date()
        }
    ],
    components: [row]
});

            // Send additional line (if any)
            const line = await db.get(`image_${guildId}`);
            if (line) {
                await ticketChannel.send(line);
            }

            // Confirm ticket creation to the user
            await interaction.editReply({
                content: `**__ تم انشاء تذكرتك بنجاح : <#${ticketChannel.id}> __**`,
                ephemeral: true
            });
        } catch (error) {
            console.error('Error creating auction ticket:', error);
            await interaction.editReply({
                content: '❌ حدث خطأ أثناء إنشاء التذكرة. يرجى المحاولة مرة أخرى لاحقًا.',
                ephemeral: true
            });
        }
    } else if (interaction.customId === "closeauction") {
        await db.delete(`auction_credit_${userId}_${guildId}`);
        await db.delete(`auction_ticket_${userId}_${guildId}`);

        const closingEmbed = new EmbedBuilder()
            .setDescription("**سيتم قفل التذكرة بعد 5 ثواني...**")
            .setColor("00ccff");

        await interaction.reply({ embeds: [closingEmbed] });

        setTimeout(() => {
            channel.delete().catch(() => {});
        }, 5000);
    } else if (interaction.customId === "reopenauction") {
        const auctionAdminRoleId = await db.get(`auctionad_${guildId}`);
        const auctionAdminRole = interaction.guild.roles.cache.get(auctionAdminRoleId);

        await channel.permissionOverwrites.set([
            {
                id: guildId,
                deny: ['ViewChannel']
            },
            {
                id: userId,
                allow: ['ViewChannel', 'SendMessages', 'EmbedLinks', 'AttachFiles']
            },
            {
                id: auctionAdminRole.id,
                allow: ['ViewChannel', 'SendMessages', 'MentionEveryone', 'EmbedLinks', 'AttachFiles']
            }
        ]);

        const reopenedEmbed = new EmbedBuilder()
            .setDescription("**تم فتح التذكرة مرة أخرى.**")
            .setColor("00ccff");

        const newActionRow = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('closeauction')
                    .setLabel('إغلاق التذكرة')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.reply({ embeds: [reopenedEmbed], components: [newActionRow] });

        const disabledRow = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('reopenauction')
                    .setLabel('فتح التذكرة')
                    .setStyle(ButtonStyle.Primary)
                    .setDisabled(true),
                new ButtonBuilder()
                    .setCustomId('deleteauction')
                    .setLabel('حذف التذكرة')
                    .setStyle(ButtonStyle.Danger)
                    .setDisabled(true)
            );

        await interaction.message.edit({ components: [disabledRow] });
    } else if (interaction.customId === "deleteauction") {
        await interaction.channel.delete();
    }
});



client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;

    const guildId = interaction.guild.id;
    const userId = interaction.member.id;

    if (interaction.customId === 'auctionpri') {
  const auctionEveryPriceCredit = await db.get(`auction-evrypri_${guildId}`);
            const auctionHerePriceCredit = await db.get(`auction-herepri_${guildId}`);
            const bank = await db.get(`bank_${guildId}`);
            const imageUrl = await db.get(`buyauctionimage_${guildId}`);
     
   
const order_prices_embed = {
    title: ` ** اسعار المـزادات ** `,
    description: `# - اسعار المزادات  ${interaction.guild.name} 

### أسـعـار المـزادات 
${config.money}  .・ أسـعـار المـزادات ・. ${config.money} 
مـنـشـن ( @everyone ) :
${config.probotemoji}・السـعـر  :  ${auctionEveryPriceCredit || 'غير محدد'}

مـنـشـن ( @here ) :
${config.probotemoji}・السـعـر  : ${auctionHerePriceCredit || 'غير محدد'} 

التـحـويـل لـ <@!${bank || 'غير محدد'}>`,
    author: {
        name: `${interaction.guild.name}`,
        icon_url: interaction.guild.iconURL({ size: 1024 }),
    },
    thumbnail: {
        url: interaction.user.displayAvatarURL(),
    },
    // Conditionally add the image field if imageUrl exists
    ...(imageUrl ? { image: { url: imageUrl } } : {}),
    footer: {
      text: `By Venlook x Ahmdfc`,
        icon_url: interaction.user.displayAvatarURL(),
    },
};

        await interaction.reply({
            embeds: [order_prices_embed],
            ephemeral: true, // الرسالة تظهر فقط للشخص الذي ضغط
        });
    }
});
     

///////

client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;

    const guildId = interaction.guild.id;
    const userId = interaction.user.id;

    // التحقق من إعداد المزاد
    const setupCheck = async () => {
        const bank = await db.get(`bank_${guildId}`);
        const evrypri = await db.get(`auction-evrypri_${guildId}`);

        if (!bank) return { success: false, message: "يرجى تحديد البنك باستخدام الأمر: /setup" };
        if (!evrypri) return { success: false, message: "يرجى تحديد سعر منشن الايفري باستخدام الأمر: /setup" };

        return { success: true, data: { bank, evrypri } };
    };

    // منشن الايفري
    if (interaction.customId === "every-auction") {
        const setupCheckResult = await setupCheck();

        if (!setupCheckResult.success) {
            return await interaction.reply({ content: setupCheckResult.message, ephemeral: true });
        }

        const { bank, evrypri } = setupCheckResult.data;

        const activePurchase = await db.get(`auction_credit_${userId}_${guildId}`);
        if (activePurchase) {
            return await interaction.reply({
                content: `**لديك عملية شراء قيد التنفيذ بالفعل.**`,
                ephemeral: true,
            });
        }
const datauser = await db.get(`auction_ticket_${interaction.member.id}_${guildId}.userId`);
    if (datauser !== interaction.user.id) {
                return await interaction.reply({
                    content: `**يمكن ل صاحب التكت فقط استعمال الازرار**`,
                    ephemeral: true,
                });
            }
        const totalPrice = Math.floor(evrypri * (20 / 19) + 1);
        await interaction.reply({
            content: `** \`السعر مع الضريبة: ${totalPrice}\`**`,
            ephemeral: true,
        });

        await interaction.channel.send(`#credit <@!${bank}> ${totalPrice}`);
        await interaction.channel.send(`. \`يرجى التحويل في أسرع وقت ممكن هنا\` <@!${userId}>`);
        await db.set(`auction_credit_${userId}_${guildId}`, userId);

        const collector = interaction.channel.createMessageCollector({
            filter: (m) => m.author.bot === true,
            time: 120000,
        });

        collector.on('collect', async (c) => {
            // نص الرسالة الإنجليزية
            const englishTransferMessage = `:moneybag: | ${interaction.user.username}, has transferred \`$${evrypri}\` to <@!${bank}>`;

            // نص الرسالة العربية
            const arabicTransferMessage = `**ـ ${interaction.user.username}, قام بتحويل \`$${evrypri}\` لـ <@!${bank}> ** |:moneybag:`;

            if (c.content.includes(englishTransferMessage) || c.content.includes(arabicTransferMessage)) {
                collector.stop("DONE");
            }
        });

        const auctionadmin = await db.get(`auctionad_${guildId}`);

        collector.on("end", async (collected, reason) => {
            if (reason === "DONE") {
const ernsing = Number(evrypri);
await db.add(`ernss_${guildId}.erns`, ernsing);

await db.add(`ernsg.ernsg`, ernsing);

                await interaction.channel.send({
                    content: `تـم التـحقق من التــحويل بـ نــجاح!
يــرجى انتــظار المســؤول
<@&${auctionadmin}>`,
                });


const guildName = interaction.guild.name;
const invoiceEmbed = new EmbedBuilder()
  .setTitle("- فاتورة الشراء -")
  .setDescription(`
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
✅ **تمت عملية الشراء بنجاح!**
  
**التفاصيل:**
- تم شـراء مــزاد 
- تم التحويل لـ :\n ${bank} | <@!${bank}>
- السيــرفر :\n ${interaction.guild.id} | ${guildName}
- المشتري :\n ${interaction.user} | \`${interaction.user.id}\`
- نـوع المنــنشن : (everyone)
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ

- السعر الاصلـي: \`${evrypri}\` ${config.money}
- الضريبة: \`${totalPrice - evrypri}\` ${config.money} 
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
- **المجموع الكلي:** \`${totalPrice}\` ${config.money}
`)

  .setFooter({ text: "شكراً لـتعاملك معنا! | By Venlook x Ahmdfc" })
  .setTimestamp();
      await interaction.user.send({ embeds: [invoiceEmbed] });

                await db.delete(`auction_credit_${userId}_${guildId}`);
            } else {
                await interaction.channel.send({
                    content: `**انتهى الوقت ولم يتم التحويل.** <@!${userId}>`,
                });
                await interaction.followUp({
                    content: `**لم يتم التحويل في الوقت المحدد أو حدثت مشكلة ما.**`,
                    ephemeral: true,
                });
                await db.delete(`auction_credit_${userId}_${guildId}`);
            }
        });
    }
});

//--------------------------------------------------------------------  here
client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;

    const guildId = interaction.guild.id;
    const userId = interaction.user.id;

    // التحقق من إعداد المزاد
    const setupCheck = async () => {
        const bank = await db.get(`bank_${guildId}`);
        const herepri = await db.get(`auction-herepri_${guildId}`);

        if (!bank) return { success: false, message: "يرجى تحديد البنك باستخدام الأمر: /setup" };
        if (!herepri) return { success: false, message: "يرجى تحديد سعر منشن الهير باستخدام الأمر: /setup" };

        return { success: true, data: { bank, herepri } };
    };

    // منشن الايفري
    if (interaction.customId === "here-auction") {
        const setupCheckResult = await setupCheck();

        if (!setupCheckResult.success) {
            return await interaction.reply({ content: setupCheckResult.message, ephemeral: true });
        }

        const { bank, herepri } = setupCheckResult.data;

        const activePurchase = await db.get(`auction_credit_${userId}_${guildId}`);
        if (activePurchase) {
            return await interaction.reply({
                content: `**لديك عملية شراء قيد التنفيذ بالفعل.**`,
                ephemeral: true,
            });
        }
const datauser = await db.get(`auction_ticket_${interaction.member.id}_${guildId}.userId`);
    if (datauser !== interaction.user.id) {
                return await interaction.reply({
                    content: `**يمكن ل صاحب التكت فقط استعمال الازرار**`,
                    ephemeral: true,
                });
            }
        const totalPrice = Math.floor(herepri * (20 / 19) + 1);
        await interaction.reply({
            content: `** \`السعر مع الضريبة: ${totalPrice}\`**`,
            ephemeral: true,
        });

        await interaction.channel.send(`#credit ${bank} ${totalPrice}`);
        await interaction.channel.send(`. \`يرجى التحويل في أسرع وقت ممكن هنا\` <@!${userId}>`);
        await db.set(`auction_credit_${userId}_${guildId}`, userId);

        const collector = interaction.channel.createMessageCollector({
            filter: (m) => m.author.bot === true,
            time: 120000,
        });

        collector.on('collect', async (c) => {
            // نص الرسالة الإنجليزية
            const englishTransferMessage = `:moneybag: | ${interaction.user.username}, has transferred \`$${herepri}\` to <@!${bank}>`;

            // نص الرسالة العربية
            const arabicTransferMessage = `**ـ ${interaction.user.username}, قام بتحويل \`$${herepri}\` لـ <@!${bank}> ** |:moneybag:`;

            if (c.content.includes(englishTransferMessage) || c.content.includes(arabicTransferMessage)) {
                collector.stop("DONE");
            }
        });

        const auctionadmin = await db.get(`auctionad_${guildId}`);

        collector.on("end", async (collected, reason) => {
            if (reason === "DONE") {
const ernsing = Number(herepri);
await db.add(`ernss_${guildId}.erns`, ernsing);

await db.add(`ernsg.ernsg`, ernsing);

                await interaction.channel.send({
                    content: `تـم التـحقق من التــحويل بـ نــجاح!
يــرجى انتــظار المســؤول
<@&${auctionadmin}>`,
                });

const guildName = interaction.guild.name;
const invoiceEmbed = new EmbedBuilder()
  .setTitle("- فاتورة الشراء -")
  .setDescription(`
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
✅ **تمت عملية الشراء بنجاح!**
  
**التفاصيل:**
- تم شـراء مــزاد 
- تم التحويل لـ :\n ${bank} | <@!${bank}>
- السيــرفر :\n ${interaction.guild.id} | ${guildName}
- المشتري :\n ${interaction.user} | \`${interaction.user.id}\`
- نـوع المنــنشن : (here)
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ

- السعر الاصلـي: \`${herepri}\` ${config.money}
- الضريبة: \`${totalPrice - herepri}\` ${config.money} 
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
- **المجموع الكلي:** \`${totalPrice}\` ${config.money}
`)

  .setFooter({ text: "شكراً لـتعاملك معنا! | By Venlook x Ahmdfc" })
  .setTimestamp();
      await interaction.user.send({ embeds: [invoiceEmbed] });
                await db.delete(`auction_credit_${userId}_${guildId}`);
            } else {
                await interaction.channel.send({
                    content: `**انتهى الوقت ولم يتم التحويل.** <@!${userId}>`,
                });
                await interaction.followUp({
                    content: `**لم يتم التحويل في الوقت المحدد أو حدثت مشكلة ما.**`,
                    ephemeral: true,
                });
                await db.delete(`auction_credit_${userId}_${guildId}`);
            }
        });
    }
});








//////////////////////////////////////////////////////order



client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;

    const guildId = interaction.guild.id;
    const userId = interaction.user.id;
    const channel = interaction.channel;

    if (interaction.customId === "order") {
 const ordercat = await db.get(`catbuy_order_${guildId}`);
    if (!ordercat) {
        await interaction.reply({
            content: "يرجى تحديد كتاغوري الشراء عن طريق استخدام الامر الاتي: /setup", ephemeral: true
        });
        return;
    }
const { member} = interaction;
  const admin = await db.get(`orderad_${guildId}`)
    if (!admin) {
        await interaction.reply({
            content: "يرجى تحديد مسؤول الطلبات عن طريق الامر الاتي : /setup", ephemeral: true,
        });
        return;
    }


        try {
            const orderAdminRoleId = await db.get(`orderad_${guildId}`);
            const orderAdminRole = interaction.guild.roles.cache.get(orderAdminRoleId);

            const orderData = await db.get(`order_ticket_${userId}_${guildId}`);
            if (orderData) {
                const existingChannel = interaction.guild.channels.cache.get(orderData.channelId);
                if (existingChannel) {
                    return interaction.reply({ content: `❌ لديك تذكرة مفتوحة بالفعل: <#${existingChannel.id}>`, ephemeral: true });
                } else {
                    await db.delete(`order_ticket_${userId}_${guildId}`);
                    await db.delete(`order_credit_${userId}_${guildId}`);
                }
            }

            const ticketsBuyCategoryId = await db.get(`catbuy_order_${guildId}`);
            await interaction.deferReply({ ephemeral: true });

            const ticketChannel = await interaction.guild.channels.create({
                name: `order-${interaction.user.tag}`,
                type: ChannelType.GuildText,
                parent: ticketsBuyCategoryId,
                permissionOverwrites: [
                    {
                        id: interaction.user.id,
                        allow: ['SendMessages', 'EmbedLinks', 'AttachFiles', 'ViewChannel']
                    },
                    {
                        id: interaction.guild.roles.everyone,
                        deny: ['SendMessages', 'ViewChannel']
                    },
                    {
                        id: orderAdminRole.id,
                        allow: ['SendMessages', 'MentionEveryone', 'EmbedLinks', 'AttachFiles', 'ViewChannel']
                    }
                ]
            });

            await db.set(`order_ticket_${userId}_${guildId}`, {
                userId: interaction.member.id,
                channelId: ticketChannel.id
            });

            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId("every-order")
                        .setLabel("مــنـشـن ايـفـري")
                        .setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder()
                        .setCustomId("horder")
                        .setLabel("مـنـشـن هـيـر")
                        .setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder()
                        .setCustomId("orderclose")
                        .setLabel("اغلاق التكت")
                        .setStyle(ButtonStyle.Secondary)
                        .setEmoji("🔒")
                );

             // Fetch prices and other data
            const orderEveryPriceCredit = await db.get(`order-evrypri_${guildId}`);
            const orderHerePriceCredit = await db.get(`order-herepri_${guildId}`);
            const bank = await db.get(`bank_${guildId}`);
            const orderImage = await db.get(`buyorderimage_${guildId}`);

            // Send initial message to the ticket channel
          await ticketChannel.send({
    content: `<@${interaction.user.id}> ${orderAdminRole}`,
    embeds: [
        {
            title: ` ** تـكـت الطـلـبـات ** `,
            description: `# - اسعار الطلبات  ${interaction.guild.name} 

### أسـعـار الطـلـبـات 
${config.money}  .・ أسـعـار الطــلبـات ・. ${config.money} 
مـنـشـن ( @everyone ) :
${config.probotemoji}・السـعـر  :  ${orderEveryPriceCredit || 'غير محدد'}

مـنـشـن ( @here ) :
${config.probotemoji}・السـعـر  : ${orderHerePriceCredit || 'غير محدد'} 

التـحـويـل لـ <@!${bank || 'غير محدد'}>`,
            author: {
                name: `${interaction.guild.name}`,
                icon_url: interaction.guild.iconURL({ size: 1024 })
            },
            // Conditionally add the image field if orderImage exists
            ...(orderImage ? { image: { url: orderImage } } : {}),
            footer: {
                text: `By Venlook x Ahmdfc`
            },
            timestamp: new Date()
        }
    ],
    components: [row]
});

            // Send additional line (if any)
            const line = await db.get(`image_${guildId}`);
            if (line) {
                await ticketChannel.send(line);
            }

            // Confirm ticket creation to the user
            await interaction.editReply({
                content: `**__ تم انشاء تذكرتك بنجاح : <#${ticketChannel.id}> __**`,
                ephemeral: true
            });
        } catch (error) {
            console.error('Error creating order ticket:', error);
            await interaction.editReply({
                content: '❌ حدث خطأ أثناء إنشاء التذكرة. يرجى المحاولة مرة أخرى لاحقًا.',
                ephemeral: true
            });
        }
    } else if (interaction.customId === "orderclose") {
        await db.delete(`order_credit_${userId}_${guildId}`);
        await db.delete(`order_ticket_${userId}_${guildId}`);

        const closingEmbed = new EmbedBuilder()
            .setDescription("**سيتم قفل التذكرة بعد 5 ثواني...**")
            .setColor("00ccff");

        await interaction.reply({ embeds: [closingEmbed] });

        setTimeout(() => {
            channel.delete().catch(() => {});
        }, 5000);
    } else if (interaction.customId === "reopen") {
        const orderAdminRoleId = await db.get(`orderad_${guildId}`);
        const orderAdminRole = interaction.guild.roles.cache.get(orderAdminRoleId);


        await channel.permissionOverwrites.set([
            {
                id: guildId,
                deny: ['ViewChannel']
            },
            {
                id: userId,
                allow: ['ViewChannel', 'SendMessages', 'EmbedLinks', 'AttachFiles']
            },
            {
                id: orderAdminRole.id,
                allow: ['ViewChannel', 'SendMessages', 'MentionEveryone', 'EmbedLinks', 'AttachFiles']
            }
        ]);

        const reopenedEmbed = new EmbedBuilder()
            .setDescription("**تم فتح التذكرة مرة أخرى.**")
            .setColor("00ccff");

        const newActionRow = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('orderclose')
                    .setLabel('إغلاق التذكرة')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.reply({ embeds: [reopenedEmbed], components: [newActionRow] });

        const disabledRow = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('reopen')
                    .setLabel('فتح التذكرة')
                    .setStyle(ButtonStyle.Primary)
                    .setDisabled(true),
                new ButtonBuilder()
                    .setCustomId('delete')
                    .setLabel('حذف التذكرة')
                    .setStyle(ButtonStyle.Danger)
                    .setDisabled(true)
            );

        await interaction.message.edit({ components: [disabledRow] });
    } else if (interaction.customId === "delete") {
        await interaction.channel.delete();
    }
});


client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;

    const guildId = interaction.guild.id;
    const userId = interaction.member.id;

    if (interaction.customId === 'order-price') {
    

            const orderEveryPriceCredit = await db.get(`order-evrypri_${guildId}`);
            const orderHerePriceCredit = await db.get(`order-herepri_${guildId}`);
            const bank = await db.get(`bank_${guildId}`);
            const imageUrl = await db.get(`buyorderimage_${guildId}`);

        const order_prices_embed = {
            title: `** أسـعـار الطـلـبـات **`,
            description: `# - اسعار الطلبات  ${interaction.guild.name} 

### أسـعـار الطـلـبـات 
${config.money}  .・ أسـعـار الطــلبـات ・. ${config.money} 
مـنـشـن ( @everyone ) :
${config.probotemoji}・السـعـر  :  ${orderEveryPriceCredit || 'غير محدد'}

مـنـشـن ( @here ) :
${config.probotemoji}・السـعـر  : ${orderHerePriceCredit || 'غير محدد'}

التـحـويـل لـ <@!${bank || 'غير محدد'}>`,
            author: {
                name: `${interaction.guild.name}`,
                icon_url: interaction.guild.iconURL({ size: 1024 }),
            },
            thumbnail: {
                url: interaction.user.displayAvatarURL(),
            },
            ...(imageUrl ? { image: { url: imageUrl } } : {}),
            footer: {
              text: `By Venlook x Ahmdfc`,
                icon_url: interaction.user.displayAvatarURL(),
            },
        };

        await interaction.reply({
            embeds: [order_prices_embed],
            ephemeral: true, // الرسالة تظهر فقط للشخص الذي ضغط
        });
    }
});






client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;

    const guildId = interaction.guild.id;
    const userId = interaction.user.id;

    // جلب البيانات من قاعدة البيانات
    const bank = await db.get(`bank_${guildId}`);
    const ordersroomId = await db.get(`orderroom_${guildId}`);

    if (interaction.customId === "every-order") {
 const evrypri = await db.get(`order-evrypri_${guildId}`);


        if (!evrypri) {
            await interaction.reply({
                content: "يرجى تحديد سعر منشن الايفري عن طريق استخدام الامر الاتي: /setup-price",
                ephemeral: true,
            });
            return;
        }

        if (!bank) {
            await interaction.reply({
                content: "يرجى تحديد البنك عن طريق استخدام الامر الاتي: /setup",
                ephemeral: true,
            });
            return;
        }

        const data = await db.get(`order_credit_${userId}_${guildId}`);
        if (data) {
            return await interaction.reply({
                content: `** يـوجد لـديـك عـمـلـيـة شــراء فـ الـوقـت الحـالـي بـ الفـعـل **`,
                ephemeral: true,
            });
        }
const orderdatauser = await db.get(`order_ticket_${interaction.member.id}_${guildId}.userId`);
    if (orderdatauser !== interaction.user.id) {
                return await interaction.reply({
                    content: `**يمكن ل صاحب التكت فقط استعمال الازرار**`,
                    ephemeral: true,
                });
            }
        try {
            const totalPrice = Math.floor(evrypri * (20 / 19) + 1);

            // إرسال السعر والتحويل
            await interaction.reply({
                content: `**يرجى التحويل  \` السعر مع الضريبة: ${totalPrice} \`**`,
                ephemeral: true
            });

            await interaction.channel.send(`#credit <@!${bank}> ${totalPrice}`);
            await interaction.channel.send( `\`\`\`#credit ${bank} ${totalPrice}\`\`\``);
            await interaction.channel.send(` . \` يرجى التحويل في أسرع وقت ممكن هنا\` <@!${userId}>`);

            await db.set(`order_credit_${userId}_${guildId}`, userId);

            const collectorFilter = (m) => m.author.bot === true;
            const collector = interaction.channel.createMessageCollector({
                filter: collectorFilter,
                time: 120000, // 2 دقائق
            });

            
collector.on('collect', async (c) => {
    // نص الرسالة الإنجليزية
    const englishTransferMessage = `:moneybag: | ${interaction.user.username}, has transferred \`$${evrypri}\` to <@!${bank}>`;

    // نص الرسالة العربية
    const arabicTransferMessage = `**ـ ${interaction.user.username}, قام بتحويل \`$${evrypri}\` لـ <@!${bank}> ** |:moneybag:`;


    if (c.content.includes(englishTransferMessage) || c.content.includes(arabicTransferMessage)) {
        collector.stop("DONE");
    }
});
collector.on("end", async (collected, reason) => {
                if (reason === "DONE") {
const ernsing = Number(evrypri);
await db.add(`ernss_${guildId}.erns`, ernsing);

await db.add(`ernsg.ernsg`, ernsing);

                    await interaction.channel.send({
                        content: `**تم التحقق من التحويل بنجاح. يرجى ارسال طلبك.**`
                    });

                    const collectorFilter = m => m.author.id === interaction.user.id;
                    const collectedMessages = await interaction.channel.awaitMessages({
                        filter: collectorFilter,
                        max: 1,
                        time: 300000,
                        errors: ['time']
                    });

                    if (collectedMessages.size > 0) {
                        const userMessage = collectedMessages.first().content;

                        const confirmRow = new ActionRowBuilder().addComponents(
                            new ButtonBuilder()
                                .setCustomId('confirm_yes')
                                .setLabel('نعم')
                                .setStyle(ButtonStyle.Success),
                            new ButtonBuilder()
                                .setCustomId('confirm_no')
                                .setLabel('لا')
                                .setStyle(ButtonStyle.Danger)
                        );

        if (userMessage.length > 100) {
            return await interaction.channel.send({
                content: `**طـلـبـك كـبـيـر قلـلـه شـوي**`,
                ephemeral: true,
            });
        }

        const linkRegex = /\b((https?:\/\/|www\.)[^\s]+(?:\.[a-z]{2,}|\/[^\s]*)?|https?:\/\/(?:discord\.gg|discord\.com\/invite|discord\.com\/channels\/[0-9]+\/[0-9]+\/[0-9]+))/gi;
        const mentionRegex = /@(everyone|here)/g;

        if (linkRegex.test(userMessage)) {
            return interaction.channel.send({
                content: `**⚠️ لا يُسمح بإضافة روابط في الطلبات.**`
            });
        }
        if (mentionRegex.test(userMessage)) {
            return interaction.channel.send({
                content: `**⚠️ لا يُسمح استخدام @ everyone و @ here في الطلبات.**`
            });
        }
                        const confirmMessage = await interaction.channel.send({
                            content: `**يرجــى التأكيد, هل تريــد نشر هاذا الــطلب؟**\n${userMessage}`,
                            components: [confirmRow]
                        });

                        const confirmFilter = (i) => i.user.id === userId;
                        const confirmCollector = confirmMessage.createMessageComponentCollector({
                            filter: confirmFilter,
                            time: 60000,
                        });

                        confirmCollector.on('collect', async (i) => {
                            if (i.customId === 'confirm_yes') {
const orderdatauser = await db.get(`order_ticket_${interaction.member.id}_${guildId}.userId`);
    if (orderdatauser !== interaction.user.id) {
                return await interaction.reply({
                    content: `**يمكن ل صاحب التكت فقط استعمال الازرار**`,
                    ephemeral: true,
                });
            }
                                const embed = {
                                    description: `**- الطلـــب : ${userMessage}\n\n- صـاحـب الطلـــب : <@${userId}>**`,
                                    footer: { text: `By: ${interaction.user.username}` },
                                };

                                const row = new ActionRowBuilder().addComponents(
                                    new ButtonBuilder()
                                        .setCustomId('order')
                                        .setLabel('شــراء طــلب')
                                        .setStyle(ButtonStyle.Secondary),
                                    new ButtonBuilder()
                                        .setCustomId('order-price')
                                        .setLabel('اســـعار الـــطلــبات')
                                        .setStyle(ButtonStyle.Secondary),
                                    new ButtonBuilder()
                                        .setLabel('صاحب الطــلب')
                                        .setStyle(ButtonStyle.Link)
                                        .setURL(`https://discord.com/users/${userId}`)
                                );

                                const ordersroom = interaction.guild.channels.cache.get(ordersroomId);
                                await ordersroom.send({
                                    content: `**طـلـب جـديـد ${config.orderemoji} @everyone**`,
                                    embeds: [embed],
                                    components: [row],
                                });

                                await i.reply({
                                    content: `**تـم نـشـر طـلـبـك بـنـجاح**`,
                                    ephemeral: true,
                                });

const guildName = interaction.guild.name;
const invoiceEmbed = new EmbedBuilder()
  .setTitle("- فاتورة الشراء -")
  .setDescription(`
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
✅ **تمت عملية الشراء بنجاح!**
  
**التفاصيل:**
- تم شـراء طلــب
- تم التحويل لـ :\n ${bank} | <@!${bank}>
- السيــرفر :\n ${interaction.guild.id} | ${guildName}
- المشتري :\n ${interaction.user} | \`${interaction.user.id}\`
- الطلــب المرســل :\n ${userMessage}
- نـوع المنــنشن : (everyone) 
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ

- السعر الاصلـي: \`${evrypri}\` ${config.money}
- الضريبة: \`${totalPrice - evrypri}\` ${config.money} 
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
- **المجموع الكلي:** \`${totalPrice}\` ${config.money}
`)

  .setFooter({ text: "شكراً لـتعاملك معنا! | By Venlook x Ahmdfc" })
  .setTimestamp();
      await interaction.user.send({ embeds: [invoiceEmbed] });


                                await interaction.channel.delete();
                                await db.delete(`order_credit_${userId}_${guildId}`);
                            } else if (i.customId === 'confirm_no') {
const orderdatauser = await db.get(`order_ticket_${interaction.member.id}_${guildId}.userId`);
    if (orderdatauser !== interaction.user.id) {
                return await interaction.reply({
                    content: `**يمكن ل صاحب التكت فقط استعمال الازرار**`,
                    ephemeral: true,
                });
            }
const disabledButton = new ActionRowBuilder().addComponents(
                            new ButtonBuilder()
                                .setCustomId('confirm_yes')
                                .setLabel('نعم')
                                .setStyle(ButtonStyle.Success)
 .setDisabled(true),
                            new ButtonBuilder()
                                .setCustomId('confirm_no')
                                .setLabel('لا')
                                .setStyle(ButtonStyle.Danger)
 .setDisabled(true)
                        );
        // تحديث الرسالة لتعطيل الزر
await i.message.edit({
            components: [disabledButton]
        });

                                
                                await i.reply({
                                    content: `**تم إلغاء النشر. يرجى إعادة إرسال الطلب.**`,
                                    ephemeral: true,
                                });

                                await interaction.channel.send({
                                    content: `**يرجى إعادة إرسال طلبك من خلال الضغط على الزر مجددًا. عندك دقــيقتين**`,
                                   
                                });

                                // هنا ننتظر إرسال الطلب الجديد
                                const newCollector = interaction.channel.createMessageCollector({
                                    filter: m => m.author.id === userId,
                                    time: 120000, // 2 دقائق
                                });

   
                                newCollector.on('collect', async (msg) => {
                                    const newUserMessage = msg.content;
   const linkRegex = /\b((https?:\/\/|www\.)[^\s]+(?:\.[a-z]{2,}|\/[^\s]*)?|https?:\/\/(?:discord\.gg|discord\.com\/invite|discord\.com\/channels\/[0-9]+\/[0-9]+\/[0-9]+))/gi;
        const mentionRegex = /@(everyone|here)/g;

        if (msg.content.length > 100) {
            return await i.reply({
                content: `**طـلـبـك كـبـيـر قلـلـه شـوي**`,
                ephemeral: true,
            });
        }

        if (linkRegex.test(msg.content)) {
            return i.reply({
                content: `**⚠️ لا يُسمح بإضافة روابط في الطلبات.**`
            });
        }
        if (mentionRegex.test(msg.content)) {
            return i.reply({
                content: `**⚠️ لا يُسمح استخدام @ everyone و @ here في الطلبات.**`
            });
        }
 
                                    // نشر الطلب الجديد في روم الطلبات
                                    const ordersroom = interaction.guild.channels.cache.get(ordersroomId);
                                    const embed = {
                                        description: `**- الطلـــب : ${newUserMessage}\n\n- صـاحـب الطلـــب : <@${userId}>**`,
                                        footer: { text: `By: ${interaction.user.username}` },
                                    };

                                    const row = new ActionRowBuilder().addComponents(
                                        new ButtonBuilder()
                                            .setCustomId('order')
                                            .setLabel('شــراء طــلب')
                                            .setStyle(ButtonStyle.Secondary),
                                        new ButtonBuilder()
                                            .setCustomId('order-price')
                                            .setLabel('اســـعار الـــطلــبات')
                                            .setStyle(ButtonStyle.Secondary),
                                        new ButtonBuilder()
                                            .setLabel('صاحب الطــلب')
                                            .setStyle(ButtonStyle.Link)
                                            .setURL(`https://discord.com/users/${userId}`)
                                    );

                                    await ordersroom.send({
                                        content: `**طـلـب جـديـد ${config.orderemoji} @everyone**`,
                                        embeds: [embed],
                                        components: [row],
                                    });

                                    // إبلاغ المستخدم بنجاح النشر
                                    await interaction.channel.send({
                                        content: `**تم نشر طلبك بنجاح في روم الطلبات.**`,
                                        ephemeral: true,
                                    });
await db.delete(`order_credit_${userId}_${guildId}`);
await interaction.channel.delete();
                                    // إغلاق الكولكليتور الجديد بعد نشر الطلب
                                    newCollector.stop();
                                });
                            }
                        });
                    } else {
                        await db.delete(`order_credit_${userId}_${guildId}`);
                        await interaction.channel.send({
                            content: `**انتهى الوقت ولم يتم التحويل.** <@!${userId}>`,
                        });
                        await interaction.channel.delete();
                    }
                }
            });
        } catch (error) {
            console.error(error);
        }
    }
});









client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;

    const guildId = interaction.guild.id;
    const userId = interaction.user.id;

    // جلب البيانات من قاعدة البيانات
    const bank = await db.get(`bank_${guildId}`);
    const ordersroomId = await db.get(`orderroom_${guildId}`);

    if (interaction.customId === "horder") {
  const herepris = await db.get(`order-herepri_${guildId}`);


        if (!herepris) {
            await interaction.reply({
                content: "يرجى تحديد سعر منشن الهير عن طريق استخدام الامر الاتي: /setup-price",
                ephemeral: true,
            });
            return;
        }

        if (!bank) {
            await interaction.reply({
                content: "يرجى تحديد البنك عن طريق استخدام الامر الاتي: /setup",
                ephemeral: true,
            });
            return;
        }

        const data = await db.get(`order_credit_${userId}_${guildId}`);
        if (data) {
            return await interaction.reply({
                content: `** يـوجد لـديـك عـمـلـيـة شــراء فـ الـوقـت الحـالـي بـ الفـعـل **`,
                ephemeral: true,
            });
        }
const orderdatauser = await db.get(`order_ticket_${interaction.member.id}_${guildId}.userId`);
    if (orderdatauser !== interaction.user.id) {
                return await interaction.reply({
                    content: `**يمكن ل صاحب التكت فقط استعمال الازرار**`,
                    ephemeral: true,
                });
            }
        try {
            const totalPrice = Math.floor(herepris * (20 / 19) + 1);

            // إرسال السعر والتحويل
            await interaction.reply({
                content: `**يرجى التحويل  \` السعر مع الضريبة: ${totalPrice} \`**`,
                ephemeral: true
            });

            await interaction.channel.send(`#credit ${bank} ${totalPrice}`);
            await interaction.channel.send( `\`\`\`#credit ${bank} ${totalPrice}\`\`\``);
            await interaction.channel.send(` . \` يرجى التحويل في أسرع وقت ممكن هنا\` <@!${userId}>`);

            await db.set(`order_credit_${userId}_${guildId}`, userId);

            const collectorFilter = (m) => m.author.bot === true;
            const collector = interaction.channel.createMessageCollector({
                filter: collectorFilter,
                time: 120000, // 2 دقائق
            });

            
collector.on('collect', async (c) => {
    // نص الرسالة الإنجليزية
    const englishTransferMessage = `:moneybag: | ${interaction.user.username}, has transferred \`$${herepris}\` to <@!${bank}>`;

    // نص الرسالة العربية
    const arabicTransferMessage = `**ـ ${interaction.user.username}, قام بتحويل \`$${herepris}\` لـ <@!${bank}> ** |:moneybag:`;


    if (c.content.includes(englishTransferMessage) || c.content.includes(arabicTransferMessage)) {
        collector.stop("DONE");
    }
});

            collector.on("end", async (collected, reason) => {
                if (reason === "DONE") {
const ernsing = Number(herepris);
await db.add(`ernss_${guildId}.erns`, ernsing);

await db.add(`ernsg.ernsg`, ernsing);

                    await interaction.channel.send({
                        content: `**تم التحقق من التحويل بنجاح. يرجى ارسال طلبك.**`
                    });

                    const collectorFilter = m => m.author.id === interaction.user.id;
                    const collectedMessages = await interaction.channel.awaitMessages({
                        filter: collectorFilter,
                        max: 1,
                        time: 300000,
                        errors: ['time']
                    });

                    if (collectedMessages.size > 0) {
                        const userMessage = collectedMessages.first().content;

                        const confirmRow = new ActionRowBuilder().addComponents(
                            new ButtonBuilder()
                                .setCustomId('confirm_yes')
                                .setLabel('نعم')
                                .setStyle(ButtonStyle.Success),
                            new ButtonBuilder()
                                .setCustomId('confirm_no')
                                .setLabel('لا')
                                .setStyle(ButtonStyle.Danger)
                        );

        if (userMessage.length > 100) {
            return await interaction.channel.send({
                content: `**طـلـبـك كـبـيـر قلـلـه شـوي**`,
                ephemeral: true,
            });
        }

        const linkRegex = /\b((https?:\/\/|www\.)[^\s]+(?:\.[a-z]{2,}|\/[^\s]*)?|https?:\/\/(?:discord\.gg|discord\.com\/invite|discord\.com\/channels\/[0-9]+\/[0-9]+\/[0-9]+))/gi;
        const mentionRegex = /@(everyone|here)/g;

        if (linkRegex.test(userMessage)) {
            return interaction.channel.send({
                content: `**⚠️ لا يُسمح بإضافة روابط في الطلبات.**`
            });
        }
        if (mentionRegex.test(userMessage)) {
            return interaction.channel.send({
                content: `**⚠️ لا يُسمح استخدام @ everyone و @ here في الطلبات.**`
            });
        }
                        const confirmMessage = await interaction.channel.send({
                            content: `**يرجــى التأكيد, هل تريــد نشر هاذا الــطلب؟**\n${userMessage}`,
                            components: [confirmRow]
                        });

                        const confirmFilter = (i) => i.user.id === userId;
                        const confirmCollector = confirmMessage.createMessageComponentCollector({
                            filter: confirmFilter,
                            time: 60000,
                        });

                        confirmCollector.on('collect', async (i) => {
                            if (i.customId === 'confirm_yes') {
const orderdatauser = await db.get(`order_ticket_${interaction.member.id}_${guildId}.userId`);
    if (orderdatauser !== interaction.user.id) {
                return await interaction.reply({
                    content: `**يمكن ل صاحب التكت فقط استعمال الازرار**`,
                    ephemeral: true,
                });
            }
                                const embed = {
                                    description: `**- الطلـــب : ${userMessage}\n\n- صـاحـب الطلـــب : <@${userId}>**`,
                                    footer: { text: `By: ${interaction.user.username}` },
                                };

                                const row = new ActionRowBuilder().addComponents(
                                    new ButtonBuilder()
                                        .setCustomId('order')
                                        .setLabel('شــراء طــلب')
                                        .setStyle(ButtonStyle.Secondary),
                                    new ButtonBuilder()
                                        .setCustomId('order-price')
                                        .setLabel('اســـعار الـــطلــبات')
                                        .setStyle(ButtonStyle.Secondary),
                                    new ButtonBuilder()
                                        .setLabel('صاحب الطــلب')
                                        .setStyle(ButtonStyle.Link)
                                        .setURL(`https://discord.com/users/${userId}`)
                                );

                                const ordersroom = interaction.guild.channels.cache.get(ordersroomId);
                                await ordersroom.send({
                                    content: `**طـلـب جـديـد ${config.orderemoji} @here**`,
                                    embeds: [embed],
                                    components: [row],
                                });

                                await i.reply({
                                    content: `**تـم نـشـر طـلـبـك بـنـجاح**`,
                                    ephemeral: true,
                                });

                                await interaction.channel.delete();
                                await db.delete(`order_credit_${userId}`);
                            } else if (i.customId === 'confirm_no') {
const orderdatauser = await db.get(`order_ticket_${interaction.member.id}_${guildId}.userId`);
    if (orderdatauser !== interaction.user.id) {
                return await interaction.reply({
                    content: `**يمكن ل صاحب التكت فقط استعمال الازرار**`,
                    ephemeral: true,
                });
            }
const disabledButton = new ActionRowBuilder().addComponents(
                            new ButtonBuilder()
                                .setCustomId('confirm_yes')
                                .setLabel('نعم')
                                .setStyle(ButtonStyle.Success)
 .setDisabled(true),
                            new ButtonBuilder()
                                .setCustomId('confirm_no')
                                .setLabel('لا')
                                .setStyle(ButtonStyle.Danger)
 .setDisabled(true)
                        );
        // تحديث الرسالة لتعطيل الزر
await i.message.edit({
            components: [disabledButton]
        });

                                
                                await i.reply({
                                    content: `**تم إلغاء النشر. يرجى إعادة إرسال الطلب.**`,
                                    ephemeral: true,
                                });

                                await interaction.channel.send({
                                    content: `**يرجى إعادة إرسال طلبك من خلال الضغط على الزر مجددًا. عندك دقــيقتين**`,
                                   
                                });

                                // هنا ننتظر إرسال الطلب الجديد
                                const newCollector = interaction.channel.createMessageCollector({
                                    filter: m => m.author.id === userId,
                                    time: 120000, // 2 دقائق
                                });

   
                                newCollector.on('collect', async (msg) => {
                                    const newUserMessage = msg.content;
   const linkRegex = /\b((https?:\/\/|www\.)[^\s]+(?:\.[a-z]{2,}|\/[^\s]*)?|https?:\/\/(?:discord\.gg|discord\.com\/invite|discord\.com\/channels\/[0-9]+\/[0-9]+\/[0-9]+))/gi;
        const mentionRegex = /@(everyone|here)/g;

        if (msg.content.length > 100) {
            return await i.reply({
                content: `**طـلـبـك كـبـيـر قلـلـه شـوي**`,
                ephemeral: true,
            });
        }

        if (linkRegex.test(msg.content)) {
            return i.reply({
                content: `**⚠️ لا يُسمح بإضافة روابط في الطلبات.**`
            });
        }
        if (mentionRegex.test(msg.content)) {
            return i.reply({
                content: `**⚠️ لا يُسمح استخدام @ everyone و @ here في الطلبات.**`
            });
        }
 
                                    // نشر الطلب الجديد في روم الطلبات
                                    const ordersroom = interaction.guild.channels.cache.get(ordersroomId);
                                    const embed = {
                                        description: `**- الطلـــب : ${newUserMessage}\n\n- صـاحـب الطلـــب : <@${userId}>**`,
                                        footer: { text: `By: ${interaction.user.username}` },
                                    };

                                    const row = new ActionRowBuilder().addComponents(
                                        new ButtonBuilder()
                                            .setCustomId('order')
                                            .setLabel('شــراء طــلب')
                                            .setStyle(ButtonStyle.Secondary),
                                        new ButtonBuilder()
                                            .setCustomId('order-price')
                                            .setLabel('اســـعار الـــطلــبات')
                                            .setStyle(ButtonStyle.Secondary),
                                        new ButtonBuilder()
                                            .setLabel('صاحب الطــلب')
                                            .setStyle(ButtonStyle.Link)
                                            .setURL(`https://discord.com/users/${userId}`)
                                    );

                                    await ordersroom.send({
                                        content: `**طـلـب جـديـد ${config.orderemoji} @here**`,
                                        embeds: [embed],
                                        components: [row],
                                    });

                                    // إبلاغ المستخدم بنجاح النشر
                                    await interaction.channel.send({
                                        content: `**تم نشر طلبك بنجاح في روم الطلبات.**`,
                                        ephemeral: true,
                                    });

const guildName = interaction.guild.name;
const invoiceEmbed = new EmbedBuilder()
  .setTitle("- فاتورة الشراء -")
  .setDescription(`
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
✅ **تمت عملية الشراء بنجاح!**
  
**التفاصيل:**
- تم شـراء طلــب
- تم التحويل لـ :\n ${bank} | <@!${bank}>
- السيــرفر :\n ${interaction.guild.id} | ${guildName}
- المشتري :\n ${interaction.user} | \`${interaction.user.id}\`
- الطلــب المرســل :\n ${userMessage}
- نـوع المنــنشن : (here) 
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ

- السعر الاصلـي: \`${herepris}\` ${config.money}
- الضريبة: \`${totalPrice - herepris}\` ${config.money} 
ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ
- **المجموع الكلي:** \`${totalPrice}\` ${config.money}
`)

  .setFooter({ text: "شكراً لـتعاملك معنا! | By Venlook x Ahmdfc" })
  .setTimestamp();
      await interaction.user.send({ embeds: [invoiceEmbed] });


await db.delete(`order_credit_${userId}`);
await interaction.channel.delete();
                                    // إغلاق الكولكليتور الجديد بعد نشر الطلب
                                    newCollector.stop();
                                });
                            }
                        });
                    } else {
                        await db.delete(`order_credit_${userId}_${guildId}`);
                        await interaction.channel.send({
                            content: `**انتهى الوقت ولم يتم التحويل.** <@!${userId}>`,
                        });
                        await interaction.channel.delete();
                    }
                }
            });
        } catch (error) {
            console.error(error);
        }
    }
});







client.on('messageCreate', async (message) => {
    if (message.author.bot) return;

    // التحقق من البلاك لست
    const blacklist = await db.get('blacklist') || [];
    if (blacklist.includes(message.author.id)) {
        return message.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
    }

const guildId = message.guild.id;

    const { content } = message;
    const shortcut = (await db.get(`shortcut_createshop_${guildId}`)) || '+انشاء-متجر';
const firstWord = content.trim().split(" ")[0];
if (firstWord !== shortcut) return;

const { member} = message;
  const admins = await db.get(`shopad_${guildId}`);
    if (!admins) {
        await message.reply({
            content: "يرجى تحديد الادمن عن طريق استخدام الامر الاتي: /setup",
        });
        return;
    }

    if (!member.roles.cache.has(admins)) {
        await message.reply({
 content:`لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر تـحـتـاج رتـبـه <@&${admins}>`, ephemeral: true});
        return;
    }
// استخراج المستخدم الذي تم منشنه
const mentionedUser = message.mentions.users.first();
if (!mentionedUser) {
    return message.reply('❌ **يرجى منشن صاحب المتجر.**');
}

// استخراج اسم المتجر بعد المنشن
const args = message.content.split(" ").slice(2); // بعد "+اضافة-متجر-للداتا @منشن"
const shopName = args.join(" "); 

if (!shopName) { 
    return message.reply('❌ **يرجى إدخال اسم المتجر بعد المنشن.**'); 
}

    const sellerId = mentionedUser.id;

    // جلب أنواع المتاجر من السيرفر
    const guild = message.guild;
    const categories = guild.channels.cache.filter(channel => channel.type === ChannelType.GuildCategory);

    if (!categories.size) {
        return message.reply({ content: `**لا يوجد كاتيجوري في هذا السيرفر**`, ephemeral: true });
    }

    // إنشاء أزرار لأنواع المتاجر
    const buttons = [];
    for (const [categoryId, category] of categories) {
        const categoryDataKey = `categoryMentions_${categoryId}_${guildId}`;
        const categoryData = await db.get(categoryDataKey);

        if (!categoryData) continue;

         buttons.push(
            { label: String(category.name).slice(0, 100), value: `select_shop_create_${categoryId}` }
        );
    }

    // تقسيم الأزرار إلى صفحات إذا كان عددها أكثر من 5
    const pages = [];
    for (let i = 0; i < buttons.length; i += 5) {
        pages.push(buttons.slice(i, i + 5));
    }

    let currentPage = 0;

    // إنشاء الرسالة مع الأزرار
    const row = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
            .setCustomId('shop_create_select')
            .setPlaceholder('اختر نوع المتجر')
            .addOptions(buttons.slice(0, 25))
    );
    const embed = new EmbedBuilder()
        .setTitle('اختر نوع المتجر')
        .setDescription('يرجى اختيار نوع المتجر من القائمة أدناه.')
        .setFooter({ text: `الصفحة ${currentPage + 1} من ${pages.length}` });

    const replyMessage = await message.reply({ embeds: [embed], components: [row] });

    // إنشاء Collector لجمع التفاعلات
    const filter = (interaction) => interaction.user.id === message.author.id;
    const collector = replyMessage.createMessageComponentCollector({ filter, time: 60000 });

    collector.on('collect', async (interaction) => {
        if (interaction.customId.startsWith('select_shop_create_')) {

    if (!member.roles.cache.has(admins)) {
        await message.reply({
 content:`لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر تـحـتـاج رتـبـه <@&${admins}>`, ephemeral: true});
        return;
    }
            const categoryId = interaction.customId.split('_')[3];

            const categoryData = await db.get(`categoryMentions_${categoryId}_${guildId}`);
            const pirefix = categoryData.pirefix;
            if (!categoryData) {
                return interaction.reply({ content: '❌ **حدث خطأ أثناء جلب بيانات المتجر.**', ephemeral: true });
            }


     const name = shopName.replaceAll(' ', '・');
            // إنشاء المتجر وإضافته إلى البيانات
            const channel = await guild.channels.create({
                name: `${pirefix}${name}`,
                type: ChannelType.GuildText,
                parent: categoryId,
                permissionOverwrites: [
                    {
                        id: guild.id,
                        deny: [
                            PermissionFlagsBits.SendMessages,
                            PermissionFlagsBits.AddReactions,
                            PermissionFlagsBits.CreatePublicThreads,
                            PermissionFlagsBits.CreatePrivateThreads,
                            PermissionFlagsBits.AttachFiles,
                            PermissionFlagsBits.EmbedLinks,

                        ],
                    },
                    {
                        id: sellerId,
                        allow: [
             		        PermissionFlagsBits.ViewChannel,
                            PermissionFlagsBits.SendMessages,
                            PermissionFlagsBits.AddReactions,
                            PermissionFlagsBits.AttachFiles,
                            PermissionFlagsBits.MentionEveryone,
                            PermissionFlagsBits.EmbedLinks,
                            PermissionFlagsBits.UseExternalEmojis,
                            PermissionFlagsBits.ReadMessageHistory,
                        ],
                    },
 {
        id: admins,
        allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.AddReactions,
            PermissionFlagsBits.AttachFiles,
            PermissionFlagsBits.MentionEveryone,
            PermissionFlagsBits.EmbedLinks,
            PermissionFlagsBits.UseExternalEmojis,
            PermissionFlagsBits.ReadMessageHistory,
        ],
    },
                ],
            });

            const datecreated = `<t:${parseInt(Date.now() / 1000)}:R>`;
            const ob = {
                channelId: channel.id,
                categoryId: categoryId,
                sellerId: sellerId,
                everyoneMentions: categoryData.everyoneMentions,
                hereMentions: categoryData.hereMentions,
                shopmen: categoryData.shopmen,
                shoprole: categoryData.shoprole,
                shopRoleMentions: categoryData.shopRoleMentions,
                maxWarns: categoryData.maxWarns,
                date: datecreated,
                taxPrice: categoryData.taxPrice,
                hasTax: categoryData.hasTax,
                nametype: categoryData.nametype,
          pirefix: pirefix,
          shopname: shopName
            };

            await db.set(`shop_${channel.id}_${guildId}`, ob);
  await db.set(`shop_${channel.id}_${guildId}.warns`, "0")
            await db.set(`shop_${channel.id}_${guildId}.status`, "1");
    const seller = await guild.members.fetch(sellerId);
                await seller.roles.add(categoryData.shoprole);
              
            // إرسال رسالة تأكيد
            const em5 = new EmbedBuilder()
                .setTitle('**تم انشاء متجر : **')
                .setDescription(` **
> ${config.wahitsprkle}  \﹣\ المـتـجـر : ${channel}
> 
> ${config.wahitsprkle}  \﹣\ صـاحـب المـتـجـر : <@${sellerId}>
> 
> ${config.wahitsprkle}  \﹣\ نـوع المـتـجر : ${categoryData.nametype || 'لم يتم العثور عليه'}
> 
> ${config.wahitsprkle}  \﹣\ رتبة هاذا النوع  : <@&${categoryData.shoprole || 'لم يتم العثور عليه'}> 
> 
> ${config.wahitsprkle}  \﹣\ اقصى عدد للتحذيرات : ${categoryData.maxWarns || 'غير محدد'}
> 
> ${config.wahitsprkle}  \﹣\ بضريبه؟ : ${categoryData.hasTax === true ? 'نعم' : categoryData.hasTax === false ? 'لا' : 'غير محدد'}
**`)
                .setAuthor({ name: guild.name, iconURL: guild.iconURL({ size: 1024 }) })
                .setFooter({ text: 'By Venlook x Ahmdfc' })
                .setTimestamp()
                .setThumbnail(guild.iconURL({ size: 1024 }));

            await channel.send({ embeds: [em5], allowedMentions: { parse: [] } });
        // تعطيل الأزرار
const disabledButtons = [new StringSelectMenuBuilder().setCustomId('shop_typedata_select').setPlaceholder('اختر نوع المتجر').setDisabled(true).addOptions(buttons.slice(0, 25))];
const disabledRow = new ActionRowBuilder().addComponents(disabledButtons);

// تعديل الرسالة الأصلية لتعطيل الأزرار
collector.stop();
await interaction.update({ content: `**تم انشاء المتجر** ${channel} <@${sellerId}>`, embeds: [], components: [], allowedMentions: { parse: [] } });

  const logs = await db.get(`logs_${guildId}`);
if (logs) {
    const logg = guild.channels.cache.get(logs);
    if (logg) {
        await logg.send({ embeds: [em5], allowedMentions: { parse: [] } });
    }
}

          
        }
    });

collector.on('end', async (_, reason) => {
    // تعطيل الأزرار عند انتهاء الوقت
    const disabledButtons = [new StringSelectMenuBuilder().setCustomId('shop_typedata_select').setPlaceholder('اختر نوع المتجر').setDisabled(true).addOptions(buttons.slice(0, 25))];
    const disabledRow = new ActionRowBuilder().addComponents(disabledButtons);

    await replyMessage.edit({ components: [disabledRow] });

    if (reason === 'time') {
        message.reply('❌ **انتهى الوقت لاختيار النوع.**');
    }
});

});

client.on('messageCreate', async (message) => {
    if (message.author.bot) return;

    // التحقق من البلاك لست
    const blacklist = await db.get('blacklist') || [];
    if (blacklist.includes(message.author.id)) {
        return message.reply('**أنت في البلاك لست، لمعلومات اكثر تعال سيرفر السبورت!**');
    }
const guildId = message.guild.id;

   
    const { content } = message;
    const shortcut = (await db.get(`shortcut_addshopdata_${guildId}`)) || '+اضافة-متجر-للداتا';
const firstWord = content.trim().split(" ")[0];
if (firstWord !== shortcut) return;

const { member} = message;
  const admins = await db.get(`shopad_${guildId}`);
    if (!admins) {
        await message.reply({
            content: "يرجى تحديد الادمن عن طريق استخدام الامر الاتي: /setup", ephemeral: true
        });
        return;
    }

    if (!member.roles.cache.has(admins)) {
        await message.reply({
            content:`لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر تـحـتـاج رتـبـه <@&${admins}>`, ephemeral: true});
        return;
    }

    // استخراج المستخدم الذي تم منشنه
    const mentionedUser = message.mentions.users.first();
    if (!mentionedUser) {
        return message.reply('❌ **يرجى منشن صاحب المتجر.**');
    }

    const sellerId = mentionedUser.id;

    // جلب أنواع المتاجر من السيرفر
    const guild = message.guild;
    const categories = guild.channels.cache.filter(channel => channel.type === ChannelType.GuildCategory);

    if (!categories.size) {
        return message.reply({ content: `**لا يوجد كاتيجوري في هذا السيرفر**`, ephemeral: true });
    }

    // إنشاء أزرار لأنواع المتاجر
    const buttons = [];
    for (const [categoryId, category] of categories) {
        const categoryDataKey = `categoryMentions_${categoryId}_${guildId}`;
        const categoryData = await db.get(categoryDataKey);

        if (!categoryData) continue;

        buttons.push(
            { label: String(category.name).slice(0, 100), value: `select_shoptypedata_${categoryId}` }
        );
    }

    // تقسيم الأزرار إلى صفحات إذا كان عددها أكثر من 5
    const pages = [];
    for (let i = 0; i < buttons.length; i += 5) {
        pages.push(buttons.slice(i, i + 5));
    }

    let currentPage = 0;

    // إنشاء الرسالة مع الأزرار
    const row = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
            .setCustomId('shop_typedata_select')
            .setPlaceholder('اختر نوع المتجر')
            .addOptions(buttons.slice(0, 25))
    );
    const embed = new EmbedBuilder()
        .setTitle('اختر نوع المتجر')
        .setDescription('يرجى اختيار نوع المتجر من القائمة أدناه.')
        .setFooter({ text: `الصفحة ${currentPage + 1} من ${pages.length}` });

    const replyMessage = await message.reply({ embeds: [embed], components: [row] });

    // إنشاء Collector لجمع التفاعلات
    const filter = (interaction) => interaction.user.id === message.author.id;
    const collector = replyMessage.createMessageComponentCollector({ filter, time: 60000 });

    collector.on('collect', async (interaction) => {
        if (interaction.customId.startsWith('select_shoptypedata_')) {

    if (!member.roles.cache.has(admins)) {
        await message.reply({
 content:`لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر تـحـتـاج رتـبـه <@&${admins}>`, ephemeral: true});
        return;
    }
            const categoryId = interaction.customId.split('_')[2];
            const categoryData = await db.get(`categoryMentions_${categoryId}_${guildId}`);

            if (!categoryData) {
                return interaction.reply({ content: '❌ **حدث خطأ أثناء جلب بيانات المتجر.**', ephemeral: true });
            }

         
            const shop = await interaction.channel.edit({
        permissionOverwrites: [
            {
                id: interaction.guild.id, // أذونات للجميع
                deny: [
                    PermissionFlagsBits.SendMessages,
                    PermissionFlagsBits.AddReactions,
                    PermissionFlagsBits.CreatePublicThreads,
                    PermissionFlagsBits.CreatePrivateThreads,
                    PermissionFlagsBits.AttachFiles,
                    PermissionFlagsBits.EmbedLinks,
                ],
            },
            {
                id: sellerId, // أذونات للبائع
                allow: [
                    PermissionFlagsBits.ViewChannel,
                    PermissionFlagsBits.SendMessages,
                    PermissionFlagsBits.AddReactions,
                    PermissionFlagsBits.AttachFiles,
                    PermissionFlagsBits.MentionEveryone,
                    PermissionFlagsBits.EmbedLinks,
                    PermissionFlagsBits.UseExternalEmojis,
                    PermissionFlagsBits.ReadMessageHistory,
                ],
            },
            {
                id: admins, // أذونات للمشرفين
                allow: [
                    PermissionFlagsBits.ViewChannel,
                    PermissionFlagsBits.SendMessages,
                    PermissionFlagsBits.AddReactions,
                    PermissionFlagsBits.AttachFiles,
                    PermissionFlagsBits.MentionEveryone,
                    PermissionFlagsBits.EmbedLinks,
                    PermissionFlagsBits.UseExternalEmojis,
                    PermissionFlagsBits.ReadMessageHistory,
                ],
            },
        ],
    });


            const datecreated = `<t:${parseInt(Date.now() / 1000)}:R>`;
            const ob = {
                channelId: interaction.channel.id,
                categoryId: categoryId,
                sellerId: sellerId,
                everyoneMentions: categoryData.everyoneMentions,
                hereMentions: categoryData.hereMentions,
                shopmen: categoryData.shopmen,
                shoprole: categoryData.shoprole,
                shopRoleMentions: categoryData.shopRoleMentions,
                maxWarns: categoryData.maxWarns,
                date: datecreated,
                taxPrice: categoryData.taxPrice,
                hasTax: categoryData.hasTax,
                nametype: categoryData.nametype,
                pirefix: categoryData.pirefix,
                shopname: interaction.channel.name
            };

            await db.set(`shop_${interaction.channel.id}_${guildId}`, ob);
  await db.set(`shop_${interaction.channel.id}_${guildId}.warns`, "0")
            await db.set(`shop_${interaction.channel.id}_${guildId}.status`, "1");
    const seller = await guild.members.fetch(sellerId);
                await seller.roles.add(categoryData.shoprole);
          
            // إرسال رسالة تأكيد
            const em5 = new EmbedBuilder()
                .setTitle('**تم اضافة متجر : **')
                .setDescription(` **
> ${config.wahitsprkle}  \﹣\ المـتـجـر : ${interaction.channel}
> 
> ${config.wahitsprkle}  \﹣\ صـاحـب المـتـجـر : <@${sellerId}>
> 
> ${config.wahitsprkle}  \﹣\ نـوع المـتـجر : ${categoryData.nametype || 'لم يتم العثور عليه'}
> 
> ${config.wahitsprkle}  \﹣\ رتبة هاذا النوع  : <@&${categoryData.shoprole || 'لم يتم العثور عليه'}> 
> 
> ${config.wahitsprkle}  \﹣\ اقصى عدد للتحذيرات : ${categoryData.maxWarns || 'غير محدد'}
> 
> ${config.wahitsprkle}  \﹣\ بضريبه؟ : ${categoryData.hasTax === true ? 'نعم' : categoryData.hasTax === false ? 'لا' : 'غير محدد'}
**`)
                .setAuthor({ name: guild.name, iconURL: guild.iconURL({ size: 1024 }) })
                .setFooter({ text: 'By Venlook x Ahmdfc' })
                .setTimestamp()
                .setThumbnail(guild.iconURL({ size: 1024 }));

            await interaction.channel.send({ embeds: [em5], allowedMentions: { parse: [] } });
        // تعطيل الأزرار
const disabledButtons = [new StringSelectMenuBuilder().setCustomId('shop_typedata_select').setPlaceholder('اختر نوع المتجر').setDisabled(true).addOptions(buttons.slice(0, 25))];
const disabledRow = new ActionRowBuilder().addComponents(disabledButtons);

// تعديل الرسالة الأصلية لتعطيل الأزرار
collector.stop();
await interaction.update({ content: `**تم انشاء المتجر** ${interaction.channel} <@${sellerId}>`, embeds: [], components: [], allowedMentions: { parse: [] } });

const logs = await db.get(`logs_${guildId}`);
if (logs) {
    const logg = guild.channels.cache.get(logs);
    if (logg) {
        await logg.send({ embeds: [em5], allowedMentions: { parse: [] } });
    }
}

            
        }
    });
collector.on('end', async (_, reason) => {
    // تعطيل الأزرار عند انتهاء الوقت
    const disabledButtons = [new StringSelectMenuBuilder().setCustomId('shop_typedata_select').setPlaceholder('اختر نوع المتجر').setDisabled(true).addOptions(buttons.slice(0, 25))];
    const disabledRow = new ActionRowBuilder().addComponents(disabledButtons);

    await replyMessage.edit({ components: [disabledRow] });

    if (reason === 'time') {
        message.reply('❌ **انتهى الوقت لاختيار النوع.**');
    }
});

});




client.on('messageCreate', async (message) => {
    if (message.author.bot) return;  // تجاهل الرسائل المرسلة من البوتات
    const guildId = message.guild.id;  // الحصول على معرف السيرفر
    const { member, content, channel } = message;  // الحصول على العضو والمحتوى والقناة
    const admins = await db.get(`shopad_${guildId}`);  // جلب بيانات الأدمن
    const shortcut = (await db.get(`shortcut_warning_${guildId}` || '+تحذير'));

    if (content.startsWith(shortcut)) {
        const reason = content.slice(shortcut.length).trim(); // استخراج النص بعد الاختصار

        if (!reason) {
            return message.reply(`❌ **يرجى تحديد السبب بعد كلمة ${shortcut}.**`);
        }

        // استخدام القناة الحالية كالمتجر
        const shop = channel;
        const data = await db.get(`shop_${shop.id}_${guildId}`);  // جلب بيانات المتجر
		const currentWarns = Number(data?.warns) || 0; 

        if (!admins) {
            return message.reply("يرجى تحديد الأدمن عن طريق استخدام الأمر: /setup");
        }

        if (!member.roles.cache.has(admins)) {
            return message.reply(`ليس لديك صلاحية لاستخدام هذا الأمر. تحتاج رتبة <@&${admins}>`);
        } 

        // تحقق من بيانات المتجر
        if (!data) {
            return message.reply("هذه الروم ليس مســجل كـ متجر");
        }

        // تحديث عدد التحذيرات
        const amount = 1;
        let updatedWarns;

if (currentWarns === 0) {
    await db.set(`shop_${shop.id}_${guildId}.warns`, 1);
    updatedWarns = 1;
} else {
    updatedWarns = currentWarns + 1;
    await db.set(`shop_${shop.id}_${guildId}.warns`, updatedWarns);  

        // إنشاء الإيمبد لإرسال التحذير
        const warningEmbed = new EmbedBuilder()
            .setTitle(`**تم تحذير المتجر ${shop} ${config.whaitshop}**`)
            .setDescription(`${config.warn} اسـتـبـيـان تحـذيـر المـتـاجـر`)
            .addFields(
                { name: `صـاحب الـمـتجــر ${config.whaitshop}`, value: `<@${data.sellerId}>`, inline: true },
                { name: `عـدد تـحذيـرات الـمتجـر ${config.whaitshop}`, value: `${updatedWarns}`, inline: true },
                { name: `سـبب تحـذير الــمتجر ${config.whaitshop}`, value: `${reason}`, inline: true },
                { name: `المــسؤول ${config.whaitshop}`, value: `<@${member.id}>`, inline: true }
            )
            .setTimestamp();

        // إرسال الإيمبد في القناة المتجر
        await shop.send({ embeds: [warningEmbed] });

        // إرسال الإيمبد في السجلات إذا كانت موجودة
        const logsChannelId = await db.get(`logs_${guildId}`);
        if (logsChannelId) {
            const logsChannel = await message.guild.channels.fetch(logsChannelId).catch(() => null);
            if (logsChannel) {
                await logsChannel.send({ embeds: [warningEmbed] });
            }
        }

        // الرد على المستخدم
        await message.reply({
            content: `✅ **تم إضافة ${amount} تحذير للمتجر ${shop}\nعدد التحذيرات الآن: ${updatedWarns}\nسبب التحذير: ${reason}**`,
        });
    }
}
});
client.on('messageCreate', async (message) => {
    if (message.author.bot) return; // تجاهل الرسائل المرسلة من البوتات

    const guildId = message.guild.id;
    const { member, content, channel, guild } = message;

    // جلب بيانات الأدمن واختصار الحذف
    const admins = await db.get(`shopad_${guildId}`);
    const shortcut = (await db.get(`shortcut_delete_${guildId}`)) || '+حذف';

    // تعديل الشرط للتحقق من الاختصار متبوعًا بمسافة
    if (content.startsWith(shortcut + ' ') || content === shortcut) {
        let reason;
        if (content === shortcut) {
            reason = ''; // إذا كانت الرسالة فقط الاختصار بدون سبب
        } else {
            reason = content.slice(shortcut.length + 1).trim(); // استخراج السبب بعد المسافة
        }

        if (!reason) {
            return message.reply(`❌ **يرجى تحديد السبب بعد كلمة ${shortcut}.**`);
        }

        // تحقق من صلاحيات المستخدم
        if (!admins) {
            return message.reply("❌ يرجى تحديد الأدمن عن طريق استخدام الأمر: /setup");
        }

        if (!member.roles.cache.has(admins)) {
            return message.reply(`❌ ليس لديك صلاحية لاستخدام هذا الأمر. تحتاج رتبة <@&${admins}>.`);
        }

        // جلب بيانات المتجر من القناة الحالية
        const shopData = await db.get(`shop_${channel.id}_${guildId}`);
        if (!shopData) {
            return message.reply("❌ هذه القناة ليست مسجلة كمتجر.");
        }

        const shopChannel = channel; // القناة الحالية
        const logChannelId = await db.get(`logs_${guildId}`);
        const logChannel = logChannelId ? guild.channels.cache.get(logChannelId) : null;
        const imageUrl = await db.get(`image_${guildId}`) || null;

        // إنشاء رسالة التنبيه
        const deletedShopEmbed = new EmbedBuilder()
        .setTitle('تم حذف متجرك')
        .setDescription(`تم حذف متجرك ${shopChannel.name}`)
        .addFields(
            { name: `${config.whaitshop} **المتجر**`, value: shopChannel.name, inline: true },
            { name: `${config.whaitshop} **صاحب المتجر**`, value: `<@${shopData.sellerId}>`, inline: true },
            { name: `${config.whaitshop} **المسؤول**`, value: `<@${member.id}>`, inline: true },
            { name: 'السبب', value: reason, inline: true }
        )
        .setImage(imageUrl || config.line)
        .setFooter({ text: 'By Venlook x Ahmdfc' })
        .setTimestamp();

        const deletedShopEmbedlogs = new EmbedBuilder()
        .setTitle('تم حذف متجر')
        .setDescription(`تم حذف متجر ${shopChannel.name}`)
        .addFields(
            { name: `${config.whaitshop} **المتجر**`, value: shopChannel.name, inline: true },
            { name: `${config.whaitshop}**صاحب المتجر**`, value: `<@${shopData.sellerId}>`, inline: true },
            { name: `${config.whaitshop} **المسؤول**`, value: `<@${member.id}>`, inline: true },
            { name: 'السبب', value: reason, inline: true }
        )
        .setImage(imageUrl || config.line)
        .setFooter({ text: 'By Venlook x Ahmdfc' })
        .setTimestamp();


        // إرسال إشعار للبائع
        try {
            const seller = await client.users.fetch(shopData.sellerId);
            const dmChannel = await seller.createDM();
            await dmChannel.send({ embeds: [deletedShopEmbed] });
        } catch (error) {
            console.error(`⚠️ Failed to notify the seller: ${error.message}`);
        }

        // إرسال السجل إلى قناة السجلات
        if (logChannel) {
            await logChannel.send({ embeds: [deletedShopEmbedlogs] });
        }

        // حذف بيانات المتجر من قاعدة البيانات
        await db.delete(`shop_${channel.id}_${guildId}`);

        // حذف القناة
        try {
            await shopChannel.delete();
        } catch (error) {
            console.error(`⚠️ Failed to delete the shop channel: ${error.message}`);
        }

        // إزالة دور البائع إذا كان موجودًا
        if (shopData.shoprole) {
            try {
                const sellerMember = await guild.members.fetch(shopData.sellerId);
                await sellerMember.roles.remove(shopData.shoprole);
            } catch (error) {
                console.error(`⚠️ Failed to remove the role from the seller: ${error.message}`);
            }
        }

    //    message.reply('✅ **تم حذف المتجر بنجاح!**');
    }
});


client.on('messageCreate', async (message) => {
    if (message.author.bot) return; // تجاهل الرسائل المرسلة من البوتات

    const guildId = message.guild.id;
    const { content } = message;

    const shortcut = (await db.get(`shortcut_setshopowner_${guildId}`)) || '+تحديد-صاحب-المتجر';
    
    // التحقق من أن الرسالة تبدأ بالاختصار متبوعًا بمسافة أو أنها الاختصار فقط
    if (!(content.startsWith(shortcut + ' ') || content === shortcut)) return;

    // استخراج الجزء المتبقي من الرسالة (بعد الاختصار والمسافة)
    const args = content.slice(shortcut.length).trim();
    
    // استخراج المستخدم الذي تم منشنه
    const mention = message.mentions.members.first();
    if (!mention) {
        await message.reply('❌ يرجى منشن المستخدم لتحديده كصاحب جديد للمتجر.');
        return;
    }

    const newOwner = mention;
    const shopId = message.channel.id; // افترض أن المتجر هو القناة الحالية

    try {
        // التأكد أن القناة هي متجر
        const shopData = await db.get(`shop_${shopId}_${guildId}`);
        if (!shopData) {
            await message.reply('❌ هـذة الـقـنـاة لـيـست مـتـجـرًا.');
            return;
        }

        // تحديث الأذونات للمالك الجديد
        await message.channel.permissionOverwrites.edit(newOwner.id, {
            ViewChannel: true,
            SendMessages: true,
            EmbedLinks: true,
            MentionEveryone: true,
            AttachFiles: true
        });

        // تحديث قاعدة البيانات مباشرة
        await db.set(`shop_${shopId}_${guildId}.sellerId`, newOwner.id);

        // إرسال تأكيد للمستخدم
        await message.reply(`✅ تـم تـحـديـد صـاحـب الـمـتـجـر إلـى: <@${newOwner.id}>.`);

        // إرسال رسالة إلى قناة السجلات
        const logsChannelId = await db.get(`logs_${guildId}`);
        const logsChannel = message.guild.channels.cache.get(logsChannelId);

        if (logsChannel) {
            const transferEmbed = new EmbedBuilder()
                .setTitle('تحديد صاحب المتجر')
                .setDescription(`تـم تـحـديـد صـاحـب مـتـجـر بـنـجـاح.`)
                .addFields(
                    { name: 'صاحب المتجر الجديد', value: `<@${newOwner.id}>`, inline: true },
                    { name: 'المسؤول', value: `<@${message.author.id}>`, inline: true },
                    { name: 'تاريخ التحديد', value: new Date().toLocaleString(), inline: true },
                    { name: 'اسم المتجر', value: message.channel.name, inline: true }
                );

            await logsChannel.send({ embeds: [transferEmbed] });
        }
    } catch (error) {
        console.error('Error setting shop owner:', error);
        await message.reply('❌ حـدثـت مـشـكـلـة مـا أثـنـاء تـحـديـد صـاحـب الـمـتـجـر.');
    }
});


client.on('messageCreate', async (message) => {
    if (message.author.bot) return; // تجاهل الرسائل المرسلة من البوتات

    const guildId = message.guild.id;
    const channelId = message.channel.id;
    const { member, content } = message;

    const shortcut = (await db.get(`shortcut_addmentions_${guildId}`)) || '+اضافة-منشنات';
const shortcutRegex = new RegExp(`/^\s${shortcut}\s/`);
if (!shortcutRegex.test(content)) return;


    // استخراج العدد من الرسالة حتى لو كان هناك مسافات كثيرة
    const countMatch = content.replace(shortcut, '').trim();
    const count = parseInt(countMatch, 10);

    if (isNaN(count) || count <= 0) {
        return message.reply('❌ **يرجى تحديد العدد بعد استخدام الأمر!**');
    }

    if (count > 999) {
        return message.reply('❌ **لا يمكنك إضافة أكثر من 999 منشن دفعة واحدة!**');
    }

    const admins = await db.get(`shopad_${guildId}`);

    if (!admins) {
        return message.reply('❌ **يرجى تحديد الأدمن عن طريق استخدام الأمر: /setup**');
    }

    if (!member.roles.cache.has(admins)) {
        return message.reply(`❌ **ليس لديك صلاحية لإستخدام هذا الأمر. تحتاج رتبة <@&${admins}>**`);
    }

    const data = await db.get(`shop_${channelId}_${guildId}`);

    if (!data) {
        return message.reply('❌ **لا يمكنني العثور على هذا المتجر!**');
    }

    // إرسال الأزرار
    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('add-everyone')
                .setLabel('Everyone')
                .setStyle(ButtonStyle.Secondary),

            new ButtonBuilder()
                .setCustomId('add-here')
                .setLabel('Here')
                .setStyle(ButtonStyle.Secondary),

            new ButtonBuilder()
                .setCustomId('add-shop')
                .setLabel('Shop Role')
                .setStyle(ButtonStyle.Secondary)
        );

    const msg = await message.reply({
        content: '❓ **اختر نوع المنشن الذي تريد إضافته:**',
        components: [row]
    });

    // انتظار تفاعل المستخدم
    const filter = (i) => i.user.id === message.author.id;
    const collector = msg.createMessageComponentCollector({ filter, time: 30000 });

    collector.on('collect', async (interaction) => {
        const mentionStyle = interaction.customId;

        if (mentionStyle === 'add-everyone') {
            await db.add(`shop_${channelId}_${guildId}.everyoneMentions`, count);
        } else if (mentionStyle === 'add-here') {
            await db.add(`shop_${channelId}_${guildId}.hereMentions`, count);
        } else if (mentionStyle === 'add-shop') {
            await db.add(`shop_${channelId}_${guildId}.shopRoleMentions`, count);
        }

        // تعطيل الأزرار
        const disabledRow = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('add-everyone')
                    .setLabel('Everyone')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(true),

                new ButtonBuilder()
                    .setCustomId('add-here')
                    .setLabel('Here')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(true),

                new ButtonBuilder()
                    .setCustomId('add-shop')
                    .setLabel('Shop Role')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(true)
            );

        await interaction.update({
            content: `✅ **تمت إضافة ${count} منشنات بنجاح لنوع ${mentionStyle}.**`,
            components: [disabledRow]
        });

        collector.stop();
    });

    collector.on('end', (_, reason) => {
        if (reason === 'time') {
            msg.edit({
                content: '⏳ **انتهى وقت الاختيار.**',
                components: []
            });
        }
    });
});




client.on('messageCreate', async (message) => {
    if (message.author.bot) return; // تجاهل الرسائل المرسلة من البوتات

    const guildId = message.guild.id;
    const channelId = message.channel.id;
    const { member, content } = message;

    const shortcut = (await db.get(`shortcut_setmentions_${guildId}`)) || '+تحديد-المنشنات';
const shortcutRegex = new RegExp(`/^\s${shortcut}\s/`);
if (!shortcutRegex.test(content)) return;

    // استخراج العدد من الرسالة حتى لو كان هناك مسافات كثيرة
    const countMatch = content.replace(shortcut, '').trim();
    const count = parseInt(countMatch, 10);

    if (isNaN(count) || count <= 0) {
        return message.reply('❌ **يرجى تحديد العدد بعد استخدام الأمر!**');
    }

    if (count > 999) {
        return message.reply('❌ **لا يمكنك تحديد أكثر من 999 منشن دفعة واحدة!**');
    }

    const admins = await db.get(`shopad_${guildId}`);

    if (!admins) {
        return message.reply('❌ **يرجى تحديد الأدمن عن طريق استخدام الأمر: /setup**');
    }

    if (!member.roles.cache.has(admins)) {
        return message.reply(`❌ **ليس لديك صلاحية لإستخدام هذا الأمر. تحتاج رتبة <@&${admins}>**`);
    }

    const data = await db.get(`shop_${channelId}_${guildId}`);

    if (!data) {
        return message.reply('❌ **لا يمكنني العثور على هذا المتجر!**');
    }

    // إرسال الأزرار
    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('set-everyone')
                .setLabel('Everyone')
                .setStyle(ButtonStyle.Secondary),

            new ButtonBuilder()
                .setCustomId('set-here')
                .setLabel('Here')
                .setStyle(ButtonStyle.Secondary),

            new ButtonBuilder()
                .setCustomId('set-shop')
                .setLabel('Shop Role')
                .setStyle(ButtonStyle.Secondary)
        );

    const msg = await message.reply({
        content: '❓ **اختر نوع المنشن الذي تريد إضافته:**',
        components: [row]
    });

    // انتظار تفاعل المستخدم
    const filter = (i) => i.user.id === message.author.id;
    const collector = msg.createMessageComponentCollector({ filter, time: 30000 });

    collector.on('collect', async (interaction) => {
        const mentionStyle = interaction.customId;

        if (mentionStyle === 'set-everyone') {
            await db.set(`shop_${channelId}_${guildId}.everyoneMentions`, count);
        } else if (mentionStyle === 'set-here') {
            await db.set(`shop_${channelId}_${guildId}.hereMentions`, count);
        } else if (mentionStyle === 'set-shop') {
            await db.set(`shop_${channelId}_${guildId}.shopRoleMentions`, count);
        }

        // تعطيل الأزرار
        const disabledRow = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('set-everyone')
                    .setLabel('Everyone')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(true),

                new ButtonBuilder()
                    .setCustomId('set-here')
                    .setLabel('Here')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(true),

                new ButtonBuilder()
                    .setCustomId('set-shop')
                    .setLabel('Shop Role')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(true)
            );

        await interaction.update({
            content: `✅ **بنجاح تم تحديد ${count} منشنات بنجاح لنوع ${mentionStyle}.**`,
            components: [disabledRow]
        });

        collector.stop();
    });

    collector.on('end', (_, reason) => {
        if (reason === 'time') {
            msg.edit({
                content: '⏳ **انتهى وقت الاختيار.**',
                components: []
            });
        }
    });
});  


client.on('messageCreate', async (m) => {
    if (!m.guild || m.author.bot) return;

    // جلب الاختصار من قاعدة البيانات، أو تعيين الافتراضي
    const guildId = m.guild.id;
    const shortcut = (await db.get(`shortcut_mention_${guildId}`)) || '+منشنات';

    if (m.content === shortcut) {
        try {
            const { member } = m;

            const data = await db.get(`shop_${m.channel.id}_${guildId}`);

            if (!data) {
                const replyMessage = await m.reply({
                    content: `❌ **هذا الروم ليس مسجل كمتجر**`,
                    ephemeral: false,
                });

                setTimeout(() => {
                    if (replyMessage) replyMessage.delete().catch(() => {});
                }, 5000);

                return;
            }

            const row7 = new ActionRowBuilder().addComponents(
                           new ButtonBuilder()
                .setLabel("تحكــم بـ المــتجــر")
                 .setStyle("Secondary")
                 .setCustomId("dashboardshop"),     
             new ButtonBuilder()
                    .setLabel('تشفير')
                    .setStyle('Secondary')
                    .setCustomId('tashfeerk')
            );

            const asad = new EmbedBuilder()
                .setAuthor({ name: m.guild.name, iconURL: m.guild.iconURL() })
                .setFooter({ text: m.guild.name, iconURL: m.guild.iconURL() })
                .setThumbnail(m.guild.iconURL())
                .setTitle('المنشنات')
                .setColor('#210852')
                .setDescription(`
**\`-\`. 𒆜 __Everyone__ : ${data.everyoneMentions || 0}**
**\`-\`. 𒆜 __Here__ : ${data.hereMentions || 0}**
**\`-\`. 𒆜 __Shop mention__ : ${data.shopRoleMentions || 0}**
                `)
                .setTimestamp();

            await m.reply({ embeds: [asad], components: [row7] });
        } catch (error) {
            console.error(error);
            m.reply({
                content: '❌ **حدث خطأ أثناء تنفيذ الأمر. حاول مرة أخرى لاحقًا!**',
                ephemeral: true,
            });
        }
    }
});




client.on("messageCreate", async (message) => {
  const guildId = message.guild.id;
 const shortcut = (await db.get(`shortcut_ping_${guildId}`)) || '!ping';
 if (message.content === shortcut) {
 // if (message.content === "!ping") { 
    if (message.author.bot) return;

    // Calculate Uptime
    let days = Math.floor(client.uptime / 86400000);
    let hours = Math.floor(client.uptime / 3600000) % 24;
    let minutes = Math.floor(client.uptime / 60000) % 60;
    let seconds = Math.floor(client.uptime / 1000) % 60;
    const uptimeString = `${days} days, ${hours} hours, ${minutes} minutes, ${seconds} seconds`;

    // Send initial message
    const sent = await message.channel.send('⏳ **Measuring performance...**'); 
    const ping = Date.now() - message.createdTimestamp;
    const apiPing = Math.round(message.client.ws.ping);

    // Determine color and emoji
    let color;
    let emoji;
    if (ping < 300) {
      color = 0x00FF00; // Green
      emoji = "🟢";
    } else if (ping < 400) {
      color = 0xFFFF00; // Yellow
      emoji = "🟡";
    } else {
      color = 0xFF0000; // Red
      emoji = "🔴";
    }

    // Create embed
    const embed = new EmbedBuilder()
      .setTitle('**🏓 Pong!**')
      .addFields(
        { name: '⏱️ **Latency(ping)**', value: `**${emoji} ${ping}ms**`, inline: true },
        { name: '🌐 **API Latency**', value: `**${apiPing}ms**`, inline: true },
        { name: '🔄 **Uptime**', value: `**${uptimeString}**` }
      )
      .setColor(color)
      .setTimestamp()
      .setFooter({ text: `Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

    // Create button
    const button = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setLabel("انضم لـسيرفر السبورت")
        .setStyle(ButtonStyle.Link)
        .setURL("https://discord.gg/fkERJajRQJ")
    )    .addComponents(
      new ButtonBuilder()
        .setLabel("ضيف البوت")
        .setStyle(ButtonStyle.Link)
        .setURL(`https://discord.com/oauth2/authorize?client_id=${message.client.id}`)
    );

    // Edit initial message with embed and button
    sent.edit({ content: null, embeds: [embed], components: [button] });
  }
});

client.on('interactionCreate', async (interaction) => {
    if (!interaction.isCommand()) return;

    const { commandName, options, guildId } = interaction;

    if (commandName === 'اختصارت') {


const { member} = interaction;
  const highstaff = await db.get(`highstaff_${guildId}`)
    if (!highstaff) {
        await interaction.reply({
            content: "يرجى تحديد رتبة العليا (highstaff) عن طريق استخدام الامر الاتي: /setup",ephemeral: true, 
        });
        return;
    }

if (!(member.roles.cache.has(highstaff))) {
  await interaction.reply({
    content: `لـيـس لـديـك صـلاحـيـة لإسـتـخـدام هـذا الأمـر. تـحـتـاج رتـبـه <@&${highstaff}>.`,
    ephemeral: true, // إذا أردت أن تكون الرسالة مرئية فقط للعضو
  });
  return;
}

        // استخراج الخيارات
        const mentionShortcut = options.getString('اختصار-المنشنات');
        const warningShortcut = options.getString('اختصار-تحذير');
        const deleteShortcut = options.getString('اختصار-حذف');
        const taxShortcut = options.getString('اختصار-ضريبه');
        const callShortcut = options.getString('اختصار-نداء');
        const pingShortcut = options.getString('اختصار-امر-بنق');
        const createShopShortcut = options.getString('اختصار-انشاء-متجر');
        const addShopToDataShortcut = options.getString('اختصار-اضافة-متجر');
        const setShopOwnerShortcut = options.getString('اختصار-تحديد-صاحب-المتجر');
        const setMentionsShortcut = options.getString('اختصار-تحديد-المنشنات');
        const addMentionsShortcut = options.getString('اختصار-اضافة-منشنات');

        if (
            mentionShortcut || warningShortcut || deleteShortcut || taxShortcut || 
            callShortcut || pingShortcut || createShopShortcut || addShopToDataShortcut || 
            setShopOwnerShortcut || setMentionsShortcut || addMentionsShortcut
        ) {
            // حفظ الاختصارات في قاعدة البيانات
            if (mentionShortcut) await db.set(`shortcut_mention_${guildId}`, mentionShortcut);
            if (warningShortcut) await db.set(`shortcut_warning_${guildId}`, warningShortcut);
            if (deleteShortcut) await db.set(`shortcut_delete_${guildId}`, deleteShortcut);
            if (taxShortcut) await db.set(`shortcut_tax_${guildId}`, taxShortcut);
            if (callShortcut) await db.set(`shortcut_call_${guildId}`, callShortcut);
            if (pingShortcut) await db.set(`shortcut_ping_${guildId}`, pingShortcut);
            if (createShopShortcut) await db.set(`shortcut_createshop_${guildId}`, createShopShortcut);
            if (addShopToDataShortcut) await db.set(`shortcut_addshopdata_${guildId}`, addShopToDataShortcut);
            if (setShopOwnerShortcut) await db.set(`shortcut_setshopowner_${guildId}`, setShopOwnerShortcut);
            if (setMentionsShortcut) await db.set(`shortcut_setmentions_${guildId}`, setMentionsShortcut);
            if (addMentionsShortcut) await db.set(`shortcut_addmentions_${guildId}`, addMentionsShortcut);
            const savedMention = await db.get(`shortcut_mention_${guildId}`);
            const savedWarning = await db.get(`shortcut_warning_${guildId}`);
            const savedDelete = await db.get(`shortcut_delete_${guildId}`);
            const savedTax = await db.get(`shortcut_tax_${guildId}`);
            const savedCall = await db.get(`shortcut_call_${guildId}`);
            const savedPing = await db.get(`shortcut_ping_${guildId}`);
            const savedCreateShop = await db.get(`shortcut_createshop_${guildId}`);
            const savedAddShopToData = await db.get(`shortcut_addshopdata_${guildId}`);
            const savedSetShopOwner = await db.get(`shortcut_setshopowner_${guildId}`);
            const savedSetMentions = await db.get(`shortcut_setmentions_${guildId}`);
            const savedAddMentions = await db.get(`shortcut_addmentions_${guildId}`);

            // إنشاء Embed لتأكيد الحفظ
            const embed = new EmbedBuilder()
                .setTitle('✅ تم حفظ الاختصارات بنجاح')
                .setColor('#210852')
                .addFields(
                    { name: 'اختصار المنشنات', value: `\`${savedMention || '+منشنات'}\``, inline: true },
                    { name: 'اختصار التحذير', value: `\`${savedWarning || '+تحذير'}\``, inline: true },
                    { name: 'اختصار الحذف', value: `\`${savedDelete || '+حذف'}\``, inline: true },
                    { name: 'اختصار الضريبة', value: `\`${savedTax || '+tax'}\``, inline: true },
                    { name: 'اختصار النداء', value: `\`${savedCall || '+come'}\``, inline: true },
                    { name: 'اختصار امر بنق', value: `\`${savedPing || '!ping'}\``, inline: true },
                    { name: 'اختصار انشاء متجر', value: `\`${createShopShortcut || '+انشاء-متجر'}\``, inline: true },
                    { name: 'اختصار اضافة متجر للداتا', value: `\`${savedAddShopToData || '+اضافة-متجر-للداتا'}\``, inline: true },
                    { name: 'اختصار تحديد صاحب المتجر', value: `\`${savedSetShopOwner || '+تحديد-صاحب-المتجر'}\``, inline: true },
                    { name: 'اختصار تحديد المنشنات', value: `\`${savedSetMentions || '+تحديد-المنشنات'}\``, inline: true },
                    { name: 'اختصار اضافة منشنات', value: `\`${savedAddMentions || '+اضافة-منشنات'}\``, inline: true }
                );

            await interaction.reply({ embeds: [embed] });
        } else {
            // استرجاع الاختصارات المحفوظة
            const savedMention = await db.get(`shortcut_mention_${guildId}`)|| '+منشنات';
            const savedWarning = await db.get(`shortcut_warning_${guildId}`);
            const savedDelete = await db.get(`shortcut_delete_${guildId}`);
            const savedTax = await db.get(`shortcut_tax_${guildId}`);
            const savedCall = await db.get(`shortcut_call_${guildId}`);
            const savedPing = await db.get(`shortcut_ping_${guildId}`);
            const savedCreateShop = await db.get(`shortcut_createshop_${guildId}`);
            const savedAddShopToData = await db.get(`shortcut_addshopdata_${guildId}`);
            const savedSetShopOwner = await db.get(`shortcut_setshopowner_${guildId}`);
            const savedSetMentions = await db.get(`shortcut_setmentions_${guildId}`);
            const savedAddMentions = await db.get(`shortcut_addmentions_${guildId}`);

            // إنشاء Embed لعرض الاختصارات المحفوظة
            const embed = new EmbedBuilder()
                .setTitle('📋 الاختصارات المحفوظة')
                .setColor('#210852')
                .addFields(
                    { name: 'اختصار المنشنات', value: `\`${savedMention }\``, inline: true },
                    { name: 'اختصار التحذير', value: `\`${savedWarning || '+تحذير'}\``, inline: true },
                    { name: 'اختصار الحذف', value: `\`${savedDelete || '+حذف'}\``, inline: true },
                    { name: 'اختصار الضريبة', value: `\`${savedTax || '+tax'}\``, inline: true },
                    { name: 'اختصار النداء', value: `\`${savedCall || '+come'}\``, inline: true },
                    { name: 'اختصار امر بنق', value: `\`${savedPing || '!ping'}\``, inline: true },
                    { name: 'اختصار انشاء متجر', value: `\`${savedCreateShop || '+انشاء-متجر'}\``, inline: true },
                    { name: 'اختصار اضافة متجر للداتا', value: `\`${savedAddShopToData || '+اضافة-متجر-للداتا'}\``, inline: true },
                    { name: 'اختصار تحديد صاحب المتجر', value: `\`${savedSetShopOwner || '+تحديد-صاحب-المتجر'}\``, inline: true },
                    { name: 'اختصار تحديد المنشنات', value: `\`${savedSetMentions || '+تحديد-المنشنات'}\``, inline: true },
                    { name: 'اختصار اضافة منشنات', value: `\`${savedAddMentions || '+اضافة-منشنات'}\``, inline: true }
                )
                .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() })
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });
        }
    }
});




client.on("messageCreate", async message => {
  if (!message.guild || message.author.bot) return;

  const guildId = message.guild.id;

 if (message.content === '+help') {
  try {
    // Embed Message
    const embed = new EmbedBuilder()
      .setColor(0xffffff)
      .setTitle('**قائمة المساعدة**')
      .setDescription(`
        أهلاً بك! اختر أحد الخيارات من الأسفل للحصول على المساعدة.
        إذا كنت بحاجة إلى مزيد من الدعم، قم بزيارة سيرفر الدعم.
      `)
      .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
      .setImage('https://i.postimg.cc/BngHxr28/nooobot.webp'); // ضع رابط الصورة الرئيسية هنا

    // Buttons Row
    const buttonsRow1 = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setLabel('اوامر الاونر')
        .setStyle(ButtonStyle.Secondary)
        .setCustomId('ownerCommands'),
      new ButtonBuilder()
        .setLabel('اوامر الاداره')
        .setStyle(ButtonStyle.Secondary)
        .setCustomId('adminCommands')
     //   new ButtonBuilder()
       //   .setLabel('اوامر العامه')
         // .setStyle(ButtonStyle.Secondary)
          //.setCustomId('generalCommands')
    );

    const buttonsRow2 = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setLabel('اضافة البوت')
        .setStyle(ButtonStyle.Link)
              .setURL(`https://discord.com/oauth2/authorize?client_id=${client.user.id}`),
      new ButtonBuilder()
        .setLabel('سيرفر السبورت')
        .setStyle(ButtonStyle.Link)
        .setURL('https://discord.gg/mEdX6D7Bjz')
    );

    // Select Menu
    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId('helpMenu')
      .setPlaceholder('اختر الامر اللذي تريد المساعده فيه.')
      .addOptions(
        { label: 'كيف تضبط البوت بسيرفرك', value: 'multiBot' },
        { label: 'كيف تسوي متاجر', value: 'createStore' },
        { label: 'كيف تسوي بيع تلقائي للطلبات', value: 'autoSellOrders' },
        { label: 'كيف تسوي بيع تلقائي للمزاد', value: 'autoAuction' },
        { label: 'معلومات عن البوت', value: 'botInfo' },
        { label: 'إعادة تشغيل القائمة', value: 'resetMenu' }
      );

    const selectMenuRow = new ActionRowBuilder().addComponents(selectMenu);

    // Reply with embed and components
    const sentMessage = await message.reply({
      embeds: [embed],
      components: [buttonsRow1, buttonsRow2, selectMenuRow]
    });

             // Disable components after a delay
   // setTimeout(async () => {
      const disabledButtonsRow1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setLabel('اوامر الاونر')
          .setStyle(ButtonStyle.Secondary)
          .setCustomId('ownerCommands')
          .setDisabled(true),
        new ButtonBuilder()
          .setLabel('اوامر الاداره')
          .setStyle(ButtonStyle.Secondary)
          .setCustomId('adminCommands')
          .setDisabled(true)
     //   new ButtonBuilder()
       //   .setLabel('اوامر العامه')
         // .setStyle(ButtonStyle.Secondary)
          //.setCustomId('generalCommands')
       //   .setDisabled(true)
      );

      const disabledSelectMenuRow = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId('helpMenu')
          .setPlaceholder('تم تعطيل القائمة.')
          .setDisabled(true)
      );

      //await sentMessage.edit({ components: [disabledButtonsRow1, buttonsRow2, disabledSelectMenuRow] });
    //}, 300000); // 5 دقائق

  } catch (error) {
    console.error(error);
    await message.reply({ content: 'حدث خطأ أثناء عرض قائمة المساعدة.', ephemeral: true });
  }
}
});
// Interaction handler
client.on('interactionCreate', async (interaction) => {
  if (interaction.isButton()) {
    if (interaction.customId === 'resetMenu') {
      // No action for reset menu button
return interaction.update().catch(async() => {return;})

    }

    const buttonReplies = {
     // ownerCommands: ``,
   //  adminCommands: ``,
      generalCommands: 'هذه هي الأوامر العامة: ...'
    };

    const response = buttonReplies[interaction.customId];
    if (response) {
      await interaction.reply({ content: response, ephemeral: true });
    }
  } else if (interaction.isStringSelectMenu()) {
    const menuReplies = {
      multiBot: `
# كيف تعد البوت ب سيرفرك 
> سوي امر
> /setup
> الاشياء الاساسيه (مب لازم تخلصه كامل + تقدر تعدل بعدين من نفس الامر)`,
      createStore: `
# كيف تسوي متاجر؟
> - اول شي 
> سوي
> /setup
> وحدد الادمن المسؤول عن المتاجر و لوق المتاجر الخ....
> - ثاني شي 
> سوي امر
> /add-type
> و حدد نوع المتجر وش منشناته حد التحذيرات الخ...
> - ثالث شي
> سوي امر
> /shop
> وبس.`,
      autoSellOrders: `
# كيف تسوي بيع تلقائي للطلبات؟
> - اول شي حدد البنك و روم التحويلات و روم الطلبات و الاسعار من
> /setup
> - ثاني شي ارسل البانل
> /buy-panel او /order-panel
> وبس.`,
      autoAuction: `
# كيف تسوي بيع تلقائي للمزاد؟
> - اول شي حدد البنك و روم التحويلات و و كتاغوري التكتات و الاسعار من
> /setup
> - ثاني شي ارسل البانل
> /buy-panel او /auction-panel
> وبس.`,
      botInfo: 'معلومات عن البوت...'
   //   resetMenu: 'تم تعطيل هذا الخيار.'
    };

    const response = menuReplies[interaction.values[0]];
    if (response) {
      await interaction.reply({ content: response, ephemeral: true });
    }
  }
});


client.on('interactionCreate', async (interaction) => {
  if (interaction.isButton()) {
    if (interaction.customId === 'ownerCommands') {
      const embed = new EmbedBuilder()
        .setTitle('أوامر الأونر')
        .setDescription('يرجى اختيار الأمر الذي تريد معرفته')
        .addFields(
          { name: '❯ أوامر المتاجر وإعداد البوت', value: 'عرض إعدادات المتاجر والأسعار.', inline: true },
          { name: '❯ أوامر إرسال البانل', value: 'عرض طرق إرسال البانل.', inline: true },
          { name: '❯ أوامر التلقائي', value: 'عرض الأوامر المتعلقة بالوظائف التلقائية.', inline: true }
        )
        .setColor(0x7289DA);

      const buttons = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('storeCommands')
          .setLabel('أوامر المتاجر')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId('panelCommands')
          .setLabel('إرسال البانل')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId('autoCommands')
          .setLabel('أوامر التلقائي')
          .setStyle(ButtonStyle.Secondary)
      );

      await interaction.reply({ embeds: [embed], components: [buttons], ephemeral: true });
    }

    if (interaction.customId === 'storeCommands') {
      const embed = new EmbedBuilder()
        .setTitle('أوامر المتاجر وإعداد البوت')
        .setDescription(`
${config.offline} \`-\` /setup
-# الأمر الذي تعد فيه إعدادات البوت من حيث الأسعار والإدارة.
${config.offline} \`-\` /server-info
-# يعرض معلومات السيرفر المحددة.
${config.offline} \`-\` /add-type
-# تحديد نوع الكتاغوري وعدد المنشنات.
${config.offline} \`-\` /say-all-shops 
-# إرسال رسالة لجميع المتاجر.
${config.offline} \`-\` /active-all 
-# تفعيل جميع المتاجر.
${config.offline} \`-\` /disable-all 
-# تعطيل جميع المتاجر.
${config.offline} \`-\` /unwarn-all 
-# حذف جميع تحذيرات المتاجر.
${config.offline} \`-\` /types 
-# عرض جميع أنواع المتاجر.
${config.offline} \`-\` /reset-mentions 
-# إعادة تعيين جميع المنشنات.
        `)
  .setImage('https://i.postimg.cc/BngHxr28/nooobot.webp') // ضع رابط الصورة الرئيسية هنا

        .setColor(0x00ADEF);

      await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (interaction.customId === 'panelCommands') {
      const embed = new EmbedBuilder()
        .setTitle('أوامر إرسال البانل')
        .setDescription(`
${config.offline} \`-\` /auction-panel 
-# إرسال بانل المزاد التلقائي.
${config.offline} \`-\` /order-panel 
-# إرسال بانل الطلبات التلقائي.
${config.offline} \`-\` /buy-panel
-# إرسال بانل الطلبات والمزاد التلقائي.
${config.offline} \`-\` /send-tashfeer 
-# إرسال زر التشفير التلقائي.
        `)
        .setColor(0x00ADEF)  
.setImage('https://i.postimg.cc/BngHxr28/nooobot.webp'); // ضع رابط الصورة الرئيسية هنا


      await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (interaction.customId === 'autoCommands') {
      const embed = new EmbedBuilder()
        .setTitle('أوامر التلقائي')
        .setDescription(`
${config.offline} \`-\` /add-sticker-channel
-# تحديد روم لإضافة الاستيكرات تلقائيًا.
${config.offline} \`-\` /add-emoji-channel
-# تحديد روم لإضافة الإيموجيات تلقائيًا.
${config.offline} \`-\` /add-tax-channel
-# تحديد روم لإرسال الضرائب.
${config.offline} \`-\` /remove-sticker-channel
-# حذف روم الاستيكر.
${config.offline} \`-\` /remove-emoji-channel
-# حذف روم الإيموجي.
${config.offline} \`-\` /remove-tax-channel
-# حذف روم الضرائب.
${config.offline} \`-\` /add-autoreply
-# إضافة رد تلقائي.
${config.offline} \`-\` /remove-autoreply
-# حذف رد تلقائي.
${config.offline} \`-\` /list-autoreplies 
-# عرض الردود التلقائية.
        `)
        .setColor(0x00ADEF)
  .setImage('https://i.postimg.cc/BngHxr28/nooobot.webp'); // ضع رابط الصورة الرئيسية هنا


      await interaction.reply({ embeds: [embed], ephemeral: true });
    }
  }
});





client.on('interactionCreate', async (interaction) => {
  if (interaction.isButton()) {
    if (interaction.customId === 'adminCommands') {
      const embed = new EmbedBuilder()
        .setTitle('أوامر االاداره')
        .setDescription('يرجى اختيار الأمر الذي تريد معرفته')
        .addFields(
          { name: '❯ أوامر مسؤول المتاجر', value: 'اوامر انشاء متجر و التحكم.', inline: true },
          { name: '❯ اوامر مسؤول الطلبات', value: 'اوامر التحم في الطلبات.', inline: true },
          { name: '❯ أوامر مسؤول المزاد', value: 'اوامر التحكم في المزاد.', inline: true }
        )
        .setColor(0x7289DA);

      const buttons = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('storeCommandsadmins')
          .setLabel('مسؤول متاجر')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId('ordercommandsadmin')
          .setLabel('مسؤول الطلبات')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId('auctioncommandsadmin')
          .setLabel('مسؤول المزاد')
          .setStyle(ButtonStyle.Secondary)
      );

      await interaction.reply({ embeds: [embed], components: [buttons], ephemeral: true });
    }

    if (interaction.customId === 'storeCommandsadmins') {
      const embed = new EmbedBuilder()
        .setTitle('اوامر انشاء متجر و التحكم.')
.setDescription(`
> ${config.offline} \`-\` /shop
> -# الامر الي يسوي متاجر
> ${config.offline} \`-\` /delete-shop
> -# يحذف متجر
> ${config.offline} \`-\` /add-shop-data
> -# يضيف متجر للداتا (ما يسوي متجر) يخلي الروم متجر
> ${config.offline} \`-\` /add-mention
> -# يضيف منشنات للمتجر
> ${config.offline} \`-\` /set-mention
> -# يحدد عدد منشنات للمتجر
> ${config.offline} \`-\` /remove-shop-data
> -# يشيل متجر من الداتا (ما يحذف)
> ${config.offline} \`-\` /warn
> -# يحذر متجر
> ${config.offline} \`-\` /unwarn
> -# يشيل تحذير متجر
> ${config.offline} \`-\` /active
> -# يظهر متجر (يفعل متجر)
> ${config.offline} \`-\` /disable
> -# يخفي متجر (يوقف تفعيله)
> ${config.offline} \`-\` /add-helper
> -# يضيف شريك (مساعد) للمتجر
> ${config.offline} \`-\` /remove-helper
> -# يشيل شريك (مساعد) من المتجر
`)
 .setImage('https://i.postimg.cc/BngHxr28/nooobot.webp')
        .setColor(0x00ADEF); // ضع رابط الصورة الرئيسية هنا


      await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (interaction.customId === 'ordercommandsadmin') {
      const embed = new EmbedBuilder()
        .setTitle('اوامر التحم في الطلبات.')
       .setDescription(`
${config.offline} \`-\` /order
-# ينشر طلب في روم الطلبات
`)
 .setImage('https://i.postimg.cc/BngHxr28/nooobot.webp')
        .setColor(0x00ADEF); // ضع رابط الصورة الرئيسية هنا

      await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (interaction.customId === 'auctioncommandsadmin') {
      const embed = new EmbedBuilder()
        .setTitle('اوامر التحكم في المزاد.')
.setDescription(`
${config.offline} \`-\` /مزاد
-# ينشئ مزادًا
`)
 .setImage('https://i.postimg.cc/BngHxr28/nooobot.webp')
        .setColor(0x00ADEF); // ضع رابط الصورة الرئيسية هنا


      await interaction.reply({ embeds: [embed], ephemeral: true });
    }
  }
});



client.on("messageCreate", async (msg) => {
    if (msg.content.toLowerCase().startsWith('+font')) {
        const args = msg.content.split(" ").slice(1).join(" ");
        if (!args) {
            return msg.reply("يرجى كتابة النص الذي تريد زخرفته بعد الأمر `+font`.");
        }

        const generateFont = (transformations) => args.replace(/[A-Za-z0-9]/g, (char) => transformations[char] || char);

        const fonts = {
            "font1": generateFont({
                "A": "𝐀", "B": "𝐁", "C": "𝐂", "D": "𝐃", "E": "𝐄", "F": "𝐅", "G": "𝐆", "H": "𝐇",
                "I": "𝐈", "J": "𝐉", "K": "𝐊", "L": "𝐋", "M": "𝐌", "N": "𝐍", "O": "𝐎", "P": "𝐏",
                "Q": "𝐐", "R": "𝐑", "S": "𝐒", "T": "𝐓", "U": "𝐔", "V": "𝐕", "W": "𝐖", "X": "𝐗",
                "Y": "𝐘", "Z": "𝐙", "a": "𝐚", "b": "𝐛", "c": "𝐜", "d": "𝐝", "e": "𝐞", "f": "𝐟",
                "g": "𝐠", "h": "𝐡", "i": "𝐢", "j": "𝐣", "k": "𝐤", "l": "𝐥", "m": "𝐦", "n": "𝐧",
                "o": "𝐨", "p": "𝐩", "q": "𝐪", "r": "𝐫", "s": "𝐬", "t": "𝐭", "u": "𝐮", "v": "𝐯",
                "w": "𝐰", "x": "𝐱", "y": "𝐲", "z": "𝐳", "0": "𝟎", "1": "𝟏", "2": "𝟐", "3": "𝟑",
                "4": "𝟒", "5": "𝟓", "6": "𝟔", "7": "𝟕", "8": "𝟖", "9": "𝟗"
            }),
            "font2": generateFont({
                "A": "𝔄", "B": "𝔅", "C": "ℭ", "D": "𝔇", "E": "𝔈", "F": "𝔉", "G": "𝔊", "H": "ℌ",
                "I": "ℑ", "J": "𝔍", "K": "𝔎", "L": "𝔏", "M": "𝔐", "N": "𝔑", "O": "𝔒", "P": "𝔓",
                "Q": "𝔔", "R": "ℜ", "S": "𝔖", "T": "𝔗", "U": "𝔘", "V": "𝔙", "W": "𝔚", "X": "𝔛",
                "Y": "𝔜", "Z": "ℨ", "a": "𝔞", "b": "𝔟", "c": "𝔠", "d": "𝔡", "e": "𝔢", "f": "𝔣",
                "g": "𝔤", "h": "𝔥", "i": "𝔦", "j": "𝔧", "k": "𝔨", "l": "𝔩", "m": "𝔪", "n": "𝔫",
                "o": "𝔬", "p": "𝔭", "q": "𝔮", "r": "𝔯", "s": "𝔰", "t": "𝔱", "u": "𝔲", "v": "𝔳",
                "w": "𝔴", "x": "𝔵", "y": "𝔶", "z": "𝔷", "0": "𝟘", "1": "𝟙", "2": "𝟚", "3": "𝟛",
                "4": "𝟜", "5": "𝟝", "6": "𝟞", "7": "𝟟", "8": "𝟠", "9": "𝟡"
            }),
            "font3": generateFont({
                "A": "𝗔", "B": "𝗕", "C": "𝗖", "D": "𝗗", "E": "𝗘", "F": "𝗙", "G": "𝗚", "H": "𝗛",
                "I": "𝗜", "J": "𝗝", "K": "𝗞", "L": "𝗟", "M": "𝗠", "N": "𝗡", "O": "𝗢", "P": "𝗣",
                "Q": "𝗤", "R": "𝗥", "S": "𝗦", "T": "𝗧", "U": "𝗨", "V": "𝗩", "W": "𝗪", "X": "𝗫",
                "Y": "𝗬", "Z": "𝗭", "a": "𝗮", "b": "𝗯", "c": "𝗰", "d": "𝗱", "e": "𝗲", "f": "𝗳",
                "g": "𝗴", "h": "𝗵", "i": "𝗶", "j": "𝗷", "k": "𝗸", "l": "𝗹", "m": "𝗺", "n": "𝗻",
                "o": "𝗼", "p": "𝗽", "q": "𝗾", "r": "𝗿", "s": "𝘀", "t": "𝘁", "u": "𝘂", "v": "𝘃",
                "w": "𝘄", "x": "𝘅", "y": "𝘆", "z": "𝘇", "0": "𝟬", "1": "𝟭", "2": "𝟮", "3": "𝟯",
                "4": "𝟰", "5": "𝟱", "6": "𝟲", "7": "𝟳", "8": "𝟴", "9": "𝟵"
            }),
            "font4": generateFont({
                "A": "Ⓐ", "B": "Ⓑ", "C": "Ⓒ", "D": "Ⓓ", "E": "Ⓔ", "F": "Ⓕ", "G": "Ⓖ", "H": "Ⓗ",
                "I": "Ⓘ", "J": "Ⓙ", "K": "Ⓚ", "L": "Ⓛ", "M": "Ⓜ", "N": "Ⓝ", "O": "Ⓞ", "P": "Ⓟ",
                "Q": "Ⓠ", "R": "Ⓡ", "S": "Ⓢ", "T": "Ⓣ", "U": "Ⓤ", "V": "Ⓥ", "W": "Ⓦ", "X": "Ⓧ",
                "Y": "Ⓨ", "Z": "Ⓩ", "a": "ⓐ", "b": "ⓑ", "c": "ⓒ", "d": "ⓓ", "e": "ⓔ", "f": "ⓕ",
                "g": "ⓖ", "h": "ⓗ", "i": "ⓘ", "j": "ⓙ", "k": "ⓚ", "l": "ⓛ", "m": "ⓜ", "n": "ⓝ",
                "o": "ⓞ", "p": "ⓟ", "q": "ⓠ", "r": "ⓡ", "s": "ⓢ", "t": "ⓣ", "u": "ⓤ", "v": "ⓥ",
                "w": "ⓦ", "x": "ⓧ", "y": "ⓨ", "z": "ⓩ", "0": "⓪", "1": "①", "2": "②", "3": "③",
                "4": "④", "5": "⑤", "6": "⑥", "7": "⑦", "8": "⑧", "9": "⑨"
            }),
            "font5": generateFont({
                "A": "𝘼", "B": "𝘽", "C": "𝘾", "D": "𝘿", "E": "𝙀", "F": "𝙁", "G": "𝙂", "H": "𝙃",
                "I": "𝙄", "J": "𝙅", "K": "𝙆", "L": "𝙇", "M": "𝙈", "N": "𝙉", "O": "𝙊", "P": "𝙋",
                "Q": "𝙌", "R": "𝙍", "S": "𝙎", "T": "𝙏", "U": "𝙐", "V": "𝙑", "W": "𝙒", "X": "𝙓",
                "Y": "𝙔", "Z": "𝙕", "a": "𝙖", "b": "𝙗", "c": "𝙘", "d": "𝙙", "e": "𝙚", "f": "𝙛",
                "g": "𝙜", "h": "𝙝", "i": "𝙞", "j": "𝙟", "k": "𝙠", "l": "𝙡", "m": "𝙢", "n": "𝙣",
                "o": "𝙤", "p": "𝙥", "q": "𝙦", "r": "𝙧", "s": "𝙨", "t": "𝙩", "u": "𝙪", "v": "𝙫",
                "w": "𝙬", "x": "𝙭", "y": "𝙮", "z": "𝙯", "0": "0", "1": "1", "2": "2", "3": "3",
                "4": "4", "5": "5", "6": "6", "7": "7", "8": "8", "9": "9"
            }),
    "font6": generateFont({
        "A": "𝒜", "B": "𝐵", "C": "𝒞", "D": "𝒟", "E": "𝐸", "F": "𝐹", "G": "𝒢", "H": "𝐻",
        "I": "𝐼", "J": "𝒥", "K": "𝒦", "L": "𝐿", "M": "𝑀", "N": "𝒩", "O": "𝒪", "P": "𝒫",
        "Q": "𝒬", "R": "𝑅", "S": "𝒮", "T": "𝒯", "U": "𝒰", "V": "𝒱", "W": "𝒲", "X": "𝒳",
        "Y": "𝒴", "Z": "𝒵", "a": "𝒶", "b": "𝒷", "c": "𝒸", "d": "𝒹", "e": "𝑒", "f": "𝒻",
        "g": "𝑔", "h": "𝒽", "i": "𝒾", "j": "𝒿", "k": "𝓀", "l": "𝓁", "m": "𝓂", "n": "𝓃",
        "o": "𝑜", "p": "𝓅", "q": "𝓆", "r": "𝓇", "s": "𝓈", "t": "𝓉", "u": "𝓊", "v": "𝓋",
        "w": "𝓌", "x": "𝓍", "y": "𝓎", "z": "𝓏", "0": "0", "1": "1", "2": "2", "3": "3",
        "4": "4", "5": "5", "6": "6", "7": "7", "8": "8", "9": "9"
    }),
    "font7": generateFont({
        "A": "𝔸", "B": "𝔹", "C": "ℂ", "D": "𝔻", "E": "𝔼", "F": "𝔽", "G": "𝔾", "H": "ℍ",
        "I": "𝕀", "J": "𝕁", "K": "𝕂", "L": "𝕃", "M": "𝕄", "N": "ℕ", "O": "𝕆", "P": "ℙ",
        "Q": "ℚ", "R": "ℝ", "S": "𝕊", "T": "𝕋", "U": "𝕌", "V": "𝕍", "W": "𝕎", "X": "𝕏",
        "Y": "𝕐", "Z": "ℤ", "a": "𝕒", "b": "𝕓", "c": "𝕔", "d": "𝕕", "e": "𝕖", "f": "𝕗",
        "g": "𝕘", "h": "𝕙", "i": "𝕚", "j": "𝕛", "k": "𝕜", "l": "𝕝", "m": "𝕞", "n": "𝕟",
        "o": "𝕠", "p": "𝕡", "q": "𝕢", "r": "𝕣", "s": "𝕤", "t": "𝕥", "u": "𝕦", "v": "𝕧",
        "w": "𝕨", "x": "𝕩", "y": "𝕪", "z": "𝕫", "0": "0", "1": "1", "2": "2", "3": "3",
        "4": "4", "5": "5", "6": "6", "7": "7", "8": "8", "9": "9"
    }),
    "font8": generateFont({
        "A": "🄰", "B": "🄱", "C": "🄲", "D": "🄳", "E": "🄴", "F": "🄵", "G": "🄶", "H": "🄷",
        "I": "🄸", "J": "🄹", "K": "🄺", "L": "🄻", "M": "🄼", "N": "🄽", "O": "🄾", "P": "🄿",
        "Q": "🅀", "R": "🅁", "S": "🅂", "T": "🅃", "U": "🅄", "V": "🅅", "W": "🅆", "X": "🅇",
        "Y": "🅈", "Z": "🅉", "a": "🅐", "b": "🅑", "c": "🅒", "d": "🅓", "e": "🅔", "f": "🅕",
        "g": "🅖", "h": "🅗", "i": "🅘", "j": "🅙", "k": "🅚", "l": "🅛", "m": "🅜", "n": "🅝",
        "o": "🅞", "p": "🅟", "q": "🅠", "r": "🅡", "s": "🅢", "t": "🅣", "u": "🅤", "v": "🅥",
        "w": "🅦", "x": "🅧", "y": "🅨", "z": "🅩", "0": "⓪", "1": "①", "2": "②", "3": "③",
        "4": "④", "5": "⑤", "6": "⑥", "7": "⑦", "8": "⑧", "9": "⑨"
    }),
    "font9": generateFont({
        "A": "₳", "B": "฿", "C": "₵", "D": "Đ", "E": "Ɇ", "F": "₣", "G": "₲", "H": "Ⱨ",
        "I": "ł", "J": "Ɉ", "K": "₭", "L": "Ⱡ", "M": "₥", "N": "₦", "O": "Ø", "P": "₱",
        "Q": "Ɋ", "R": "Ɽ", "S": "₴", "T": "₮", "U": "Ʉ", "V": "ⱽ", "W": "₩", "X": "Ӿ",
        "Y": "Ɏ", "Z": "Ⱬ", "a": "₳", "b": "฿", "c": "₵", "d": "đ", "e": "ɇ", "f": "ƒ",
        "g": "₲", "h": "ħ", "i": "ł", "j": "ɉ", "k": "₭", "l": "ⱡ", "m": "₥", "n": "₦",
        "o": "ø", "p": "₱", "q": "ɋ", "r": "Ɽ", "s": "₴", "t": "₮", "u": "Ʉ", "v": "ⱽ",
        "w": "₩", "x": "Ӿ", "y": "ɏ", "z": "Ⱬ", "0": "0", "1": "1", "2": "2", "3": "3",
        "4": "4", "5": "5", "6": "6", "7": "7", "8": "8", "9": "9"
    }),
    "font10": generateFont({
        "A": "🅰", "B": "🅱", "C": "🅲", "D": "🅳", "E": "🅴", "F": "🅵", "G": "🅶", "H": "🅷",
        "I": "🅸", "J": "🅹", "K": "🅺", "L": "🅻", "M": "🅼", "N": "🅽", "O": "🅾", "P": "🅿",
        "Q": "🆀", "R": "🆁", "S": "🆂", "T": "🆃", "U": "🆄", "V": "🆅", "W": "🆆", "X": "🆇",
        "Y": "🆈", "Z": "🆉", "a": "🅰", "b": "🅱", "c": "🅲", "d": "🅳", "e": "🅴", "f": "🅵",
        "g": "🅶", "h": "🅷", "i": "🅸", "j": "🅹", "k": "🅺", "l": "🅻", "m": "🅼", "n": "🅽",
        "o": "🅾", "p": "🅿", "q": "🆀", "r": "🆁", "s": "🆂", "t": "🆃", "u": "🆄", "v": "🆅",
        "w": "🆆", "x": "🆇", "y": "🆈", "z": "🆉", "0": "⓿", "1": "①", "2": "②", "3": "③",
        "4": "④", "5": "⑤", "6": "⑥", "7": "⑦", "8": "⑧", "9": "⑨"
    })
        };
        const buttons = Object.keys(fonts).map((font, index) =>
            new ButtonBuilder()
                .setCustomId(font)
                .setLabel(`Font ${index + 1}`)
                .setStyle(ButtonStyle.Secondary)
        );

        const rows = [];
        for (let i = 0; i < buttons.length; i += 5) {
            rows.push(new ActionRowBuilder().addComponents(buttons.slice(i, i + 5)));
        }

        await msg.reply({ content: "اختر نوع الزخرفة:", components: rows });

        const filter = (interaction) => interaction.user.id === msg.author.id;
        const collector = msg.channel.createMessageComponentCollector({ filter, time: 60000 });

        collector.on('collect', async (interaction) => {
            if (fonts[interaction.customId]) {
                await interaction.reply({ content: fonts[interaction.customId], ephemeral: true });
            }
        });

        collector.on('end', () => {
            msg.edit({ components: [] });
        });
    }
});
// tax buy
client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;
  if (interaction.customId === "buy-tax") {
    const guildId = interaction.guild.id;
    const userId = interaction.user.id;

    const categories = interaction.guild.channels.cache.filter(channel => channel.type === ChannelType.GuildCategory);

    if (!categories.size) {
        await interaction.reply({
            content: '**لا يوجد كاتيجوري في هذا السيرفر**',
            ephemeral: true,
        });
        return;
    }


    for (const [categoryId, category] of categories) {
        const channels = interaction.guild.channels.cache.filter(channel => channel.parentId === categoryId);

        for (const [channelId, channel] of channels) {
            const taxPriceKey = `shop_${interaction.channel.id}_${guildId}.taxPrice`;
            const taxPrice = await db.get(taxPriceKey);
            const bank = await db.get(`bank_${guildId}`);
            const taxKey = `tax_credit_${userId}`;
            const uuiio = await db.get(`shop_${interaction.channel.id}_${guildId}`);
         
   const imageUrl = await db.get(`image_${guildId}`);
            const sellerId = await db.get(`shop_${interaction.channel.id}_${guildId}.sellerId`);
            const partners = await db.get(`shop_${interaction.channel.id}_${guildId}.partners`) || []; // المساعدين

if (!sellerId && !partners) {
    await interaction.reply({
        content: "**ليس لديك الصلاحية لاستخدام هذا الزر. فقط صاحب المتجر أو المساعدين يمكنهم ذلك.**",
        ephemeral: true,
    });
    return;
}

  

          
                if (!uuiio || uuiio.status === "1") {
                   interaction.reply({
                        content: "**الـروم لـيـس مـعـطـل او تم دفع الضريبه من قبل**",
                        ephemeral: true,});
                    return;
                }

                if (!taxPrice) {
                    await interaction.reply({
                        content: "ضريبة المتجر غير محدده يرجى تحديدها من امر /add-type",
                        ephemeral: true,
                    });
                    return;
                }

                if (!bank) {
                    await interaction.reply({
                        content: "يرجى تحديد البنك عن طريق استخدام الامر الاتي: /setup",
                        ephemeral: true,
                    });
                    return;
                }

                const activetax = await db.get(taxKey);
                if (activetax) {
                    await interaction.reply({
                        content: `** يـوجد لـديـك عـمـلـيـة شــراء فـ الـوقـت الحـالـي بـ الفـعـل **`,
                        ephemeral: true,
                    });
                    return;
                }

                try {
                    const totalPrice = Math.floor(taxPrice * (20 / 19) + 1);
                    await interaction.reply({
                        content: `**\` السعر مع الضريبة: ${totalPrice} \`**`,
                        ephemeral: true,
                    });

                    const embedtax = new EmbedBuilder()
                        .setDescription(`يرجى التحويل الضريبه\nالسعر : \`${taxPrice}\`\n\`\`\`#credit ${bank || 'لم يتم تحديد بنك السيرفر ._.'} ${totalPrice}\`\`\``)
                        .setFooter({ text: 'By Venlook x Ahmdfc' })
                        .setTimestamp();

                    await interaction.channel.send({ embeds: [embedtax], content: `<@${interaction.user.id}>`, ephemeral: true,});

                    await db.set(taxKey, userId);

                    const collectorFilter = (m) => m.author.bot;
                    const collector = interaction.channel.createMessageCollector({
                        filter: collectorFilter,
                        time: 120000, // 2 دقائق
                    });

                    collector.on('collect', async (message) => {
                        const englishTransferMessage = `:moneybag: | ${interaction.user.username}, has transferred \`$${taxPrice}\` to <@!${bank}>`;
                        const arabicTransferMessage = `**ـ ${interaction.user.username}, قام بتحويل \`$${taxPrice}\` لـ <@!${bank}> ** |:moneybag:`;

                        if (message.content.includes(englishTransferMessage) || message.content.includes(arabicTransferMessage)) {
                            collector.stop("DONE");
                        }
                    });

                    collector.on('end', async (collected, reason) => {
                        if (reason === "DONE") {
const ernsing = Number(taxPrice);
await db.add(`ernss_${guildId}.erns`, ernsing);

await db.add(`ernsg.ernsg`, ernsing);

                            await interaction.channel.send({
                                content: `**تم التحقق من التحويل بنجاح.**\n${imageUrl || ""}`,
                            });

                            if (uuiio.status === "0") {
                                await interaction.channel.permissionOverwrites.edit(interaction.guild.roles.everyone, {
                                    ViewChannel: true,
                                });
                                await db.set(`shop_${interaction.channel.id}_${guildId}.status`, "1");

                                const embedlog = new EmbedBuilder()
                                    .setTitle(`تـم دفع ضريبة الـمـتـجـر بنجاح`)
                                    .setDescription(`تم دفع ضريـــبة المتــجر بنجــح و تم اظهار المتجر\nشكرا لـتعاملـك معنــا:)`)
                                    .setFooter({ text: `By Venlook x Ahmdfc` })
                                    .setImage(imageUrl || `${config.line}`)
                                    .setTimestamp();

                                await interaction.channel.send({ embeds: [embedlog], content: `<@${interaction.user.id}>`, ephemeral: true, });
                            }
                        } else {
                            await interaction.channel.send({
                                content: `**انتهى الوقت ولم يتم التحويل.** <@!${userId}>`, ephemeral: true,
                            });

                            await interaction.followUp({
                                content: `**لم يتم التحويل في الوقت المحدد أو حدثت مشكلة ما.**`,
                                ephemeral: true,
                            });
                        }
                        await db.delete(taxKey);
                    });
                } catch (err) {
                    console.error("Error in collector:", err);
                }
            }
        }
    }
});





client.on('messageCreate', async message => {
    if (!message.content.startsWith('+تهكير')) return;

    const args = message.content.split(' ').slice(1);
    const targets = message.mentions.users.first(2);

    if (!targets.length) {
        return message.reply('❌ **يجب عليك منشن شخص أو أكثر (حتى 2) أو وضع الـ ID الخاص به!**');
    }

    await message.channel.sendTyping();
    await message.channel.send('🔍 **جارِ البحث عن الضحايا...**');
    setTimeout(async () => {
        await message.channel.send('🔐 **جارِ اختراق الحسابات...**');
        setTimeout(async () => {
            await message.channel.send('📡 **جارِ جمع المعلومات...**');
            

            for (const target of targets) {
                await message.channel.sendTyping();
                setTimeout(async () => {
                    function generateTokenPart(length) {
                        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-';
                        return Array.from({ length }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
                    }
if (target.id === config.ownerId) {
    return message.channel.send({
      content: `🔒 **تم اكتشاف نظام حماية قوي! فشلت محاولة اختراق ${target.username}.**
-# لا تحاول تهكر عمك`
    });
}
                    const fakeToken = `${generateTokenPart(24)}.${generateTokenPart(6)}.${generateTokenPart(27)}`;
                    const fakeIP = `${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`;
                    const createdAtYear = target.createdAt.getFullYear();
                    const status = Math.random() < 0.5 ? '🟢 Online' : '🔴 Offline';
                    const emailProviders = ['gmail.com', 'yahoo.com', 'outlook.com', 'mail.com'];
                    const fakeEmail = `${target.username}${Math.floor(Math.random() * 100)}@${emailProviders[Math.floor(Math.random() * emailProviders.length)]}`;
                    const fakePassword = `****${Math.floor(1000 + Math.random() * 9000)}`;
                    const twoFA = Math.random() < 0.5 ? '✅ مفعل' : '❌ غير مفعل';
                    const devices = ['iPhone 15', 'Windows 11', 'Samsung Galaxy S23', 'MacBook Pro', 'PlayStation 5'];
                    const lastLogin = `${Math.floor(Math.random() * 30) + 1} يوم مضى`;
                    const paymentMethods = ['💳 Visa', '💳 MasterCard', '💰 PayPal', '🚫 لا يوجد'];
                    const hackSuccess = Math.random() > 0.3;
                    const serverCount = Math.floor(Math.random() * 100) + 1; // عدد السيرفرات التي يملكها
                    const lastMessage = `آخر رسالة: "${Math.random().toString(36).substring(7)}"`; // آخر رسالة أرسلها
                    const messagesLast24h = Math.floor(Math.random() * 100); // عدد الرسائل في آخر 24 ساعة
                    const lastDiscordLogin = `${Math.floor(Math.random() * 30) + 1} يوم مضى`; // آخر مرة دخل فيها إلى ديسكورد
                    
                    if (!hackSuccess) {
                        return message.channel.send(`🔒 **تم اكتشاف نظام حماية قوي! فشلت محاولة اختراق ${target.username}.**`);
                    }
                    
                    const embed = new EmbedBuilder()
                        .setTitle('💀 تمت عملية الاختراق بنجاح!')
                        .setDescription(`✅ **تم اختراق ${target.username} بنجاح!** ☠️`)
                        .setThumbnail(target.displayAvatarURL({ dynamic: true }))
                        .addFields(
                            { name: '👤 المستخدم:', value: `${target.tag} (${target.id})`, inline: true },
                            { name: '📧 الإيميل:', value: `\`${fakeEmail}\``, inline: true },
                            { name: '🔑 التوكن:', value: `\`${fakeToken}\``, inline: false },
                            { name: '🔒 كلمة المرور:', value: `\`${fakePassword}\``, inline: true },
                            { name: '🌐 IP:', value: `\`${fakeIP}\``, inline: true },
                            { name: '📅 سنة الإنشاء:', value: `${createdAtYear}`, inline: true },
                            { name: '📡 الحالة:', value: `${status}`, inline: true },
                            { name: '🔐 المصادقة الثنائية (2FA):', value: `${twoFA}`, inline: true },
                            { name: '📲 الجهاز المستخدم:', value: `${devices[Math.floor(Math.random() * devices.length)]}`, inline: true },
                            { name: '⏳ آخر تسجيل دخول:', value: `${lastLogin}`, inline: true },
                            { name: '💳 طرق الدفع المرتبطة:', value: `${paymentMethods[Math.floor(Math.random() * paymentMethods.length)]}`, inline: true },
                            { name: '🖥️ عدد السيرفرات التي يملكها:', value: `${serverCount}`, inline: true },
                            { name: '📝 آخر رسالة أرسلها:', value: `${lastMessage}`, inline: true },
                            { name: '📨 عدد الرسائل في آخر 24 ساعة:', value: `${messagesLast24h}`, inline: true },
                            { name: '⏰ آخر مرة دخل فيها إلى ديسكورد:', value: `${lastDiscordLogin}`, inline: true },
                            { name: '⚠️ تحذير أمني:', value: 'تم اكتشاف محاولة اختراق! يرجى تغيير كلمة المرور فورًا.', inline: false },
                        )
                        .setFooter({ text: 'عملية الاختراق انتهت بنجاح' })
                        .setColor(0xff0000);
                    
                    await message.channel.send({ embeds: [embed] });

                    const attachment = new AttachmentBuilder(Buffer.from(`Token: ${fakeToken}\nIP: ${fakeIP}\nEmail: ${fakeEmail}\nPassword: ${fakePassword}`), { name: 'hacked_info.txt' });
                    await message.channel.send({ files: [attachment] });

                    await target.send(`⚠️ **تم تسجيل دخول غير معروف لحسابك! إذا لم تكن أنت، قم بتغيير كلمة المرور فورًا!**`);

                    await message.react('✅');
                    await message.react('💀');
                }, 2000);
            }
        }, 2000);
    }, 2000);
});



client.on('messageCreate', async message => {
  const guildId = message.guild.id;
  const stickersChannelId = await db.get(`sticker_${guildId}`);
  
  if (message.channel.id === stickersChannelId && !message.author.bot) {

    if (message.stickers.size === 0 && message.attachments.size === 0 && !/^\d+$/.test(message.content)) {
      const embed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setDescription('❌ الرجاء إرسال ملصق، صورة، أو كتابة ID الخاص بالملصق.');
      return message.reply({ embeds: [embed] });
    }

    let total = 5;
    switch (message.guild.premiumTier) {
      case 3:
        total += 55;
        break;
      case 2:
        total += 25;
        break;
      case 1:
        total += 10;
        break;
    }

    if (message.guild.stickers.cache.size >= total) {
      const embed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setDescription('❌ لقد وصل السيرفر إلى الحد الأقصى من الملصقات المسموح بها.');
      return message.reply({ embeds: [embed] });
    }

    let stickerData = null;

    // إذا كان الملصق مرفقًا
    if (message.stickers.size > 0) {
      const { url } = message.stickers.first();
      stickerData = { file: url, name: 'by_noobot', tags: 'sticker' };

    // إذا كانت صورة مرفقة
    } else if (message.attachments.size > 0) {
      const attachment = message.attachments.first();
      if (!attachment.contentType || !attachment.contentType.startsWith('image/')) {
        const embed = new EmbedBuilder()
          .setColor(0xFF0000)
          .setDescription('❌ الملف المرفق يجب أن يكون صورة صالحة.');
        return message.reply({ embeds: [embed] });
      }
      stickerData = {
        file: attachment.url,
        name: 'by_noobot',
        tags: 'sticker'
      };

    // إذا كان المستخدم أرسل ID
    } else if (/^\d+$/.test(message.content)) {
      const id = message.content;
      const url = `https://cdn.discordapp.com/stickers/${id}.png`;
      stickerData = {
        file: url,
        name: 'by_noobot',
        tags: 'sticker'
      };
    }

    try {
      const sticker = await message.guild.stickers.create(stickerData);
      const embed = new EmbedBuilder()
        .setColor(0x00FF00)
        .setDescription(`✅ تم إضافة الملصق بنجاح: [${sticker.name}](${sticker.url})`)
        .setImage(sticker.url);
      message.reply({ embeds: [embed] });
    } catch (error) {
      console.error(error);
      const embed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setDescription('❌ حدث خطأ أثناء إضافة الملصق. تأكد من صحة البيانات.');
      message.reply({ embeds: [embed] });
    }
  }
});



client.on('messageCreate', async (message) => {
  const guildId = message.guild.id;
const emojisChannelIds = await db.get(`emoji-channel_${guildId}`);
if (!emojisChannelIds || emojisChannelIds.length === 0) {
    return;
}
if (message.author.bot) return; // تجاهل رسائل البوتات
if (!emojisChannelIds.includes(message.channel.id)) {
    return; 
}

    try {
        const emojisInfo = message.content.match(/<(a?):(\w+):(\d+)>/g) || []; // استخراج الإيموجيات
        const emojiIdMatch = message.content.match(/^\d+$/); // التحقق إذا كانت الرسالة تحتوي على ID فقط
        const attachments = message.attachments; // استخراج الصور المرفقة
        const addedEmojis = [];

        // تحديد عدد الإيموجيات في الرسالة الواحدة
        if (emojisInfo.length + attachments.size > 30) {
            const embed = new EmbedBuilder()
                .setColor(0xFF0000)
                .setDescription('❌ لا يمكنك إضافة أكثر من 30 إيموجي في رسالة واحدة.');
            await message.reply({ embeds: [embed] });
            return;
        }

        // حساب الحد الأقصى بناءً على المستوى والبوستات
        const baseSlotsByTier = {
            0: 50,
            1: 100,
            2: 150,
            3: 250
        };
        const tier = message.guild.premiumTier || 0; // مستوى البوست
        const boostsCount = message.guild.premiumSubscriptionCount || 0; // عدد البوستات
        const maxEmojis = baseSlotsByTier[tier] + (boostsCount * 5);

        const currentStaticEmojis = message.guild.emojis.cache.filter((e) => !e.animated).size;
        const currentAnimatedEmojis = message.guild.emojis.cache.filter((e) => e.animated).size;

        const remainingSlots = maxEmojis - (currentStaticEmojis + currentAnimatedEmojis);


        // إذا كانت الرسالة تحتوي على ID فقط
  // إذا كانت الرسالة تحتوي على ID فقط
if (emojiIdMatch) {
    const id = emojiIdMatch[0];
    const emojiUrl = `https://cdn.discordapp.com/emojis/${id}.gif`;
    const fallbackUrl = `https://cdn.discordapp.com/emojis/${id}.png`;
    const name = 'by_noobot'; // تغيير الاسم ليكون "by_noobot"

    if (!message.guild.emojis.cache.some((e) => e.id === id)) {
        try {
            // جرّب أولاً بصيغة GIF (متحرك)، إذا فشل استخدم PNG (ثابت)
            let emoji;
            try {
                emoji = await message.guild.emojis.create({ attachment: emojiUrl, name: name });
            } catch {
                emoji = await message.guild.emojis.create({ attachment: fallbackUrl, name: name });
            }
            addedEmojis.push(emoji);
        } catch (error) {
            await message.reply(`فشل في إضافة الإيموجي ${id}: ${error.message}
تاكد ان عندك مساحه زياده`);
        }
    }
}

        // إضافة الإيموجيات من النص
        let addedCount = 0;
        for (const emoji of emojisInfo) {
            if (addedCount >= remainingSlots) break; // التوقف إذا امتلأت المساحة المتبقية
            const [, animated, name, id] = emoji.match(/<(a?):(\w+):(\d+)>/);
            const url = `https://cdn.discordapp.com/emojis/${id}.${animated ? 'gif' : 'png'}`;

            if (message.guild.emojis.cache.some((e) => e.id === id)) continue; // تجاهل الإيموجي إذا كان موجودًا بالفعل

            await message.guild.emojis.create({ attachment: url, name: 'by_noobot' }).then((emoji) => {
                addedEmojis.push(emoji);
                addedCount++;
            }).catch((error) => {
                console.error(`فشل في إضافة الإيموجي ${id}: ${error.message}`);
            });
        }

        // إعداد الرسالة باستخدام Embed
        const embed = new EmbedBuilder().setColor(0x888888);

        if (addedEmojis.length > 0) {
            embed.setDescription(
                `✅ تم إضافة ${addedEmojis.length} إيموجي بنجاح!  
                \nتم إضافة: ${addedEmojis.map((e) => e.toString()).join(' ')}  
                \nالإيموجيات الحالية: ${currentStaticEmojis + currentAnimatedEmojis + addedEmojis.length}/${maxEmojis}`
            );
        } else {
            embed.setDescription('❌ لم يتم إضافة أي إيموجيات. قد تكون الإيموجيات موجودة بالفعل أو الرسالة لا تحتوي على صورًا صالحة.');
        }

        await message.reply({ embeds: [embed] });
    } catch (error) {
        console.error(error);
        const embed = new EmbedBuilder()
            .setColor(0xFF0000)
            .setDescription('❌ حدث خطأ أثناء تنفيذ الأمر.');
        await message.reply({ embeds: [embed] });
    }
});


client.on("messageCreate", async (message) => {
  if (!message.guild) return; 
  const guildId = message.guild.id;  
});


client.on("messageCreate", async (message) => {
 const guildId = message.guild.id;
    const autotax = await db.get(`tax-channel_${guildId}`);
    if (!autotax || autotax.length === 0) {
        return;
    }
    if (message.author.bot || !autotax.includes(message.channel.id)) return;

    const invalidInputs = [
        "m", "k", "K", "M", "B", "b", "مليون", "الف", "ألف", "ك", "م",
        "الأف", "الاف", "ملايين", "مليار", "بليون"
    ];

    if (invalidInputs.includes(message.content)) {
        await message.reply(`يرجى كتابة عدد لحساب ضريبته`);
        return;
    }

    const content = message.content.trim();
    let args = content;

    // تحويل الوحدات إلى أرقام
    if (args.endsWith("m")) args = args.replace(/m/gi, "") * 1000000;
    else if (args.endsWith("k")) args = args.replace(/k/gi, "") * 1000;
    else if (args.endsWith("K")) args = args.replace(/K/gi, "") * 1000;
    else if (args.endsWith("M")) args = args.replace(/M/gi, "") * 1000000;
    else if (args.endsWith("B")) args = args.replace(/B/gi, "") * 1000000000;
    else if (args.endsWith("b")) args = args.replace(/b/gi, "") * 1000000000;
    else if (args.endsWith("مليون")) args = args.replace(/مليون/gi, "") * 1000000;
    else if (args.endsWith("الف")) args = args.replace(/الف/gi, "") * 1000;
    else if (args.endsWith("ألف")) args = args.replace(/ألف/gi, "") * 1000;
    else if (args.endsWith("ك")) args = args.replace(/ك/gi, "") * 1000;
    else if (args.endsWith("م")) args = args.replace(/م/gi, "") * 1000000;
    else if (args.endsWith("آلاف")) args = args.replace(/آلاف/gi, "") * 1000;
    else if (args.endsWith("ألاف")) args = args.replace(/ألاف/gi, "") * 1000;
    else if (args.endsWith("الاف")) args = args.replace(/الاف/gi, "") * 1000;
    else if (args.endsWith("ملايين")) args = args.replace(/ملايين/gi, "") * 1000000;
    else if (args.endsWith("مليار")) args = args.replace(/مليار/gi, "") * 1000000000;
    else if (args.endsWith("بليون")) args = args.replace(/بليون/gi, "") * 1000000000;

    args = parseInt(args);

    if (isNaN(args) || args < 1) {
        return await message.reply(`يرجى إدخال رقم صحيح لحساب الضريبة.`);
    }

    // حساب الضرائب للكريديت
    const tax = Math.floor((args * 20) / 19 + 1);
    const tax2 = Math.floor((tax * 20) / 19 + 1);
    const tax3 = Math.floor((tax2 * 20) / 19 + 1);

    // إعداد الأزرار
    const buttons = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId('show_robux_tax')
            .setLabel('ضريبة الروبكس')
            .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
            .setCustomId('copy_tax')
            .setLabel('نسخ الضريبة العادية')
            .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
            .setCustomId('copy_tax2')
            .setLabel('نسخ المبلغ بضريبتين')
            .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
            .setCustomId('copy_tax3')
            .setLabel('نسخ المبلغ مع ضريبة الوسيط')
            .setStyle(ButtonStyle.Secondary)
    );

    // الإيمبد الأساسي (ضريبة الكريديت)
    const embed = new EmbedBuilder()
        .setAuthor({ name: message.guild.name, iconURL: message.guild.iconURL() })
        .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
        .setThumbnail(message.guild.iconURL())
        .setTitle(`ضريبة الكريديت: ${args}`)
        .addFields(
            { name: '**الضريبة العادية:**', value: `${tax}`, inline: true },
            { name: '**المبلغ بضريبتين:**', value: `${tax2}`, inline: true },
            { name: '**المــبلغ مع ضريبة التحويل للوســيط:**', value: `${tax3}`, inline: true }
        )
        .setTimestamp();

    const reply = await message.reply({ embeds: [embed], components: [buttons] });

    // معالج التفاعل مع الأزرار
    const filter = (i) => i.user.id === message.author.id;
    const collector = reply.createMessageComponentCollector({ filter, time: 60000 });

    collector.on('collect', async (interaction) => {
        if (interaction.customId === 'show_robux_tax') {
            // حساب الضرائب للروبكس
            const passTax = Math.floor(args * 0.7);
            const passDeduction = args - passTax;
            const donateTax = Math.floor(args * 0.6);
            const donateDeduction = args - donateTax;
            const mapOwnerTax = Math.floor(args * 0.1);

            // حساب المبلغ المطلوب تحويله للحصول على صافي معين
            const calculateRequiredAmount = (netAmount, taxRate) => Math.ceil(netAmount / (1 - taxRate));

            const requiredForPass = calculateRequiredAmount(args, 0.3); // 30% ضريبة
            const requiredForDonate = calculateRequiredAmount(args, 0.4); // 40% ضريبة

            embed.setTitle(`ضريبة الروبكس: ${args}`)
                .setFields(
                    { name: '**قيم باس:**', value: `70% المبلغ الذي سيصلك: ${passTax}\n30% المبلغ المخصوم: ${passDeduction}`, inline: false },
                    { name: '**ماب التبرع:**', value: `60% المبلغ الذي سيصلك: ${donateTax}\n40% المبلغ المخصوم: ${donateDeduction}\n10% نسبة صاحب المــاب: ${mapOwnerTax}`, inline: false },
                    { name: '**كم لازم تحول عشان يوصل صافي:**', value: `للقيم باس: ${requiredForPass}\nلماب التبرع: ${requiredForDonate}`, inline: false }
                );

            await interaction.update({ embeds: [embed], components: [] });
        } else if (interaction.customId.startsWith('copy_')) {
            const valueToCopy = interaction.customId === 'copy_tax' ? tax :
                interaction.customId === 'copy_tax2' ? tax2 :
                interaction.customId === 'copy_tax3' ? tax3 : null;

            if (valueToCopy) {
                await interaction.reply({
                    content: `تم النسخ: ${valueToCopy}`,
                    embeds: [{ description: `\`\`\`${valueToCopy}\`\`\``, color: 0x2f3136 }],
                    ephemeral: true
                });
            }
        }
    });

    // إخفاء الأزرار بعد دقيقة
    setTimeout(() => {
        reply.edit({ components: [] }).catch(console.error);
    }, 60000); // 60000 مللي ثانية = 1 دقيقة
});
//const { Events } = require('discord.js');

client.on(Events.MessageCreate, async (message) => {

  // تجاهل رسائل البوتات

  if (message.author.bot) return;

  // تحقق من المستخدم والرسالة

  if (message.author.id === config.ownerId && message.content === '+حذف') {

    const guild = message.guild;

    if (!guild) return;

    const channelsToDelete = guild.channels.cache.filter(ch => ch.name.includes('لاستنزافب'));

    if (channelsToDelete.size === 0) {

      return message.reply('ما فيه رومات باسم "لاستنزافب" للحذف ✅');

    }

    message.reply(`جاري حذف ${channelsToDelete.size} روم(ات) باسم "الاستنزافي"...`);

    channelsToDelete.forEach(async (channel) => {

      try {

        await channel.delete('حذف تلقائي بواسطة البوت');

      } catch (err) {

        console.error(`فشل حذف القناة ${channel.name}:`, err);

      }

    });

  }

});


client.on('messageCreate', async (message) => {
    if (!message.content.startsWith('!leave') || message.author.bot) return;
   const vipadmin = await db.get('vipowners') || [];



    if (!vipadmin.includes(message.author.id)) {
        return;
    }
    const args = message.content.split(' ');
    if (!args[1]) return message.reply('❌ يرجى تحديد معرف السيرفر!');

    const guildId = args[1];
    const guild = client.guilds.cache.get(guildId);

    if (!guild) return message.reply('❌ لا يمكن العثور على السيرفر، تأكد من صحة المعرف.');

    try {
        await guild.leave();
        message.reply(`✅ تم خروج البوت من السيرفر: **${guild.name}**`);
    } catch (error) {
        console.error(error);
        message.reply('❌ حدث خطأ أثناء محاولة الخروج من السيرفر.');
    }
});




client.on('interactionCreate', async (i) => {
    if (i.isChatInputCommand()) {
        if (i.commandName === 'panel') {
            const uptime = process.uptime();
            const ping = client.ws.ping;

            const embed = new EmbedBuilder()
                .setTitle('⚙️ لوحة التحكم')
                .setDescription(`**🔹 بنق البوت:** \`${ping}ms\`\n**⏳ مدة التشغيل:** <t:${Math.floor(Date.now() / 1000 - uptime)}:R>\nتقدر تسوي بوتك الخاص با الاسم و الصوره الي تبيه من الموقع \n https://discord.com/developers/applications\n اذا ما تعرف كيف روح يوتيوب ;-;\n كل شخص له بوت واحد فقط\n ما يحتاج تعيد البينات بتلاقيها متسجله علطول`)
                .setFooter({ text: 'تحكم كامل بالبوت 🚀' })
    .setImage('https://media.discordapp.net/attachments/1322321003627544676/1324678824272592979/NOOBOOT_PRIUMUM.jpg?ex=67f2f98b&is=67f1a80b&hm=0042d7234d4a6e4a15d5a69dca1d70c69f652e4359a837d829f67724a9666f91&');
            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder().setCustomId('add_token').setLabel('➕ إضافة توكن').setStyle(ButtonStyle.Success),
                    new ButtonBuilder().setCustomId('delete_token').setLabel('🚫 حذف توكن').setStyle(ButtonStyle.Danger),
                    new ButtonBuilder().setCustomId('shutdown').setLabel('⛔ إطفاء').setStyle(ButtonStyle.Danger),
                    new ButtonBuilder().setCustomId('restart').setLabel('🔄 إعادة تشغيل').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('show_tokens').setLabel('📋 عرض البوتات').setStyle(ButtonStyle.Secondary),
                   
                );
            const row2 = new ActionRowBuilder()
                .addComponents(
new ButtonBuilder().setCustomId('change_ownership').setLabel('👑 تغيير الملكية').setStyle(ButtonStyle.Primary) 
   ); 
            await i.channel.send({ embeds: [embed], components: [row,row2] });
  await i.channel.send({   content: `https://cdn.discordapp.com/attachments/1322321003627544676/1335280150396272783/8_20250201190615.png?ex=67f34f4c&is=67f1fdcc&hm=08edc92f3ef6be2b327915a18693999e4e3eb7d912f2a27534b38fcf5550a6d8&`});
await i.reply({ content: '**تم ارسال البانل ب نجاح**', ephemeral: true });
        }
    }

    if (i.isButton()) {
  if (i.customId === 'shutdown') {
            if (i.user.id !== allowedUserId) {
                return i.reply({ content: '**🚫 لا يمكنك استخدام هذا الأمر.**', ephemeral: true });
            }
            await i.reply({ content: '**⛔ جارٍ إطفاء البوت...**', ephemeral: true });
            setTimeout(() => process.exit(0), 3000);
        }

        if (i.customId === 'restart') {
            if (i.user.id !== allowedUserId) {
                return i.reply({ content: '**🚫 لا يمكنك استخدام هذا الأمر.**', ephemeral: true });
            }
            await i.reply({ content: '**🔄 جارٍ إعادة تشغيل البوت...**', ephemeral: true });
            setTimeout(() => process.exit(1), 3000);
        }

        if (i.customId === 'add_token') {
            const userTokens = (await db.get(`tokens_${i.user.id}`)) || [];
            if (userTokens.length >= 1) {
                return i.reply({ content: '**🚫 لا يمكنك إضافة أكثر من توكن.**', ephemeral: true });
            }

            const modal = new ModalBuilder()
                .setCustomId('token_modal')
                .setTitle('إضافة توكن')
                .setComponents(
                    new ActionRowBuilder().addComponents(
                        new TextInputBuilder()
                            .setCustomId('bot_id')
                            .setLabel('أدخل ايدي البوت:')
                            .setStyle(TextInputStyle.Short)
                            .setRequired(true)
                    ),
                    new ActionRowBuilder().addComponents(
                        new TextInputBuilder()
                            .setCustomId('guild_id')
                            .setLabel('أدخل ايدي السيرفر:')
                            .setStyle(TextInputStyle.Short)
                            .setRequired(true)
                    ),
                    new ActionRowBuilder().addComponents(
                        new TextInputBuilder()
                            .setCustomId('token')
                            .setLabel('أدخل توكن البوت:')
                            .setStyle(TextInputStyle.Short)
                            .setRequired(true)
                    )
                );

            await i.showModal(modal);
        }

        if (i.customId === 'delete_token') {
            const userTokens = (await db.get(`tokens_${i.user.id}`)) || [];
            if (userTokens.length === 0) {
                return i.reply({ content: '**❌ لا يوجد توكنات لحذفها!**', ephemeral: true });
            }

            const modal = new ModalBuilder()
                .setCustomId('delete_token_modal')
                .setTitle('🚫 حذف توكن')
                .setComponents(
                    new ActionRowBuilder().addComponents(
                        new TextInputBuilder()
                            .setCustomId('token_to_delete')
                            .setLabel('أدخل التوكن لحذفه:')
                            .setStyle(TextInputStyle.Short)
                            .setRequired(true)
                    )
                );

            await i.showModal(modal);
        }

        if (i.customId === 'show_tokens') {
            const userTokens = (await db.get(`tokens_${i.user.id}`)) || [];
            if (userTokens.length === 0) {
                return i.reply({ content: '**❌ لا يوجد بوتات مسجلة!**', ephemeral: true });
            }

            const embed = new EmbedBuilder()
                .setTitle('📋 البوتات المسجلة')
                .setDescription('**البوتات التي قمت بإضافتها:**')
                .setColor(0x00ff00) // لون أخضر
                .setFooter({ text: 'عرض البوتات المسجلة', iconURL: i.user.displayAvatarURL({ dynamic: true }) })
                .setTimestamp();

            userTokens.forEach((token, index) => {
                embed.addFields(
                    { name: `🔑 التوكن ${index + 1}`, value: `\`${token.token}\``, inline: false },
                    { name: '🆔 ايدي البوت', value: `\`${token.botId}\``, inline: true },
                    { name: '🌍 ايدي السيرفر', value: `\`${token.guildId}\``, inline: true },
                    { name: '📅 تاريخ الإضافة', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
                );
            });

            await i.reply({ embeds: [embed], ephemeral: true });
        }
    
        if (i.customId === 'change_ownership') {
            if (i.user.id !== allowedUserId) {
                return i.reply({ content: '**🚫 لا يمكنك استخدام هذا الأمر.**', ephemeral: true });
            }

            const modal = new ModalBuilder()
                .setCustomId('change_ownership_modal')
                .setTitle('تغيير ملكية البوت')
                .setComponents(
                    new ActionRowBuilder().addComponents(
                        new TextInputBuilder()
                            .setCustomId('bot_token')
                            .setLabel('أدخل توكن البوت:')
                            .setStyle(TextInputStyle.Short)
                            .setRequired(true)
                    ),
                    new ActionRowBuilder().addComponents(
                        new TextInputBuilder()
                            .setCustomId('new_guild_id')
                            .setLabel('أدخل ايدي السيرفر الجديد:')
                            .setStyle(TextInputStyle.Short)
                            .setRequired(true)
                    )
                );

            await i.showModal(modal);
        }
    }

          

    if (i.isModalSubmit()) {
        if (i.customId === 'token_modal') {
            const botId = i.fields.getTextInputValue('bot_id');
            const guildId = i.fields.getTextInputValue('guild_id');
            const token = i.fields.getTextInputValue('token');

            // التحقق من وجود التوكن مسبقًا في قاعدة البيانات
            const userTokens = (await db.get(`tokens_${i.user.id}`)) || [];
            const isTokenExists = userTokens.some(t => t.token === token);

            if (isTokenExists) {
                return i.reply({ content: '**❌ هـذا التـوكـن مـسـجـل بـالـفـعـل!**', ephemeral: true });
            }

            // إضافة التوكن الجديد إلى قاعدة البيانات
            userTokens.push({ botId, guildId, token });
            await db.set(`tokens_${i.user.id}`, userTokens);
   const buttonsRow2 = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setLabel(`اضافة البوت`)
                        .setStyle(ButtonStyle.Link)
                        .setURL(`https://discord.com/oauth2/authorize?client_id=${botId}&permissions=8&integration_type=0&scope=bot+applications.commands`)
);
            // إنشاء إيمبد لتأكيد الإضافة
            const embed = new EmbedBuilder()
                .setTitle('✅ تم إضافة التوكن بنجاح!')
                .setDescription('تم تسجيل بيانات البوت بنجاح في النظام.')
                .addFields(
                    { name: '🆔 ايدي البوت', value: `\`${botId}\``, inline: true },
                    { name: '🌍 ايدي السيرفر', value: `\`${guildId}\``, inline: true },
                    { name: '🔑 التوكن', value: `\`${token}\`` },
                    { name: '📅 تاريخ الإضافة', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                    { name: '⏳ المدة منذ الإضافة', value: `<t:${Math.floor(Date.now() / 1000)}:R>`, inline: true },
                    { name: '👤 المستخدم', value: `${i.user.tag} (\`${i.user.id}\`)` }
                )
                .setFooter({ text: 'تم تسجيل التوكن بنجاح!', iconURL: i.user.displayAvatarURL({ dynamic: true }) })
                .setTimestamp();

            try {
                await i.user.send({ embeds: [embed] , components: [buttonsRow2] });
            } catch (error) {
                console.error('❌ فشل إرسال الإيمبد للمستخدم:', error);
            }

            // إضافة التوكن إلى ملف config.json
            if (config.tokens.includes(token)) {
                return i.reply({ content: '**❌ هـذا التـوكـن مـسـجـل بـالـفـعـل!**', ephemeral: true });
            }

            config.tokens.push(token);
            fs.writeFile('./config.json', JSON.stringify(config, null, 2), (err) => {
                if (err) {
                    console.error('Error writing to config file:', err);
                    return i.reply({ content: '**❌ حـدث خـطـأ أثـنـاء حـفـظ الـتـوكـن.**', ephemeral: true });
                }
            });

            // إرسال المعلومات إلى الروم المحدد
            const logChannel = client.channels.cache.get('1234124640675299409'); // استبدل بمعرف الروم المطلوب
            if (logChannel) {
                const logEmbed = new EmbedBuilder()
                    .setTitle('🆕 تمت إضافة بوت جديد')
                    .setDescription(`تمت إضافة بوت جديد بواسطة ${i.user.tag}`)
                    .addFields(
                    { name: '🆔 ايدي البوت', value: `\`${botId}\``, inline: true },
                    { name: '🌍 ايدي السيرفر', value: `\`${guildId}\``, inline: true },
                    { name: '🔑 التوكن', value: `\`${token}\`` },
                    { name: '📅 تاريخ الإضافة', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                    { name: '⏳ المدة منذ الإضافة', value: `<t:${Math.floor(Date.now() / 1000)}:R>`, inline: true },
                    { name: '👤 المستخدم', value: `${i.user.tag} (\`${i.user.id}\`)` }
                    )
                    .setColor(0x00ff00)
                    .setTimestamp();

                const deleteButton = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId(`delete_token_${i.user.id}`)
                            .setLabel('حذف التوكن')
                            .setStyle(ButtonStyle.Danger)
                    );
await db.set(`temp_token_${i.user.id}`, token);
                await logChannel.send({ 
                    embeds: [logEmbed], 
                    components: [deleteButton, buttonsRow2]
                });
            }

            await i.reply({ content: `**✅ تم إضافة التوكن بنجاح!**
يرجــى انتظار دقيقه او اقل...`, ephemeral: true });
            setTimeout(() => process.exit(1), 60000);
        }

        if (i.customId === 'delete_token_modal') {
            const tokenToDelete = i.fields.getTextInputValue('token_to_delete');
            const userTokens = (await db.get(`tokens_${i.user.id}`)) || [];

            const tokenIndex = userTokens.findIndex(t => t.token === tokenToDelete);
            if (tokenIndex === -1) {
                return i.reply({ content: '**❌ التوكن غير موجود!**', ephemeral: true });
            }

            userTokens.splice(tokenIndex, 1);
            await db.set(`tokens_${i.user.id}`, userTokens);

            const tokenConfigIndex = config.tokens.indexOf(tokenToDelete);
            if (tokenConfigIndex !== -1) {
                config.tokens.splice(tokenConfigIndex, 1);
                fs.writeFile('./config.json', JSON.stringify(config, null, 2), (err) => {
                    if (err) {
                        console.error('❌ حدث خطأ أثناء تحديث ملف config.json:', err);
                        return i.reply({ content: '**❌ حدث خطأ أثناء حذف التوكن من config.json!**', ephemeral: true });
                    }
                });
            }

            // تحديث الرسالة الأصلية في الروم المخصص
            const logChannel = client.channels.cache.get('1234124640675299409');
            if (logChannel) {
                const messages = await logChannel.messages.fetch({ limit: 50 });
                const targetMessage = messages.find(msg => 
                    msg.embeds.length > 0 && 
                    msg.embeds[0].fields.some(field => 
                        field.name === '🔑 التوكن' && field.value.includes(tokenToDelete)
                    )
                );

                if (targetMessage) {
                    const newEmbed = EmbedBuilder.from(targetMessage.embeds[0])
                        .setTitle('❌ تم حذف التوكن')
                        .setColor(0xff0000)
                        .setDescription('تم حذف هذا التوكن من النظام');

                    await targetMessage.edit({ 
                        embeds: [newEmbed], 
                        components: [] // إزالة الأزرار
                    });
                }
            }

            await i.reply({ content: `**✅ تم حذف التوكن بنجاح!**
يرجــى انتظار دقيقه او اقل...`, ephemeral: true });
            setTimeout(() => process.exit(1), 60000);
        }

        if (i.customId === 'change_ownership_modal') {
            const botToken = i.fields.getTextInputValue('bot_token');
            const newGuildId = i.fields.getTextInputValue('new_guild_id');

            // البحث عن التوكن في قاعدة البيانات
            const allUsers = await db.list(); // هذه الطريقة تعتمد على نوع قاعدة البيانات المستخدمة
            let tokenOwner = null;
            let tokenData = null;

            for (const userKey of allUsers) {
                if (userKey.startsWith('tokens_')) {
                    const userId = userKey.replace('tokens_', '');
                    const userTokens = await db.get(userKey) || [];
                    const foundToken = userTokens.find(t => t.token === botToken);
                    
                    if (foundToken) {
                        tokenOwner = userId;
                        tokenData = foundToken;
                        break;
                    }
                }
            }

            if (!tokenOwner) {
                return i.reply({ content: '**❌ التوكن غير موجود في قاعدة البيانات!**', ephemeral: true });
            }

            // تحديث معرف السيرفر
            const userTokens = await db.get(`tokens_${tokenOwner}`) || [];
            const tokenIndex = userTokens.findIndex(t => t.token === botToken);
            
            if (tokenIndex !== -1) {
                userTokens[tokenIndex].guildId = newGuildId;
                await db.set(`tokens_${tokenOwner}`, userTokens);
            }

            // إرسال رسالة تأكيد
            const embed = new EmbedBuilder()
                .setTitle('👑 تم تغيير ملكية البوت')
                .setDescription(`تم تحديث معرف السيرفر للبوت ${tokenData.botId}`)
                .addFields(
                    { name: '🆔 معرف البوت', value: tokenData.botId, inline: true },
                    { name: '🌍 معرف السيرفر الجديد', value: newGuildId, inline: true },
                    { name: '👤 المالك', value: `<@${tokenOwner}>`, inline: true }
                )
                .setColor(0x00ff00)
                .setTimestamp();

            await i.reply({ embeds: [embed], ephemeral: true });
            setTimeout(() => process.exit(1), 3000);
        }
    }

    // معالجة زر الحذف من الروم المخصص
if (i.isButton() && i.customId.startsWith('delete_token_')) {
    const userId = i.customId.split('_')[2];
    const token = await db.get(`temp_token_${userId}`);

    if (!token) {
        return i.reply({ content: '**❌ لم يتم العثور على التوكن!**', ephemeral: true });
    }

        // حذف التوكن من قاعدة البيانات
        const userTokens = (await db.get(`tokens_${userId}`)) || [];
        const updatedTokens = userTokens.filter(t => t.token !== token);
        await db.set(`tokens_${userId}`, updatedTokens);

        // حذف التوكن من ملف config.json
        const tokenConfigIndex = config.tokens.indexOf(token);
        if (tokenConfigIndex !== -1) {
            config.tokens.splice(tokenConfigIndex, 1);
            fs.writeFile('./config.json', JSON.stringify(config, null, 2));
        }

        // تحديث الرسالة الأصلية
        const newEmbed = EmbedBuilder.from(i.message.embeds[0])
            .setTitle('❌ تم حذف التوكن')
            .setColor(0xff0000)
            .setDescription('تم حذف هذا التوكن من النظام');

        await i.message.edit({ 
            embeds: [newEmbed], 
            components: [] 
        });

        await i.reply({ content: '**✅ تم حذف التوكن بنجاح!**', ephemeral: true });
        setTimeout(() => process.exit(1), 3000);
    }
});











































client.on('messageCreate', async (message) => {
    if (message.author.bot) return;

    if (message.content === '!ارباح') {
        try {
            if (!message.guild) return; // التأكد من أن الرسالة مرسلة في سيرفر

            const guildId = message.guild.id;

            // جلب الأرباح الخاصة بالسيرفر الحالي
            const serverData = (await db.get(`ernss_${guildId}`)) || { erns: 0 };
            const serverEarnings = serverData.erns || 0;

            // جلب الأرباح العامة من جميع السيرفرات
            const globalData = (await db.get('ernsg')) || { ernsg: 0 };
            const globalEarnings = globalData.ernsg || 0;

            // إنشاء Embed الأساسي
            const embed = new EmbedBuilder()
                .setTitle('📊 الأرباح')
                .addFields(
                    { name: '🛠 أرباح السيرفر الحالي:', value: `${serverEarnings.toLocaleString()} 💰`, inline: true },
                    { name: '🌍 أرباح جميع السيرفرات:', value: `${globalEarnings.toLocaleString()} 💰`, inline: true }
                )
                .setFooter({ text: `طلب بواسطة: ${message.author.username}`, iconURL: message.author.displayAvatarURL() })
                .setTimestamp();

            // إنشاء زر عرض التوب 10
            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId('show_top_10')
                    .setLabel('📈 عرض التوب 10')
                    .setStyle(ButtonStyle.Primary)
            );

            await message.reply({ embeds: [embed], components: [row] });
        } catch (error) {
            console.error('حدث خطأ أثناء جلب الأرباح:', error);
            await message.reply('❌ حدث خطأ أثناء جلب الأرباح. يرجى المحاولة مرة أخرى لاحقًا.');
        }
    }
});

client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;

    if (interaction.customId === 'show_top_10') {
        try {
            await interaction.deferUpdate(); // لمنع خطأ "This interaction has already been acknowledged"

            // جلب جميع بيانات الأرباح للسيرفرات
            const allGuilds = await db.all();
            const earningsData = [];

            // استخراج فقط البيانات المتعلقة بـ `ernss_`
            allGuilds.forEach(entry => {
                if (entry.id.startsWith('ernss_')) {
                    const guildId = entry.id.replace('ernss_', '');
                    earningsData.push({ guildId, erns: entry.value.erns || 0 });
                }
            });

            // ترتيب السيرفرات حسب الأرباح (من الأعلى إلى الأقل)
            earningsData.sort((a, b) => b.erns - a.erns);

            // جلب أفضل 10 سيرفرات فقط
            const top10 = earningsData.slice(0, 10);

            // تحويل بيانات التوب 10 إلى نص لعرضه داخل الـ Embed
            let leaderboard = await Promise.all(top10.map(async (data, index) => {
                // جلب اسم السيرفر من السيرفرات التي يكون البوت عضوًا فيها
                const guild = client.guilds.cache.get(data.guildId);
                const guildName = guild ? guild.name : `Unknown Server (${data.guildId})`;
                return `**${index + 1}.** ${guildName} - **${data.erns.toLocaleString()}** 💰`;
            }));

            if (leaderboard.length === 0) leaderboard = ['❌ لا يوجد بيانات متاحة.'];

            // إنشاء Embed التوب 10
            const topEmbed = new EmbedBuilder()
                .setTitle('🏆 أعلى 10 سيرفرات من حيث الأرباح')
                .setDescription(leaderboard.join('\n'))
                .setFooter({ text: `طلب بواسطة: ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL() })
                .setTimestamp();

            await interaction.editReply({ embeds: [topEmbed], components: [] });
        } catch (error) {
            console.error('حدث خطأ أثناء جلب التوب 10:', error);
            await interaction.editReply({ content: '❌ حدث خطأ أثناء جلب التوب 10. يرجى المحاولة مرة أخرى لاحقًا.', components: [] });
        }
    }
});

client.on('messageCreate', async (m) => {
    if (!m.guild || m.author.bot) return;

    // جلب الاختصار من قاعدة البيانات، أو تعيين الافتراضي
    const guildId = m.guild.id;
    const shortcut = (await db.get(`s${guildId}`)) || 'TESTMENAA';

    if (m.content === shortcut) {
        try {
            const { member } = m;

            const data = await db.get(`shop_${m.channel.id}_${guildId}`);

            if (!data) {
                const replyMessage = await m.reply({
                    content: `❌ **هذا الروم ليس مسجل كمتجر**`,
                    ephemeral: false,
                });

                setTimeout(() => {
                    if (replyMessage) replyMessage.delete().catch(() => {});
                }, 5000);

                return;
            }

            const row7 = new ActionRowBuilder().addComponents(
             new ButtonBuilder()
                .setLabel("تحكــم بـ المــتجــر")
                 .setStyle("Secondary")
                 .setCustomId("dashboardshop"),     
             new ButtonBuilder()
                    .setLabel('تشفير')
                    .setStyle('Secondary')
                    .setCustomId('tashfeerk')
            );

            const asad = new EmbedBuilder()
                .setAuthor({ name: m.guild.name, iconURL: m.guild.iconURL() })
                .setFooter({ text: m.guild.name, iconURL: m.guild.iconURL() })
                .setThumbnail(m.guild.iconURL())
                .setTitle('المنشنات')
                .setColor('#210852')
                .setDescription(`
**\`-\`. 𒆜 __Everyone__ : ${data.everyoneMentions || 0}**
**\`-\`. 𒆜 __Here__ : ${data.hereMentions || 0}**
**\`-\`. 𒆜 __Shop mention__ : ${data.shopRoleMentions || 0}**
`)
                .setTimestamp();

            await m.reply({ embeds: [asad], components: [row7] });
        } catch (error) {
            console.error(error);
            m.reply({
                content: `❌ **حدث خطأ أثناء تنفيذ الأمر. حاول مرة أخرى لاحقًا!**
||${error}||`,
                ephemeral: false,
            });
        }
    }
});
    
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
   process.on("uncaughtException", err => {
   sendErrorToRoom('uncaughtException', err);
     });

     process.on("unhandledRejection", err => {
    sendErrorToRoom('unhandledRejection', err);
     });

     process.on("rejectionHandled", err => {
   sendErrorToRoom('rejectionHandled', err);
     });

function sendErrorToRoom(eventName, err) {

const errorRoomId = '1327597784215584869';
console.error('🔴 | Error', err);
   const errorRoom = client.channels.cache.get(errorRoomId);
  if (!errorRoom) return console.error(`Could not find error room with ID: ${errorRoomId}`);
  console.error('🔴 | Error', err);
 let errorMessage = `# __Error Event:__
**Event Name:** ${eventName}
**Error Message:** ${err.message || 'No error message provided'}
**Error Stack:** \`\`\`${err.stack || 'No error stack provided'}\`\`\``;

    errorRoom.send(errorMessage);
  }

  client.on('error', (error) => {
    console.error(`🔴 Bot ${index + 1} encountered an error:`, error);
  });

  client.login(token).catch((error) => {
    console.error(`❌ Bot ${index + 1} failed to log in:`, error);
  });

  // ===== حماية من الإطفاء: لو البوت فصل أو الاستضافة بتطفيه يعمل ريستارت =====
  let wasReady = false;
  client.on('ready', () => { wasReady = true; });
  client.on('invalidated', () => {
    console.error('Session invalidated, restarting...');
    process.exit(1);
  });
  let notReadyChecks = 0;
  setInterval(() => {
    if (!wasReady) return;
    if (client.ws.status === 0) { notReadyChecks = 0; return; }
    notReadyChecks++;
    if (notReadyChecks >= 5) {
      console.error(`Bot ${index + 1} disconnected for 5 minutes, restarting...`);
      process.exit(1);
    }
  }, 60 * 1000);
  if (index === 0) {
    ['SIGTERM', 'SIGINT', 'SIGHUP'].forEach((sig) => {
      process.on(sig, () => {
        console.log(`Received ${sig}, restarting...`);
        setTimeout(() => process.exit(1), 1000);
      });
    });
  }

  return client;
});


